"""Audit log routes -- account-level activity trail."""
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Account, AuditLog, User
from app.schemas import AuditLogResponse, MessageResponse
from app.utils.auth import get_current_active_user
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/audit-log", tags=["audit-log"])


@router.get("", response_model=list[AuditLogResponse])
async def list_audit_logs(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    event_type: Optional[str] = Query(None, description="Filter by event type"),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    """Return the account's own audit trail, paginated.

    Includes file-purge confirmations, deletion attestations, consent
    changes, and other account-scoped events. Superadmins see all logs.
    """
    query = select(AuditLog)

    if current_user.role.value == "superadmin":
        # Superadmin sees all, optionally filter by account
        pass
    else:
        query = query.where(AuditLog.account_id == current_user.account_id)

    if event_type:
        query = query.where(AuditLog.event_type == event_type)

    query = query.order_by(AuditLog.created_at.desc()).offset(offset).limit(limit)
    result = await db.execute(query)
    logs = result.scalars().all()

    return [
        AuditLogResponse(
            public_id=log.public_id,
            event_type=log.event_type,
            event_details=log.event_details,
            ip_address=log.ip_address,
            created_at=log.created_at,
        )
        for log in logs
    ]
