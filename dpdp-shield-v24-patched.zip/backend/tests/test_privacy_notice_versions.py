"""Privacy Notice version management tests."""
import secrets

import pytest
from fastapi import status
from httpx import AsyncClient

from app.models import Account, PrivacyNotice, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_publish_unpublish_cycle(async_client: AsyncClient, db_session):
    """Publish then unpublish a privacy notice; verify state transitions."""
    account = Account(
        business_name="PN Test",
        business_slug="pn-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="pn@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    notice = PrivacyNotice(
        account_id=account.id,
        template_type="generic",
        content={"sections": []},
        version=1,
        is_published=False,
    )
    db_session.add(notice)
    await db_session.commit()
    await db_session.refresh(notice)

    token = create_access_token({"sub": str(user.public_id)})

    # Publish
    response = await async_client.post(
        f"/api/v1/privacy-notice/{notice.public_id}/publish",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["is_published"] is True
    assert data["published_at"] is not None

    # Unpublish
    response = await async_client.post(
        f"/api/v1/privacy-notice/{notice.public_id}/unpublish",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["is_published"] is False
    assert data["published_at"] is None


@pytest.mark.asyncio
async def test_version_detail(async_client: AsyncClient, db_session):
    """GET /versions/{version_id} returns the specific version."""
    account = Account(
        business_name="PN Version Test",
        business_slug="pn-version-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="pnv@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    notice = PrivacyNotice(
        account_id=account.id,
        template_type="ecommerce",
        content={"title": "v1"},
        version=1,
        is_published=False,
    )
    db_session.add(notice)
    await db_session.commit()
    await db_session.refresh(notice)

    token = create_access_token({"sub": str(user.public_id)})
    response = await async_client.get(
        f"/api/v1/privacy-notice/versions/{notice.public_id}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["public_id"] == str(notice.public_id)
    assert data["version"] == 1
    assert data["content"]["title"] == "v1"


@pytest.mark.asyncio
async def test_restore_version_creates_new_and_unpublishes_prior(async_client: AsyncClient, db_session):
    """Restore creates a NEW version with old content, unpublishes prior, increments version."""
    account = Account(
        business_name="PN Restore Test",
        business_slug="pn-restore-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="pnr@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    old_notice = PrivacyNotice(
        account_id=account.id,
        template_type="service",
        content={"title": "Old Content"},
        version=1,
        is_published=False,
    )
    db_session.add(old_notice)

    current_notice = PrivacyNotice(
        account_id=account.id,
        template_type="service",
        content={"title": "Current Content"},
        version=2,
        is_published=True,
    )
    db_session.add(current_notice)
    await db_session.commit()
    await db_session.refresh(old_notice)
    await db_session.refresh(current_notice)

    token = create_access_token({"sub": str(user.public_id)})

    # Restore old version
    response = await async_client.post(
        f"/api/v1/privacy-notice/versions/{old_notice.public_id}/restore",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "Restored as version 3" in data["message"]

    # Verify current (v2) is now unpublished
    response = await async_client.get(
        f"/api/v1/privacy-notice/versions/{current_notice.public_id}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    current_data = response.json()
    assert current_data["is_published"] is False

    # Verify a new v3 exists and is published with old content
    response = await async_client.get(
        "/api/v1/privacy-notice/versions",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    versions = response.json()
    v3 = next((v for v in versions if v["version"] == 3), None)
    assert v3 is not None
    assert v3["is_published"] is True
    assert v3["content"]["title"] == "Old Content"
