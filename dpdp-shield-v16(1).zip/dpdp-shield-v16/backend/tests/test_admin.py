"""Admin panel access-control tests."""
import secrets

import pytest
from httpx import AsyncClient

from app.models import Account, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_regular_admin_cannot_access_admin_panel(async_client: AsyncClient, db_session):
    """A normal account admin (not superadmin) must get 403 on admin panel routes."""
    account = Account(
        business_name="Not Super", business_slug="not-super",
        sector="E-commerce", widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    admin = User(account_id=account.id, email="admin@x.com", password_hash="h", role=UserRole.ADMIN)
    db_session.add(admin)
    await db_session.commit()

    token = create_access_token({"sub": str(admin.public_id)})
    response = await async_client.get("/api/v1/admin/accounts", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 403, response.text


@pytest.mark.asyncio
async def test_superadmin_can_list_accounts_and_see_analytics(async_client: AsyncClient, db_session):
    """A superadmin can list accounts and pull analytics."""
    account = Account(
        business_name="Regular Biz", business_slug="regular-biz",
        sector="Services", widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    super_account = Account(
        business_name="Platform Ops", business_slug="platform-ops",
        sector="Internal", widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(super_account)
    await db_session.flush()

    superadmin = User(
        account_id=super_account.id, email="super@platform.com",
        password_hash="h", role=UserRole.SUPERADMIN,
    )
    db_session.add(superadmin)
    await db_session.commit()

    token = create_access_token({"sub": str(superadmin.public_id)})

    response = await async_client.get("/api/v1/admin/accounts", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200, response.text
    accounts = response.json()
    assert len(accounts) == 2

    response = await async_client.get("/api/v1/admin/analytics", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200, response.text
    analytics = response.json()
    assert analytics["total_accounts"] == 2
    assert analytics["total_users"] == 1


@pytest.mark.asyncio
async def test_superadmin_suspend_and_activate(async_client: AsyncClient, db_session):
    """Suspend then activate an account via the admin panel."""
    target = Account(
        business_name="Target Biz", business_slug="target-biz",
        sector="E-commerce", widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(target)
    await db_session.flush()

    super_account = Account(
        business_name="Ops", business_slug="ops-team",
        sector="Internal", widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(super_account)
    await db_session.flush()

    superadmin = User(
        account_id=super_account.id, email="ops@platform.com",
        password_hash="h", role=UserRole.SUPERADMIN,
    )
    db_session.add(superadmin)
    await db_session.commit()
    await db_session.refresh(target)

    token = create_access_token({"sub": str(superadmin.public_id)})

    response = await async_client.post(
        f"/api/v1/admin/accounts/{target.public_id}/suspend",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200, response.text

    response = await async_client.post(
        f"/api/v1/admin/accounts/{target.public_id}/activate",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200, response.text
