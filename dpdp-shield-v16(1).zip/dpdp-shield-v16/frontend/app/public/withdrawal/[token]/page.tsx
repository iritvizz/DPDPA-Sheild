"use client";

import { useTranslations } from "next-intl";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function WithdrawalPage({
  params,
}: {
  params: { token: string };
}) {
  const t = useTranslations();

  // TODO: call GET /api/v1/public/withdrawal/{token} to verify and withdraw
  const handleConfirm = () => {
    alert("Withdrawal confirmed (placeholder — wire to backend)");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <Card className="max-w-md w-full mx-4">
        <CardHeader>
          <CardTitle>{t("consent.withdrawalTitle")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-600">
            {t("consent.withdrawalDescription")}
          </p>
          <Button onClick={handleConfirm} className="w-full">
            {t("consent.confirmWithdrawal")}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
