import { getRequestConfig } from "next-intl/server";

export const locales = ["en", "hi", "gu"];
export const defaultLocale = "en";

export default getRequestConfig(async ({ requestLocale }) => {
  let locale = await requestLocale;
  if (!locale || !locales.includes(locale as any)) {
    locale = defaultLocale;
  }
  return {
    locale,
    messages: (await import(`./locales/${locale}.json`)).default,
  };
});
