import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const t = await getTranslations();

  const navItems = [
    { href: "/dashboard", label: t("dashboard.title") },
    { href: "/inventory", label: t("inventory.title") },
    { href: "/privacy-notice", label: t("privacyNotice.title") },
    { href: "/consent", label: t("consent.title") },
    { href: "/dsar", label: t("dsar.title") },
    { href: "/retention", label: t("retention.title") },
    { href: "/reports", label: t("reports.title") },
    { href: "/settings", label: t("settings.title") },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">{t("app.name")}</h1>
          <div className="flex gap-2">
            <Link href="/admin">
              <Button variant="ghost" size="sm">Admin</Button>
            </Link>
            <Button variant="outline" size="sm">{t("auth.logout")}</Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 flex gap-6">
        <aside className="w-64 shrink-0">
          <Card>
            <CardContent className="p-4 space-y-2">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="block px-3 py-2 rounded-md text-sm text-gray-700 hover:bg-gray-100"
                >
                  {item.label}
                </Link>
              ))}
            </CardContent>
          </Card>
        </aside>

        <main className="flex-1">{children}</main>
      </div>
    </div>
  );
}
