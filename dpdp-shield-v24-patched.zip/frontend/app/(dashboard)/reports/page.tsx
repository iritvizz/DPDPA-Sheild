"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

interface MonthlySummary {
  consent_records_count: number;
  dsar_requests_count: number;
  data_sources_count: number;
  privacy_notice_updates: number;
}

interface AuditPackStatus {
  generation_id: string;
  status: string;
  download_url: string | null;
  expires_at: string | null;
}

export default function ReportsPage() {
  const t = useTranslations();
  const [summary, setSummary] = useState<MonthlySummary | null>(null);
  const [auditPack, setAuditPack] = useState<AuditPackStatus | null>(null);
  const [polling, setPolling] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadSummary(); }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (polling && auditPack?.generation_id) {
      interval = setInterval(async () => {
        try {
          const data = await apiFetch(`/api/v1/reports/audit-pack/${auditPack.generation_id}`);
          setAuditPack(data);
          if (data.status === "completed" || data.status === "failed") setPolling(false);
        } catch (err: any) {
          setPolling(false);
          setError(err.message || "Polling failed");
        }
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [polling, auditPack?.generation_id]);

  async function loadSummary() {
    try {
      const data = await apiFetch("/api/v1/reports/monthly-summary");
      setSummary(data);
    } catch (err: any) {
      setError(err.message || "Failed to load summary");
    } finally {
      setLoading(false);
    }
  }

  async function generateAuditPack() {
    try {
      setError("");
      const data = await apiFetch("/api/v1/reports/audit-pack", { method: "POST" });
      setAuditPack(data);
      if (data.status === "queued") setPolling(true);
    } catch (err: any) {
      setError(err.message || "Failed to generate audit pack");
    }
  }

  if (loading) return <p className="text-gray-500">Loading reports...</p>;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t("reports.title")}</h2>
      {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}

      <Card>
        <CardHeader><CardTitle>{t("reports.monthlySummary")}</CardTitle></CardHeader>
        <CardContent>
          {summary ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-gray-50 rounded-lg"><p className="text-2xl font-bold">{summary.consent_records_count}</p><p className="text-sm text-gray-500">{t("reports.consentRecords")}</p></div>
              <div className="text-center p-4 bg-gray-50 rounded-lg"><p className="text-2xl font-bold">{summary.dsar_requests_count}</p><p className="text-sm text-gray-500">{t("reports.dsarRequests")}</p></div>
              <div className="text-center p-4 bg-gray-50 rounded-lg"><p className="text-2xl font-bold">{summary.data_sources_count}</p><p className="text-sm text-gray-500">{t("reports.dataSources")}</p></div>
              <div className="text-center p-4 bg-gray-50 rounded-lg"><p className="text-2xl font-bold">{summary.privacy_notice_updates}</p><p className="text-sm text-gray-500">{t("reports.privacyNoticeUpdates")}</p></div>
            </div>
          ) : <p className="text-gray-500">{t("reports.noData")}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>{t("reports.auditPack")}</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-600">{t("reports.auditPackDescription")}</p>
          <Button onClick={generateAuditPack} disabled={polling}>{polling ? t("reports.generating") : t("reports.generateAuditPack")}</Button>
          {auditPack && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">{t("reports.status")}:</span>
                <Badge className={auditPack.status === "completed" ? "bg-green-100 text-green-800" : auditPack.status === "failed" ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"}>{auditPack.status}</Badge>
              </div>
              {auditPack.download_url && (
                <div>
                  <a href={auditPack.download_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline text-sm">{t("reports.downloadAuditPack")}</a>
                  <p className="text-xs text-gray-400">{t("reports.expires")}: {new Date(auditPack.expires_at!).toLocaleString()}</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
