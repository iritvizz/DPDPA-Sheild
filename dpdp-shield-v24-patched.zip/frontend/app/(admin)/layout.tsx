import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const t = await getTranslations();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-red-700 text-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">{t("app.name")} — {t("admin.title")}</h1>
            <p className="text-xs text-red-200">{t("admin.superadminOnly")}</p>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm" className="text-white border-white hover:bg-red-600">
              {t("admin.exitAdmin")}
            </Button>
          </Link>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 flex gap-6">
        <aside className="w-64 shrink-0">
          <Card>
            <CardContent className="p-4 space-y-2">
              <Link href="/admin" className="block px-3 py-2 rounded-md text-sm text-gray-700 hover:bg-gray-100">
                {t("admin.dashboard")}
              </Link>
              <Link href="/admin/accounts" className="block px-3 py-2 rounded-md text-sm text-gray-700 hover:bg-gray-100">
                {t("admin.accounts")}
              </Link>
            </CardContent>
          </Card>
        </aside>

        <main className="flex-1">{children}</main>
      </div>
    </div>
  );
}
