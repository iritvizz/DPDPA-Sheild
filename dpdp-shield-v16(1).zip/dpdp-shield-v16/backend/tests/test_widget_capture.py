"""Widget capture endpoint test with genuinely valid nonce."""
import secrets

import pytest
from httpx import AsyncClient

from app.models import Account
from app.utils.auth import generate_widget_nonce


@pytest.mark.asyncio
async def test_widget_capture_with_valid_nonce(async_client: AsyncClient, db_session):
    """End-to-end: create account -> generate valid nonce -> capture consent via widget."""
    account = Account(
        business_name="Widget Test Co",
        business_slug="widget-test-co",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.commit()
    await db_session.refresh(account)

    nonce = generate_widget_nonce(account.business_slug, account.widget_nonce_secret)

    response = await async_client.post(
        "/api/v1/consent/widget/capture",
        json={
            "business_slug": account.business_slug,
            "customer_reference": "cust-widget-001",
            "purpose": "marketing",
            "nonce": nonce,
        },
    )

    assert response.status_code == 201, f"Widget capture failed: {response.text}"
    data = response.json()
    assert data["status"] == "success"
    assert "Consent recorded" in data["message"]


@pytest.mark.asyncio
async def test_widget_capture_invalid_nonce(async_client: AsyncClient, db_session):
    """Widget capture with a bad nonce must be rejected."""
    account = Account(
        business_name="Widget Test Co 2",
        business_slug="widget-test-co-2",
        sector="Services",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.commit()

    response = await async_client.post(
        "/api/v1/consent/widget/capture",
        json={
            "business_slug": account.business_slug,
            "customer_reference": "cust-002",
            "purpose": "analytics",
            "nonce": "totally-fake-nonce-1234567890ab",
        },
    )

    assert response.status_code == 403
    assert "Invalid widget nonce" in response.json()["detail"]
