#!/usr/bin/env python3
"""Export OpenAPI 3.0 spec from FastAPI app.

Usage:
    cd backend
    source venv/bin/activate
    python scripts/export_openapi.py > ../docs/api-spec.yaml

Requires: app must be importable (DATABASE_URL can be a dummy value)
"""
import json
import sys
from pathlib import Path

# Add app to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from app.main import app


def main():
    openapi = app.openapi()
    # FastAPI generates dict; dump as YAML or JSON
    try:
        import yaml
        print(yaml.dump(openapi, sort_keys=False, allow_unicode=True))
    except ImportError:
        print(json.dumps(openapi, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
