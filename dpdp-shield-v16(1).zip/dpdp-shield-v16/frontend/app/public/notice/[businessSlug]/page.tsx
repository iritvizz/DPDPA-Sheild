import { getTranslations } from "next-intl/server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function PublicNoticePage({
  params,
}: {
  params: { businessSlug: string };
}) {
  const t = await getTranslations();

  // TODO: fetch real notice from GET /api/v1/public/notice/{businessSlug}
  const notice = {
    title: "Privacy Notice",
    content: "This is a placeholder privacy notice. In production, this would be fetched from the backend based on the business slug.",
    version: "1.0",
    updated_at: "2026-08-07",
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4">
        <Card>
          <CardHeader>
            <CardTitle>{notice.title}</CardTitle>
            <p className="text-sm text-gray-500">
              {t("privacyNotice.version")} {notice.version} • {notice.updated_at}
            </p>
          </CardHeader>
          <CardContent>
            <div className="prose max-w-none">
              {notice.content.split("\n").map((paragraph, i) => (
                <p key={i} className="mb-4">{paragraph}</p>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
