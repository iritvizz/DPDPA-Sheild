/**
 * DPDP Shield — Embeddable Consent Widget
 *
 * Usage: paste this script tag on your website:
 * <script src="https://YOUR_API_DOMAIN/widget.js" data-business-slug="your-slug"></script>
 *
 * Or load it asynchronously:
 * <script async src="..." data-business-slug="..."></script>
 */
(function () {
  "use strict";

  const API_BASE = "https://api.dpdp-shield.in"; // override via data-api-base
  const WIDGET_VERSION = "1.0.0";

  function getConfig() {
    const script = document.currentScript || document.querySelector('script[src*="widget.js"]');
    if (!script) return null;
    return {
      businessSlug: script.dataset.businessSlug,
      apiBase: script.dataset.apiBase || API_BASE,
      purpose: script.dataset.purpose || "general",
      language: script.dataset.language || "en",
      theme: script.dataset.theme || "light",
      position: script.dataset.position || "bottom-right",
    };
  }

  async function fetchNonce(config) {
    const res = await fetch(`${config.apiBase}/api/v1/consent/widget/nonce?business_slug=${encodeURIComponent(config.businessSlug)}`);
    if (!res.ok) throw new Error("Failed to fetch widget nonce");
    const data = await res.json();
    return data.nonce;
  }

  async function submitConsent(config, nonce, customerReference) {
    const res = await fetch(`${config.apiBase}/api/v1/consent/widget/capture`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        business_slug: config.businessSlug,
        nonce: nonce,
        customer_reference: customerReference,
        purpose: config.purpose,
      }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: "Request failed" }));
      throw new Error(err.detail || "Consent capture failed");
    }
    return res.json();
  }

  function injectStyles() {
    if (document.getElementById("dpdp-widget-styles")) return;
    const style = document.createElement("style");
    style.id = "dpdp-widget-styles";
    style.textContent = `
      .dpdp-widget-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.4); z-index: 9998; display: none;
      }
      .dpdp-widget-overlay.active { display: block; }
      .dpdp-widget-modal {
        position: fixed; z-index: 9999; max-width: 420px; width: 90%;
        background: #fff; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,0.2);
        padding: 24px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 14px; line-height: 1.5; color: #1a202c; display: none;
      }
      .dpdp-widget-modal.active { display: block; }
      .dpdp-widget-modal.bottom-right { bottom: 20px; right: 20px; }
      .dpdp-widget-modal.bottom-left { bottom: 20px; left: 20px; }
      .dpdp-widget-modal.top-right { top: 20px; right: 20px; }
      .dpdp-widget-modal.top-left { top: 20px; left: 20px; }
      .dpdp-widget-modal.center { top: 50%; left: 50%; transform: translate(-50%, -50%); }
      .dpdp-widget-title { font-size: 16px; font-weight: 600; margin-bottom: 12px; }
      .dpdp-widget-text { margin-bottom: 16px; color: #4a5568; }
      .dpdp-widget-input {
        width: 100%; padding: 10px 12px; border: 1px solid #e2e8f0;
        border-radius: 6px; font-size: 14px; margin-bottom: 12px; box-sizing: border-box;
      }
      .dpdp-widget-btn {
        width: 100%; padding: 10px; border: none; border-radius: 6px;
        background: #1a365d; color: #fff; font-size: 14px; font-weight: 500;
        cursor: pointer; transition: opacity 0.2s;
      }
      .dpdp-widget-btn:hover { opacity: 0.9; }
      .dpdp-widget-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      .dpdp-widget-close {
        position: absolute; top: 12px; right: 16px; background: none; border: none;
        font-size: 20px; cursor: pointer; color: #718096;
      }
      .dpdp-widget-success { color: #276749; text-align: center; padding: 12px 0; }
      .dpdp-widget-error { color: #c53030; text-align: center; padding: 12px 0; font-size: 13px; }
      .dpdp-widget-footer { margin-top: 12px; font-size: 11px; color: #a0aec0; text-align: center; }
      .dpdp-widget-footer a { color: #718096; text-decoration: underline; }
    `;
    document.head.appendChild(style);
  }

  function createModal(config) {
    injectStyles();

    const overlay = document.createElement("div");
    overlay.className = "dpdp-widget-overlay";
    overlay.id = "dpdp-widget-overlay";

    const modal = document.createElement("div");
    modal.className = `dpdp-widget-modal ${config.position}`;
    modal.id = "dpdp-widget-modal";

    modal.innerHTML = `
      <button class="dpdp-widget-close" id="dpdp-widget-close" aria-label="Close">&times;</button>
      <div class="dpdp-widget-title">We value your privacy</div>
      <div class="dpdp-widget-text">
        By continuing, you consent to our processing of your personal data
        in accordance with the Digital Personal Data Protection Act, 2023 (DPDPA).
      </div>
      <input type="email" class="dpdp-widget-input" id="dpdp-widget-email"
             placeholder="Enter your email" required />
      <button class="dpdp-widget-btn" id="dpdp-widget-submit">I Consent</button>
      <div id="dpdp-widget-message"></div>
      <div class="dpdp-widget-footer">
        Powered by <a href="https://dpdp-shield.in" target="_blank" rel="noopener">DPDP Shield</a>
      </div>
    `;

    document.body.appendChild(overlay);
    document.body.appendChild(modal);

    return { overlay, modal };
  }

  async function initWidget() {
    const config = getConfig();
    if (!config || !config.businessSlug) {
      console.error("[DPDP Widget] Missing data-business-slug attribute on script tag.");
      return;
    }

    const { overlay, modal } = createModal(config);
    const closeBtn = document.getElementById("dpdp-widget-close");
    const submitBtn = document.getElementById("dpdp-widget-submit");
    const emailInput = document.getElementById("dpdp-widget-email");
    const messageEl = document.getElementById("dpdp-widget-message");

    function show() {
      overlay.classList.add("active");
      modal.classList.add("active");
    }

    function hide() {
      overlay.classList.remove("active");
      modal.classList.remove("active");
    }

    closeBtn.addEventListener("click", hide);
    overlay.addEventListener("click", hide);

    submitBtn.addEventListener("click", async function () {
      const email = emailInput.value.trim();
      if (!email || !email.includes("@")) {
        messageEl.innerHTML = '<div class="dpdp-widget-error">Please enter a valid email.</div>';
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = "Processing...";
      messageEl.innerHTML = "";

      try {
        const nonce = await fetchNonce(config);
        await submitConsent(config, nonce, email);
        messageEl.innerHTML = '<div class="dpdp-widget-success">Thank you. Your consent has been recorded.</div>';
        submitBtn.textContent = "Consent Recorded";
        setTimeout(hide, 2500);
      } catch (err) {
        messageEl.innerHTML = `<div class="dpdp-widget-error">${err.message || "Something went wrong."}</div>`;
        submitBtn.disabled = false;
        submitBtn.textContent = "I Consent";
      }
    });

    // Show after a short delay so the page has time to render
    setTimeout(show, 800);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initWidget);
  } else {
    initWidget();
  }
})();
