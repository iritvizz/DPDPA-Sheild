# DPDP Shield - AWS Deployment Runbook

## Prerequisites
- AWS CLI configured
- Docker installed
- Domain registered

## 1. AWS Resources

### RDS PostgreSQL
```bash
aws rds create-db-instance \
  --db-instance-identifier dpdp-shield-db \
  --db-instance-class db.t3.medium \
  --engine postgres --engine-version 15.4 \
  --allocated-storage 20 \
  --master-username postgres \
  --master-user-password <STRONG_PASSWORD> \
  --backup-retention-period 30 \
  --region ap-south-1
```

### ElastiCache Redis
```bash
aws elasticache create-cache-cluster \
  --cache-cluster-id dpdp-shield-redis \
  --engine redis \
  --cache-node-type cache.t3.micro \
  --region ap-south-1
```

### S3 Buckets
```bash
# Consent proofs - encrypted, private
aws s3api create-bucket \
  --bucket dpdp-shield-consent-proofs \
  --region ap-south-1 \
  --create-bucket-configuration LocationConstraint=ap-south-1

aws s3api put-bucket-encryption \
  --bucket dpdp-shield-consent-proofs \
  --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

# Temp bucket - 1 hour auto-delete
aws s3api create-bucket \
  --bucket dpdp-shield-temp \
  --region ap-south-1 \
  --create-bucket-configuration LocationConstraint=ap-south-1
```

## 2. Environment Variables

```bash
SECRET_KEY=<GENERATE_WITH: python -c "import secrets; print(secrets.token_urlsafe(32))">
DATABASE_URL=postgresql+asyncpg://postgres:<PASSWORD>@<RDS_ENDPOINT>:5432/dpdp_shield
REDIS_URL=redis://<ELASTICACHE_ENDPOINT>:6379/0
AWS_REGION=ap-south-1
AWS_ACCESS_KEY_ID=<KEY>
AWS_SECRET_ACCESS_KEY=<SECRET>
S3_BUCKET_CONSENT_PROOFS=dpdp-shield-consent-proofs
S3_BUCKET_TEMP=dpdp-shield-temp
RAZORPAY_KEY_ID=<KEY>
RAZORPAY_KEY_SECRET=<SECRET>
RAZORPAY_WEBHOOK_SECRET=<SECRET>
SES_FROM_EMAIL=noreply@dpdp-shield.in
ENVIRONMENT=production
FRONTEND_URL=https://app.dpdp-shield.in
API_URL=https://api.dpdp-shield.in
```

## 3. Deploy

```bash
docker-compose -f docker-compose.prod.yml up --build
```

## 4. Database Migrations

```bash
cd backend
alembic upgrade head
```

## 5. Razorpay Webhook

Set webhook URL to: `https://api.dpdp-shield.in/api/v1/webhooks/razorpay`

## Known Gaps (MVP)
1. Rate limiting - implement before production traffic
2. Pre-storage malware scanning - GuardDuty post-upload only
3. SMS integration - Twilio configured but not wired
