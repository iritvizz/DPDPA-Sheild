import { getTranslations } from "next-intl/server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

// NOTE: In a real implementation, these would be fetched from the backend
// via `fetch()` in a Server Component.  For now, we use the structure
// the backend already supports (GET /api/v1/dashboard/summary) and mark
// where the real data hook belongs.

export default async function DashboardPage() {
  const t = await getTranslations();

  // TODO: Replace with real fetch to /api/v1/dashboard/summary
  const summary = {
    total_data_sources: 0,
    total_consent_records: 0,
    total_privacy_notices: 0,
    pending_dsars: 0,
    trial_days_remaining: 14,
  };

  const checklist = [
    { key: "dataInventory", done: summary.total_data_sources > 0 },
    { key: "privacyNotice", done: summary.total_privacy_notices > 0 },
    { key: "consentRecords", done: summary.total_consent_records > 0 },
    { key: "grievanceContact", done: false },
    { key: "ropa", done: false },
  ];

  const completed = checklist.filter((c) => c.done).length;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">{t("dashboard.title")}</h2>
        <p className="text-gray-500 mt-1">
          {t("dashboard.trialDaysRemaining", { days: summary.trial_days_remaining })}
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t("dashboard.complianceChecklist")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <span className="text-lg font-semibold">
              {completed} {t("dashboard.ofComplete")}
            </span>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div
                className="bg-blue-600 h-2 rounded-full"
                style={{ width: `${(completed / 5) * 100}%` }}
              />
            </div>
          </div>
          <ul className="space-y-2">
            {checklist.map((item) => (
              <li key={item.key} className="flex items-center gap-2">
                <Badge variant={item.done ? "default" : "secondary"}>
                  {item.done ? "✓" : "○"}
                </Badge>
                <span className={item.done ? "line-through text-gray-400" : ""}>
                  {t(`checklist.${item.key}`)}
                </span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div>
        <h3 className="text-lg font-semibold mb-3">{t("dashboard.quickActions")}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { href: "/inventory", label: t("dashboard.dataInventory") },
            { href: "/privacy-notice", label: t("dashboard.privacyNotice") },
            { href: "/consent", label: t("dashboard.consentManagement") },
            { href: "/reports", label: t("dashboard.generateAuditPack") },
          ].map((action) => (
            <Link key={action.href} href={action.href}>
              <Button variant="outline" className="w-full h-24 flex flex-col gap-2">
                <span className="text-2xl">→</span>
                <span>{action.label}</span>
              </Button>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
