# DPDP Shield v23 — Fix List

## Summary

This round fixes three mechanical bugs that blocked clean installs and test runs, answers the long-standing Gujarati PDF rendering question with a real product feature, and verifies that the DSAR and Reports frontend pages are already fully wired to their backends.

---

## 1. Bug: `pytest-asyncio` missing from `requirements.txt`

**What:** `pytest-asyncio==0.23.7` was accidentally dropped from `backend/requirements.txt` during a prior dependency-bump edit.

**Impact:** A clean install followed by `pytest` fails at collection with `ModuleNotFoundError: No module named 'pytest_asyncio'`.

**Fix:** Added `pytest-asyncio==0.23.7` back to `backend/requirements.txt`.

**File:** `backend/requirements.txt`

---

## 2. Bug: `pytest.ini` uses wrong section header

**What:** `backend/pytest.ini` used `[tool:pytest]` as its section header. That header is only valid inside `setup.cfg`. A standalone file named `pytest.ini` requires `[pytest]`.

**Impact:** pytest silently ignores the entire file on bare `pytest` invocations (the normal way most developers and CI systems run it). `testpaths = tests`, `asyncio_mode = auto`, and all other settings are disabled. This causes pytest to sweep the whole repo, erroring out on `scripts/load_test.py` (which needs `locust`, not installed).

**Fix:** Changed section header from `[tool:pytest]` to `[pytest]`.

**Verification:** `pytest --collect-only` (no explicit path) now correctly collects exactly 50 tests.

**File:** `backend/pytest.ini`

---

## 3. Bug: `frontend/package.json` overrides break `npm install`

**What:** `postcss` was declared both as a direct dependency (`^8.4.38`) and as an `overrides` entry (`>=8.4.31`). npm's stricter recent validation rejects this as a conflict, even though the ranges are compatible.

**Impact:** Hard failure on `npm install`. No one gets past install with this file as-is.

**Fix:** Changed the override from a version range to `"postcss": "$postcss"` — npm's syntax for "match whatever the direct dependency resolves to". This expresses the actual intent (force all transitive resolutions to the top-level version) without duplicating a range that can drift out of sync.

**File:** `frontend/package.json`

---

## 4. Feature: Privacy Notice PDF Export

**What:** There was no way for a user to export a privacy notice as a PDF. The test assumed a `/download` endpoint existed, but it had never been built.

**Backend changes:**

- Added `GET /api/v1/privacy-notice/{notice_id}/download` to `backend/app/api/v1/privacy_notice.py`.
- PDF generation is synchronous (privacy notices are small; no need for Celery async pipeline).
- Uses WeasyPrint with a Noto Sans font stack to ensure Gujarati and other Unicode scripts render correctly when `fonts-noto-core` is installed (already specified in `backend/Dockerfile`).
- HTML template is UTF-8 aware and includes proper `@page` CSS for A4 output.
- Returns `Content-Type: application/pdf` with `Content-Disposition: attachment`.
- Creates an `AuditLog` entry on every download using the correct field names (`event_type` / `event_details`).

**Frontend changes:**

- Added a **Download PDF** button to every version card in `frontend/app/(dashboard)/privacy-notice/page.tsx`.
- Uses direct `fetch` (not `apiFetch`) because the response is binary PDF data, not JSON.
- Streams the blob to a temporary object URL and triggers browser download via anchor element.
- Shows loading state ("Downloading...") and disables the button while in progress.
- Translation key `privacyNotice.downloadPdf` already existed in `en.json`, `gu.json`, and `hi.json`.

**Files:**
- `backend/app/api/v1/privacy_notice.py`
- `frontend/app/(dashboard)/privacy-notice/page.tsx`

---

## 5. Test fix: Gujarati PDF rendering test

**What:** `backend/tests/test_gujarati_pdf_rendering.py` had three problems:
1. **Syntax error:** docstring closed with `""""` (four quotes) instead of `"""`, making the entire file unparseable.
2. **Wrong endpoint:** called `GET /api/v1/privacy-notice/{id}/download` which didn't exist.
3. **Incomplete last line:** the assertion was cut off mid-expression.

**Fix:**
- Removed the extra quote.
- Added `language: "gu"` to the notice content to match the HTML generator's expectations.
- Added `%PDF` magic-byte validation.
- Added a Unicode-range heuristic to detect Gujarati glyphs in the PDF stream.
- The test now calls the real `/download` endpoint.

**File:** `backend/tests/test_gujarati_pdf_rendering.py`

---

## 6. New test: Privacy Notice Download endpoint

**What:** The new `/download` endpoint needed test coverage.

**Fix:** Added `backend/tests/test_privacy_notice_download.py` with two test cases:
1. **Success:** valid notice returns PDF with correct headers, and an `AuditLog` is created with correct `event_type` / `event_details`.
2. **Not found:** non-existent `notice_id` returns 404.

**File:** `backend/tests/test_privacy_notice_download.py`

---

## 7. Verified: DSAR and Reports frontend pages are not placeholders

**What:** The handover flagged the DSAR and Reports frontend pages as potentially still being placeholder shells with zero backend calls.

**Verification:** Inspected the current v22 files:
- `frontend/app/(dashboard)/dsar/page.tsx` — makes live calls to `/api/v1/dsar`, `/api/v1/dsar/{id}/actions`, `/api/v1/dsar/templates`, supports create/update/status-change/action-add with full UI.
- `frontend/app/(dashboard)/reports/page.tsx` — makes live calls to `/api/v1/reports/monthly-summary` and `/api/v1/reports/audit-pack`, with polling for async generation status.

**Result:** Both pages are fully implemented. No changes needed.

---

## Files changed in this round

| File | Change |
|------|--------|
| `backend/requirements.txt` | Add `pytest-asyncio==0.23.7` |
| `backend/pytest.ini` | Fix section header `[tool:pytest]` → `[pytest]` |
| `frontend/package.json` | Fix `overrides.postcss` to `"$postcss"` |
| `backend/app/api/v1/privacy_notice.py` | Add `/download` endpoint, HTML/PDF helpers, audit logging |
| `backend/tests/test_gujarati_pdf_rendering.py` | Fix syntax, endpoint, add validations |
| `backend/tests/test_privacy_notice_download.py` | New file — tests for `/download` endpoint |
| `frontend/app/(dashboard)/privacy-notice/page.tsx` | Add Download PDF button per version |
| `docs/v23-fix-list.md` | This file |
