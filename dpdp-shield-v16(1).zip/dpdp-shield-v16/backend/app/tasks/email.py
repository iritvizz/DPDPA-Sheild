"""Email tasks."""
from datetime import datetime, timezone

from app.tasks import celery_app
from app.utils.logging import get_logger

logger = get_logger(__name__)


@celery_app.task(bind=True, max_retries=3)
def send_email(self, to_email: str, subject: str, body: str, html_body: str = None):
    """Send transactional email via AWS SES or SMTP fallback."""
    from app.config import get_settings
    settings = get_settings()

    try:
        # Try AWS SES first
        if settings.AWS_ACCESS_KEY_ID and settings.AWS_SECRET_ACCESS_KEY:
            import boto3
            client = boto3.client(
                "ses",
                region_name=settings.AWS_REGION,
                aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
            )

            response = client.send_email(
                Source=settings.SES_FROM_EMAIL,
                Destination={"ToAddresses": [to_email]},
                Message={
                    "Subject": {"Data": subject},
                    "Body": {
                        "Text": {"Data": body},
                        "Html": {"Data": html_body or body},
                    },
                },
            )
            logger.info(f"Email sent via SES: {to_email}, MessageId={response['MessageId']}")
            return {"status": "sent", "provider": "ses", "to": to_email}

        # Fallback: log the email for development
        log_msg = "[EMAIL] To: " + to_email + "\nSubject: " + subject + "\n\n" + body
        logger.info(log_msg)
        return {"status": "logged", "provider": "none", "to": to_email}

    except Exception as exc:
        logger.error(f"Email failed: {exc}")
        raise self.retry(exc=exc, countdown=60)


@celery_app.task
def send_trial_expiry_reminder(account_id: int, days_remaining: int):
    """Send trial expiry reminder email."""
    from app.database import AsyncSessionLocal
    from sqlalchemy import select
    from app.models import Account, User

    async def _send():
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(Account).where(Account.id == account_id)
            )
            account = result.scalar_one_or_none()
            if not account:
                return

            # Find admin user
            result = await db.execute(
                select(User).where(
                    User.account_id == account_id,
                    User.role == "admin",
                )
            )
            admin = result.scalar_one_or_none()
            if not admin:
                return

            subject = f"Your DPDP Shield trial expires in {days_remaining} days"
            body = (
                "Hello,\n\n"
                f"Your DPDP Shield free trial for {account.business_name} expires in {days_remaining} days.\n\n"
                "To keep your compliance data and continue using all features, please subscribe now:\n\n"
                "https://app.dpdp-shield.in/settings/billing\n\n"
                "If you have any questions, reply to this email.\n\n"
                "— DPDP Shield Team"
            )

            send_email.delay(admin.email, subject, body)

    import asyncio
    asyncio.run(_send())


@celery_app.task
def send_account_deletion_warning(account_id: int):
    """Send 48-hour cooling-off warning before account deletion."""
    from app.database import AsyncSessionLocal
    from sqlalchemy import select
    from app.models import Account, User

    async def _send():
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(Account).where(Account.id == account_id)
            )
            account = result.scalar_one_or_none()
            if not account:
                return

            result = await db.execute(
                select(User).where(
                    User.account_id == account_id,
                    User.role == "admin",
                )
            )
            admin = result.scalar_one_or_none()
            if not admin:
                return

            subject = "URGENT: Your DPDP Shield account will be deleted in 48 hours"
            body = (
                "Hello,\n\n"
                f"You requested deletion of your DPDP Shield account for {account.business_name}.\n\n"
                "Your account and all associated data will be permanently deleted in 48 hours.\n\n"
                "If you did NOT request this deletion, or if you wish to cancel:\n\n"
                "1. Log in immediately at https://app.dpdp-shield.in\n"
                "2. Go to Settings\n"
                "3. Click \"Cancel Deletion\"\n\n"
                "After 48 hours, this action CANNOT be undone. All compliance records, "
                "data inventory, privacy notices, and consent logs will be permanently removed.\n\n"
                "— DPDP Shield Team"
            )

            send_email.delay(admin.email, subject, body)

    import asyncio
    asyncio.run(_send())


@celery_app.task
def send_staff_invitation(invitation_id: int):
    """Send staff invitation email."""
    from app.database import AsyncSessionLocal
    from sqlalchemy import select
    from app.models import Account, UserInvitation

    async def _send():
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(UserInvitation).where(UserInvitation.id == invitation_id)
            )
            invitation = result.scalar_one_or_none()
            if not invitation or invitation.used_at:
                return

            result = await db.execute(
                select(Account).where(Account.id == invitation.account_id)
            )
            account = result.scalar_one()

            subject = f"You have been invited to join {account.business_name} on DPDP Shield"
            body = (
                "Hello,\n\n"
                f"You have been invited to join {account.business_name} as a staff member on DPDP Shield.\n\n"
                "DPDP Shield helps businesses generate audit-ready proof of DPDPA compliance.\n\n"
                "Click the link below to accept your invitation and create your account:\n\n"
                f"https://app.dpdp-shield.in/invite?token={invitation.token}\n\n"
                "This invitation expires in 48 hours.\n\n"
                "— DPDP Shield Team"
            )

            send_email.delay(invitation.email, subject, body)

    import asyncio
    asyncio.run(_send())
