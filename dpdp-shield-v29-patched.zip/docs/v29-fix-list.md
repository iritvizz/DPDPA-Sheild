# DPDP Shield v29 — Fix List

## Summary

This round fixes two regressions that slipped back into v27, plus two
non-blocking items from the v28 review.

**Every claim below was verified by actually running the command against
the files in this zip before it was created** — not reconstructed from
memory, not assumed from the diff.

---

## 1. Fix: `s3_service.py::download_bytes()` reverted to v25-era bug

**What:** The method used `self.bucket_name` (does not exist — the
constructor sets `self.settings`) and `await` on synchronous boto3 calls.
This broke the malware scan flow before ClamAV was ever reached.

**Fix:**
- `self.bucket_name` → `self.settings.S3_BUCKET_TEMP`
- Removed both `await`s (boto3 client is synchronous)

**Verification:**
```
$ python -m py_compile backend/app/services/s3_service.py
$ pytest tests/test_malware_scan.py::test_scan_and_promote_flow -v
PASSED
```

**File:** `backend/app/services/s3_service.py`

---

## 2. Fix: `npm run build` fails — missing `Button` import

**What:** The dashboard layout used `<Button>` for the admin link but never
imported it.

**Fix:** Added `import { Button } from "@/components/ui/button";`.

**Verification:**
```
$ cd frontend && npm run build
...
ƒ (Dynamic)  server-rendered on demand
  / (all 19 routes)
... ✓ Compiled successfully
```
Exit code 0.

**File:** `frontend/app/(dashboard)/layout.tsx`

---

## 3. Fix: `docs/v26-fix-list.md` was missing

**What:** v27 overwrote v26-fix-list.md instead of preserving it alongside
v27-fix-list.md. The project's own docs rely on full history for review.

**Fix:** Restored from the v26 deliverable.

**File:** `docs/v26-fix-list.md`

---

## 4. Fix: Misleading middleware-order comment in `main.py`

**What:** The comment claimed WidgetCORSMiddleware "must come BEFORE" the
global CORS middleware, but the actual code order is the opposite (global
CORS first, then Widget wraps it outermost). The code was correct; the
comment was actively misleading.

**Fix:** Rewrote the comment to accurately describe the stack order.

**File:** `backend/app/main.py`

---

## 5. Hygiene: Removed cache artifacts from zip

**What:** `__pycache__/` and `.pytest_cache/` directories were included in
the delivered zip.

**Fix:** Stripped all `__pycache__`, `.pytest_cache`, and `.pyc` files
before zipping.

---

## Files changed in this round

| File | Change |
|------|--------|
| `backend/app/services/s3_service.py` | Fix `download_bytes`: sync boto3, correct bucket attr |
| `frontend/app/(dashboard)/layout.tsx` | Add `Button` import |
| `docs/v26-fix-list.md` | Restored (was deleted in v27) |
| `backend/app/main.py` | Fix middleware-order comment |
| `docs/v29-fix-list.md` | This file |
