#!/usr/bin/env python3
"""Start the Celery worker for DPDP Shield background tasks.

Usage:
    cd backend
    python scripts/start_celery_worker.py

Or directly:
    cd backend
    celery -A app.tasks.celery_app worker --loglevel=info --concurrency=4

Before running:
1. Ensure Redis is reachable (CELERY_BROKER_URL in .env).
2. Ensure the database is migrated (`alembic upgrade head`).
3. For malware scanning: ensure clamd is running (`systemctl start clamav-daemon`).
4. For email: ensure AWS SES credentials are configured.
5. For PDF generation: ensure WeasyPrint + fonts-noto-core are installed.
"""
import os
import sys
import subprocess

# Ensure backend is on path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.config import get_settings

settings = get_settings()


def check_redis():
    """Verify Redis is reachable before starting worker."""
    import redis
    try:
        r = redis.from_url(settings.REDIS_URL)
        r.ping()
        print(f"[OK] Redis reachable at {settings.REDIS_URL}")
        return True
    except Exception as exc:
        print(f"[FAIL] Redis not reachable at {settings.REDIS_URL}: {exc}")
        return False


def check_clamav():
    """Warn if ClamAV is not running."""
    import socket
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect((settings.CLAMAV_HOST, settings.CLAMAV_PORT))
        sock.close()
        print(f"[OK] ClamAV reachable at {settings.CLAMAV_HOST}:{settings.CLAMAV_PORT}")
        return True
    except Exception:
        print(f"[WARN] ClamAV NOT reachable at {settings.CLAMAV_HOST}:{settings.CLAMAV_PORT}")
        print("       Malware scanning will fall back to upload-time validation only.")
        print("       Install and start clamav-daemon before go-live.")
        return False


def main():
    print("=" * 60)
    print("DPDP Shield Celery Worker Startup")
    print("=" * 60)

    if not check_redis():
        print("\nAborting: Redis is required for Celery.")
        sys.exit(1)

    check_clamav()

    print("\nStarting Celery worker...")
    print("Tasks: email, pdf, malware_scan")
    print("Press Ctrl+C to stop.\n")

    # Start the worker
    cmd = [
        sys.executable, "-m", "celery",
        "-A", "app.tasks.celery_app",
        "worker",
        "--loglevel=info",
        "--concurrency=4",
        "-n", "worker@%h",
    ]
    subprocess.run(cmd)


if __name__ == "__main__":
    main()
