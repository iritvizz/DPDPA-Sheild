"""User management service helpers."""
import uuid

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import User, UserRole
from app.utils.enums import enum_value


async def remove_user_from_account(
    user_id: uuid.UUID,
    account_id: int,
    db: AsyncSession,
) -> str:
    """Remove a staff user from an account.

    Returns a success message. Raises HTTPException if user not found
    or if attempting to remove an admin.
    """
    result = await db.execute(
        select(User).where(
            User.public_id == user_id,
            User.account_id == account_id,
        )
    )
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if enum_value(user.role) in ("admin", "superadmin"):
        raise HTTPException(status_code=403, detail="Cannot remove admin user")

    await db.delete(user)
    await db.commit()

    return "User removed successfully"
