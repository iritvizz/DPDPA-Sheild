"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

interface Suggestion {
  field_name: string;
  suggested_category: string;
  suggested_purposes: string[];
  confidence: string;
}

interface ReviewRow extends Suggestion {
  category: string;
  purposes: string;
}

interface DataSource {
  public_id: string;
  name: string;
  source_type: string;
  status: string;
  row_count: number | null;
  column_count: number | null;
  created_at: string;
}

interface DriveFile {
  id: string;
  name: string;
  mime_type: string;
  modified_time: string | null;
}

const CATEGORIES = ["personal", "sensitive_personal", "not_personal"];

export default function InventoryPage() {
  const t = useTranslations();
  const [sources, setSources] = useState<DataSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const [pendingSourceId, setPendingSourceId] = useState<string | null>(null);
  const [reviewRows, setReviewRows] = useState<ReviewRow[]>([]);
  const [confirming, setConfirming] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const [gdriveConnected, setGdriveConnected] = useState(false);
  const [gdriveFiles, setGdriveFiles] = useState<DriveFile[]>([]);
  const [showGdriveFiles, setShowGdriveFiles] = useState(false);

  const loadSources = () => {
    setLoading(true);
    apiFetch("/api/v1/inventory/sources")
      .catch(() => [])
      .then((data) => setSources(Array.isArray(data) ? data : []))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadSources();
    const params = new URLSearchParams(window.location.search);
    if (params.get("gdrive") === "success") {
      setGdriveConnected(true);
      loadGdriveFiles();
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, []);

  const handleFile = async (file: File) => {
    setUploading(true);
    setError("");
    setSuccess("");
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await apiFetch("/api/v1/inventory/sources/parse-headers", {
        method: "POST",
        body: formData,
      });
      setPendingSourceId(res.data_source_id);
      setReviewRows(
        res.suggestions.map((s: Suggestion) => ({
          ...s,
          category: s.suggested_category,
          purposes: s.suggested_purposes.join(", "),
        }))
      );
    } catch (err: any) {
      setError(err.message || "Failed to process file.");
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  async function connectGoogleDrive() {
    try {
      const data = await apiFetch("/api/v1/inventory/google-drive/connect", { method: "POST" });
      window.location.href = data.message;
    } catch (err: any) {
      setError(err.message || "Failed to connect Google Drive");
    }
  }

  async function loadGdriveFiles() {
    try {
      const data = await apiFetch("/api/v1/inventory/google-drive/files");
      setGdriveFiles(data);
      setShowGdriveFiles(true);
    } catch (err: any) {
      setError(err.message || "Failed to load Drive files");
    }
  }

  async function disconnectGoogleDrive() {
    try {
      await apiFetch("/api/v1/inventory/google-drive/disconnect", { method: "POST" });
      setGdriveConnected(false);
      setGdriveFiles([]);
      setShowGdriveFiles(false);
    } catch (err: any) {
      setError(err.message || "Failed to disconnect");
    }
  }

  async function parseDriveFile(fileId: string, filename: string) {
    setUploading(true);
    setError("");
    setSuccess("");
    try {
      const res = await apiFetch(`/api/v1/inventory/google-drive/${fileId}/parse`, {
        method: "POST",
      });
      setPendingSourceId(res.data_source_id);
      setReviewRows(
        res.suggestions.map((s: Suggestion) => ({
          ...s,
          category: s.suggested_category,
          purposes: s.suggested_purposes.join(", "),
        }))
      );
    } catch (err: any) {
      setError(err.message || "Failed to parse Drive file.");
    } finally {
      setUploading(false);
    }
  }

  const updateRow = (index: number, field: "category" | "purposes", value: string) => {
    setReviewRows((rows) =>
      rows.map((r, i) => (i === index ? { ...r, [field]: value } : r))
    );
  };

  const handleConfirm = async () => {
    if (!pendingSourceId) return;
    setConfirming(true);
    setError("");
    try {
      await apiFetch(`/api/v1/inventory/sources/${pendingSourceId}/elements`, {
        method: "POST",
        body: JSON.stringify({
          elements: reviewRows.map((r) => ({
            field_name: r.field_name,
            data_category: r.category,
            purposes: r.purposes.split(",").map((p) => p.trim()).filter(Boolean),
          })),
        }),
      });
      setSuccess("Data inventory confirmed.");
      setPendingSourceId(null);
      setReviewRows([]);
      loadSources();
    } catch (err: any) {
      setError(err.message || "Failed to confirm elements.");
    } finally {
      setConfirming(false);
    }
  };

  const handleDeleteSource = async (id: string) => {
    setError("");
    try {
      await apiFetch(`/api/v1/inventory/sources/${id}`, { method: "DELETE" });
      loadSources();
    } catch (err: any) {
      setError(err.message || "Failed to delete source.");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{t("inventory.title")}</h2>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {success && (
        <Alert>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {!pendingSourceId ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>{t("inventory.uploadFile")}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">{t("inventory.fileTypes")}</p>
              <div
                className={`mt-4 border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                  isDragging ? "border-blue-400 bg-blue-50" : "border-gray-300"
                }`}
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
              >
                {uploading ? (
                  <p className="text-gray-500">Processing file...</p>
                ) : (
                  <>
                    <p className="text-gray-400 mb-3">{t("inventory.dragDrop")}</p>
                    <input
                      type="file"
                      accept=".csv,.xlsx,.xls"
                      onChange={handleFileInput}
                      className="mx-auto text-sm"
                    />
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("inventory.googleDrive")}</CardTitle>
            </CardHeader>
            <CardContent>
              {!gdriveConnected ? (
                <Button onClick={connectGoogleDrive}>
                  {t("inventory.connectGoogleDrive")}
                </Button>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-green-600 text-sm font-medium">✓ {t("inventory.gdriveConnected")}</span>
                    <Button variant="outline" size="sm" onClick={disconnectGoogleDrive}>
                      {t("inventory.disconnect")}
                    </Button>
                  </div>
                  {showGdriveFiles && (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      <p className="text-sm text-gray-500">{t("inventory.selectFile")}</p>
                      {gdriveFiles.map((file) => (
                        <div
                          key={file.id}
                          className="flex items-center justify-between p-2 border rounded hover:bg-gray-50 cursor-pointer"
                          onClick={() => parseDriveFile(file.id, file.name)}
                        >
                          <span className="text-sm">{file.name}</span>
                          <span className="text-xs text-gray-400">{file.mime_type}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Review Classification</CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left border-b">
                  <th className="pb-2">Field</th>
                  <th className="pb-2">Category</th>
                  <th className="pb-2">Purposes</th>
                  <th className="pb-2">Confidence</th>
                </tr>
              </thead>
              <tbody>
                {reviewRows.map((row, i) => (
                  <tr key={row.field_name} className="border-b">
                    <td className="py-2 font-medium">{row.field_name}</td>
                    <td className="py-2">
                      <select
                        className="border rounded px-2 py-1"
                        value={row.category}
                        onChange={(e) => updateRow(i, "category", e.target.value)}
                      >
                        {CATEGORIES.map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </td>
                    <td className="py-2">
                      <input
                        className="border rounded px-2 py-1 w-full"
                        value={row.purposes}
                        onChange={(e) => updateRow(i, "purposes", e.target.value)}
                      />
                    </td>
                    <td className="py-2">
                      <Badge variant="secondary">{row.confidence}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="flex gap-2 mt-4">
              <Button onClick={handleConfirm} disabled={confirming}>
                {confirming ? "Confirming..." : "Confirm & Save"}
              </Button>
              <Button variant="outline" onClick={() => { setPendingSourceId(null); setReviewRows([]); }}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Data Sources</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : sources.length === 0 ? (
            <p className="text-gray-500">No data sources yet.</p>
          ) : (
            <div className="space-y-2">
              {sources.map((s) => (
                <div key={s.public_id} className="flex items-center justify-between border-b pb-2">
                  <div>
                    <p className="font-medium">{s.name}</p>
                    <p className="text-sm text-gray-500">
                      {s.row_count ?? 0} rows · {s.column_count ?? 0} columns
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={s.status === "confirmed" ? "default" : "secondary"}>
                      {s.status}
                    </Badge>
                    <Button size="sm" variant="outline" onClick={() => handleDeleteSource(s.public_id)}>
                      Delete
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
