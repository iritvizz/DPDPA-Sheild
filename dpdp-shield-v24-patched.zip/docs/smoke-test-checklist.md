# DPDP Shield — Production Smoke Test Checklist

**Environment:** Production (AWS Mumbai, ap-south-1)  
**Executed by:** _______________  
**Date:** _______________  
**Result:** PASS / FAIL (circle one)

---

## Pre-conditions

- [ ] `docker-compose up -d` completed without errors
- [ ] `alembic upgrade head` completed without errors
- [ ] `pytest tests/ -v` passed (all 50+ tests)
- [ ] `npm run build` exits 0 (frontend production build must succeed)
- [ ] `pip-audit` shows zero critical/high vulnerabilities
- [ ] `npm audit` shows zero critical/high vulnerabilities
- [ ] SSL certificates valid on both domains
- [ ] CloudWatch log streams active

---

## Tier 1 Critical Path (Must All Pass)

### Auth & Onboarding

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 1.1 | Navigate to signup page | Page loads, no console errors | | |
| 1.2 | Register with email + password | Account created, redirected to dashboard | | |
| 1.3 | Check email for welcome | Welcome email received (or queued in Celery) | | |
| 1.4 | Login with credentials | JWT token returned, dashboard loads | | |
| 1.5 | Click "Forgot Password" | Always shows success (no enumeration) | | |
| 1.6 | Receive reset email, click link | Reset page loads with valid token | | |
| 1.7 | Enter new password, submit | Login with new password succeeds | | |
| 1.8 | Login with old password | Returns 401, "Invalid credentials" | | |

### Dashboard & Settings

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 2.1 | Dashboard loads | Compliance score shows "X of 5 complete" | | |
| 2.2 | "Get Started" checklist visible | 3 steps: Add Data Source, Generate Notice, Log Consent | | |
| 2.3 | Settings page loads | Business details editable, i18n works (EN/HI/GU) | | |
| 2.4 | Update business name | Saved, reflected in privacy notice preview | | |
| 2.5 | Configure grievance contact | Email/phone saved, appears in notice template | | |
| 2.6 | Invite staff user | Invitation sent, staff can login with limited permissions | | |
| 2.7 | Delete account (test account) | 48-hour cooling-off initiated, email sent | | |

### Data Inventory

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 3.1 | Click "Add Data Source" → Upload | File picker opens, accepts .csv/.xlsx | | |
| 3.2 | Upload valid CSV | Suggestions table appears within 5 seconds | | |
| 3.3 | Review suggestions, edit category | Dropdown works, purposes editable | | |
| 3.4 | Click "Confirm & Save" | Source status = "confirmed", appears in list | | |
| 3.5 | Upload file > 25MB | Error: "File too large. Max size: 25MB" | | |
| 3.6 | Upload invalid file (e.g., .exe renamed .csv) | Error: "Unsupported file type" | | |
| 3.7 | Upload empty file | Error: "File appears to be empty" | | |
| 3.8 | Verify purge log in AuditLog | `event_type="file_purge_verified"` exists | | |
| 3.9 | Connect Google Drive | OAuth redirect works, file list loads | | |
| 3.10 | Select Drive file | Same review flow as direct upload | | |
| 3.11 | Disconnect Google Drive | "Disconnected" message, files hidden | | |
| 3.12 | Delete a data source | Confirmation modal, then removed from list | | |

### Privacy Notice

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 4.1 | Select "E-commerce" template | Sections pre-filled from inventory | | |
| 4.2 | Edit a section | Live preview updates | | |
| 4.3 | Switch language to Gujarati | Gujarati text renders correctly (no boxes) | | |
| 4.4 | Click "Publish" | Status = "published", version increments | | |
| 4.5 | View version history | Previous versions listed, clickable | | |
| 4.6 | Restore old version | New version created with old content, auto-published | | |
| 4.7 | Download as PDF | PDF downloads, Gujarati glyphs correct | | |
| 4.8 | Copy embed code | Iframe snippet copied, works on test HTML page | | |
| 4.9 | Visit public notice page | `notice.dpdp-shield.in/{slug}` loads, no auth needed | | |
| 4.10 | Public page on mobile | Responsive, readable | | |

### Consent Management

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 5.1 | Log manual consent | Record appears in table with timestamp | | |
| 5.2 | Upload proof file (PNG) | File accepted, pre-signed URL generated | | |
| 5.3 | Upload proof file (renamed .exe) | Rejected: MIME validation failed | | |
| 5.4 | Revoke consent | Status = "revoked", timestamp recorded | | |
| 5.5 | Generate withdrawal link | UUID token created, link copyable | | |
| 5.6 | Visit withdrawal page | `withdrawal.dpdp-shield.in/{token}` shows confirmation | | |
| 5.7 | Copy widget embed code | Script tag copied, works on external test page | | |
| 5.8 | Widget POST to `/widget/capture` | CORS allowed, consent recorded | | |
| 5.9 | Export consent log | CSV/PDF downloads with correct records | | |

### Subscription

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 6.1 | New account trial countdown | Dashboard shows "14 days remaining" | | |
| 6.2 | Click "Subscribe" | Razorpay checkout modal opens | | |
| 6.3 | Complete payment | Webhook received, status = "active" | | |
| 6.4 | Cancel subscription | Access continues until period end | | |
| 6.5 | Trial expiry warning (3 days before) | Email reminder received | | |

---

## Tier 2 Fast-Follow (Should Pass for Complete Product)

### DSAR

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 7.1 | Create DSAR ticket | Ticket appears in list with "pending" status | | |
| 7.2 | Mark "In Progress" | Status updates, action log records the change | | |
| 7.3 | Select response template | Template text populates response field | | |
| 7.4 | Save response | Response stored, ticket shows "fulfilled" | | |
| 7.5 | Add action note | Note appears in action log timeline | | |
| 7.6 | Deadline alert (within 7 days) | Dashboard alert visible | | |

### Retention & Deletion

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 8.1 | View upcoming expiries | List shows fields with < 90 days remaining | | |
| 8.2 | Record deletion attestation | Modal warns "this is attestation, not verification" | | |
| 8.3 | Submit attestation | Log entry created, appears in deletion log | | |
| 8.4 | Verify audit log entry | `event_type="deletion_attestation"` in AuditLog | | |

### Reports

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 9.1 | View monthly summary | Counts accurate, month label correct | | |
| 9.2 | Generate audit pack | Status = "queued", then "completed" after poll | | |
| 9.3 | Download completed audit pack | Pre-signed URL works, PDF contains all modules | | |
| 9.4 | Verify audit pack contents | Cover page, inventory, notice, consent log, DSAR, deletion log | | |

### Admin Panel

| # | Step | Expected Result | Actual | Pass/Fail |
|---|---|---|---|---|
| 10.1 | Superadmin views analytics | Total accounts, MRR, activation rate displayed | | |
| 10.2 | Suspend an account | Account cannot login, data retained | | |
| 10.3 | Activate suspended account | Account can login again | | |
| 10.4 | Impersonate an account | Token issued, dashboard loads as target user | | |
| 10.5 | Verify impersonation audit log | `event_type="admin_impersonation"` recorded | | |
| 10.6 | Non-superadmin accesses /admin | 403 or redirect to dashboard | | |

---

## Cross-Cutting Checks

| # | Check | Expected | Actual | Pass/Fail |
|---|---|---|---|---|
| 11.1 | All API responses use `public_id` | Never see raw `id: int` in JSON | | |
| 11.2 | Rate limiting active | 429 after 100 req/min per user | | |
| 11.3 | CORS on widget endpoint | `Access-Control-Allow-Origin: *` for `/widget/capture` | | |
| 11.4 | HSTS header | `Strict-Transport-Security: max-age=31536000` | | |
| 11.5 | No PII in application logs | grep for email/phone patterns in CloudWatch → zero hits | | |
| 11.6 | Database backup snapshot | Manual snapshot created, restorable | | |
| 11.7 | S3 bucket policies | Both buckets private, proof bucket encrypted | | |

---

## Sign-off

| Role | Name | Date | Signature |
|---|---|---|---|
| QA Lead | | | |
| Security Reviewer | | | |
| Product Owner | | | |

**Overall Result:** PASS / FAIL

If FAIL: List blocking items below, fix, and re-run checklist.
