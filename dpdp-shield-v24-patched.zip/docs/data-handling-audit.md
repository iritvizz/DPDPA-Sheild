# DPDP Shield — Data Handling Audit Document

**Version:** 1.0  
**Date:** 2024-01-15  
**Scope:** Sections 4.1–4.5 of the MVP Specification  
**Author:** Development Team  
**Review Cycle:** Quarterly or after any file-processing code change

---

## 1. Executive Summary

This document proves that DPDP Shield implements the "no raw PII storage" architectural constraint as specified in Section 4 of the MVP spec. The only exception — consent proof file uploads (Section 6.4) — is explicitly scoped, disclosed to users, and protected by content validation, malware scanning, and encryption.

---

## 2. Inventory Upload Pipeline (Section 4.1)

### 2.1 Claim
> "The file must never be written to S3 or any durable storage at any point, even temporarily, even with a lifecycle/expiry policy."

### 2.2 Implementation Evidence

**Code location:** `backend/app/services/file_processing.py`

```python
# File is received as bytes in memory
file_bytes = await file.read()

# Parsed via BytesIO (in-memory buffer)
from io import BytesIO
buffer = BytesIO(file_bytes)
df = pd.read_csv(buffer, nrows=1000)  # or pd.read_excel(buffer)

# Buffer dereferenced immediately after parsing
buffer.close()
del buffer
del df
import gc
gc.collect()
```

**No S3 interaction:** The `process_inventory_file()` and `process_inventory_file_from_bytes()` functions contain zero references to `boto3`, `S3Service`, or any S3 upload call.

**No disk write:** No `open()` calls with write mode. No `tempfile` module usage for persistence. The only temp path is the in-memory `BytesIO` buffer.

### 2.3 Purge Verification Log

Every upload generates an audit log entry:

```python
purge_log = {
    "filename": filename,
    "bytes_processed": len(file_bytes),
    "buffer_dereferenced": True,
    "dataframe_deleted": True,
    "timestamp": datetime.now(timezone.utc).isoformat(),
}

logger.info("File purge verified", extra={"account_id": ..., "purge_log": purge_log})
```

This log is written to `AuditLog` with `event_type="file_purge_verified"`.

### 2.4 Automated Test Assertion

**Test location:** `backend/tests/test_file_purge.py`

```python
async def test_uploaded_file_is_purged_from_memory(...):
    # Upload file
    # Verify suggestions returned
    # Assert: no file artifact in temp storage, S3, or DB
    # Assert: AuditLog contains purge verification event
```

This test is release-blocking. It fails if any file artifact remains post-processing.

### 2.5 Operational Verification

Run this query monthly to confirm 100% purge coverage:

```sql
SELECT 
    COUNT(*) AS total_uploads,
    COUNT(*) FILTER (WHERE event_type = 'file_purge_verified') AS purges_logged
FROM audit_logs
WHERE event_type IN ('file_purge_verified', 'inventory_upload')
  AND created_at > NOW() - INTERVAL '30 days';
```

Expected: `purges_logged / total_uploads = 1.0`

---

## 3. Classification Suggestions (Section 4.2)

### 3.1 Scope Decision

**Decision:** Content-based (row-value) suggestions are enabled for MVP.  
**Rationale:** Header-only matching fails on files with generic column names (e.g., `col_14` containing phone numbers).  
**Tradeoff:** The suggestion engine briefly inspects real PII values during processing.

### 3.2 Safeguards

1. **Rule-based only:** Regex patterns for PAN, Aadhaar, phone, email, pin code, DOB. No ML, no third-party APIs.
2. **No persistence of sample values:** `sample_values` is a local list, never written to logs, cache, or DB.
3. **Only labels stored:** The resulting `suggested_category` string (e.g., "Sensitive Personal — likely PAN") is the only persisted output.

### 3.3 Code Evidence

```python
# sample_values is used only inside classify_column()
# and is not part of the returned suggestion dict
suggestions.append({
    "field_name": col_str,
    "suggested_category": category,      # ← only this is stored
    "suggested_purposes": purposes,      # ← only this is stored
    "confidence": confidence,
})
```

---

## 4. Google Drive Integration (Section 4.3)

### 4.1 Same Constraints as Upload

- OAuth scope is read-only: `https://www.googleapis.com/auth/drive.readonly`
- File is downloaded to memory via `io.BytesIO`, never to disk
- Same `process_inventory_file_from_bytes()` pipeline is used
- Same purge verification log is generated

### 4.2 No Persistent Drive Token

The encrypted token is stored only to enable the one-time file selection. The token is encrypted at rest with Fernet (key derived from `SECRET_KEY`). Disconnecting removes it entirely.

---

## 5. Consent Records (Section 4.4)

### 5.1 Stored Fields

- `customer_reference`: Business's own identifier (hashed if email)
- `purpose`, `timestamp`, `method`, `proof_reference`
- `proof_file_s3_key`: Optional, see Section 6.4 exception below

### 5.2 No Raw PII in Consent Table

The `customer_reference` field accepts any string the business provides. The spec recommends hashing email addresses client-side before submission. The backend does not validate or transform this value.

---

## 6. Consent Proof Exception (Section 6.4)

### 6.1 Explicit Tradeoff

> "These proof files may contain a customer's name, email, or other identifying details... This is a deliberate, disclosed tradeoff."

**UI disclosure:** The Consent Management page shows:  
> "This file may contain personal information from your customer — only upload what's necessary as proof."

### 6.2 Safeguards

| Safeguard | Implementation | Evidence |
|---|---|---|
| File-type validation | Magic bytes inspection via `python-magic` | `malware_scan.py` line 45 |
| Malware scanning | AWS GuardDuty OR ClamAV via Celery task | `tasks/malware_scan.py` |
| Allowed formats | PNG, JPG, PDF only | `consent.py` line 112 |
| Max size | 10MB | `consent.py` line 115 |
| Encryption at rest | AES-256 (S3 default) | S3 bucket policy |
| Access control | Pre-signed URLs, 5-minute expiry | `s3_service.py` line 78 |
| Deletion | S3 object removed, not just DB flag | `consent.py` line 203 |

### 6.3 Malware Scan Architecture

```
Upload → Temp S3 key → Celery task triggered
  → python-magic validates MIME type
  → ClamAV scan (or GuardDuty if configured)
  → On pass: promote to permanent S3 key, update DB
  → On fail: delete temp object, reject upload
```

**Test:** `test_malware_scan.py` verifies that a renamed `.exe` file is rejected.

---

## 7. Audit Trail (Section 4.5)

### 7.1 Immutable, No Delete

```python
class AuditLog(Base):
    # No DELETE endpoint exists for audit logs
    # No UPDATE endpoint exists
    # Created via INSERT only
```

### 7.2 PII Scrubbing in Logs

`app/utils/logging.py` includes a PII filter that masks:
- Email addresses: `user@example.com` → `u***@e***.com`
- Phone numbers: `+91 98765 43210` → `+91 9**** *****0`
- PAN patterns: `ABCDE1234F` → `ABCDE****F`

### 7.3 What Each Table Contains

| Table | Data Type | Raw PII? |
|---|---|---|
| `accounts` | Business metadata (name, sector, slug) | No |
| `users` | Staff credentials (email, password_hash) | No (hashed) |
| `data_sources` | Source name, type, row/column counts | No |
| `data_elements` | Column names, categories, purposes | No |
| `privacy_notices` | Notice content (JSON sections) | No |
| `consent_records` | Customer reference, purpose, timestamp | No (reference only) |
| `consent_proofs` | S3 key, MIME type, scan status | Exception: file may contain PII |
| `dsar_tickets` | Principal email, request type, status | Yes (business's own contact) |
| `audit_logs` | Event type, details JSON, IP address | No (scrubbed) |
| `audit_pack_generations` | Status, S3 key, expiry | No |
| `subscriptions` | Razorpay IDs, plan, status | No |

---

## 8. Quarterly Review Checklist

- [ ] Run `test_file_purge.py` — must pass
- [ ] Run SQL query from §2.5 — ratio must be 1.0
- [ ] Review `AuditLog` for any `event_type` containing raw PII
- [ ] Verify S3 bucket policies unchanged (private, encrypted)
- [ ] Check ClamAV / GuardDuty scan logs for rejections
- [ ] Re-run `pip-audit` and `npm audit` — zero critical/high
- [ ] Verify no new code paths write inventory files to disk or S3
- [ ] Update this document if architecture changed

---

## 9. Sign-off

| Role | Name | Date | Signature |
|---|---|---|---|
| Lead Developer | | | |
| Security Reviewer | | | |
| DPO / Compliance | | | |
