"""Dashboard routes."""
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import (
    Account,
    AuditLog,
    ConsentRecord,
    DataSource,
    PrivacyNotice,
    User,
)
from app.schemas import (
    ComplianceChecklistItem,
    DashboardActivityResponse,
    DashboardSummaryResponse,
    ActivityItem,
)
from app.utils.auth import get_current_active_user
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/dashboard", tags=["dashboard"])

# Compliance checklist configuration (tunable without touching code)
COMPLIANCE_CHECKLIST = [
    {"key": "inventory", "label": "Data Inventory completed (at least one data source with mapped fields)"},
    {"key": "privacy_notice", "label": "Privacy Notice published (at least one version published)"},
    {"key": "consent", "label": "Consent records active (at least one consent logged)"},
    {"key": "grievance", "label": "Grievance contact configured"},
    {"key": "ropa", "label": "RoPA generated"},
]


@router.get("/summary", response_model=DashboardSummaryResponse)
async def get_dashboard_summary(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get dashboard summary with compliance checklist."""
    account_id = current_user.account_id

    # Check inventory
    result = await db.execute(
        select(func.count(DataSource.id))
        .where(
            DataSource.account_id == account_id,
            DataSource.status == "confirmed",
        )
    )
    inventory_count = result.scalar() or 0

    # Check published notice
    result = await db.execute(
        select(func.count(PrivacyNotice.id))
        .where(
            PrivacyNotice.account_id == account_id,
            PrivacyNotice.is_published == True,
        )
    )
    published_notice = (result.scalar() or 0) > 0

    # Check consent records
    result = await db.execute(
        select(func.count(ConsentRecord.id))
        .where(ConsentRecord.account_id == account_id)
    )
    consent_count = result.scalar() or 0

    # Check grievance contact
    result = await db.execute(
        select(Account).where(Account.id == account_id)
    )
    account = result.scalar_one()
    grievance_configured = bool(account.grievance_email or account.grievance_phone)

    # Check if RoPA has been generated (via audit log)
    result = await db.execute(
        select(func.count(AuditLog.id))
        .where(
            AuditLog.account_id == account_id,
            AuditLog.event_type == "ropa_generated",
        )
    )
    ropa_generated = (result.scalar() or 0) > 0

    # Build checklist
    checklist = [
        ComplianceChecklistItem(
            key="inventory",
            label=COMPLIANCE_CHECKLIST[0]["label"],
            completed=inventory_count > 0,
        ),
        ComplianceChecklistItem(
            key="privacy_notice",
            label=COMPLIANCE_CHECKLIST[1]["label"],
            completed=published_notice,
        ),
        ComplianceChecklistItem(
            key="consent",
            label=COMPLIANCE_CHECKLIST[2]["label"],
            completed=consent_count > 0,
        ),
        ComplianceChecklistItem(
            key="grievance",
            label=COMPLIANCE_CHECKLIST[3]["label"],
            completed=grievance_configured,
        ),
        ComplianceChecklistItem(
            key="ropa",
            label=COMPLIANCE_CHECKLIST[4]["label"],
            completed=ropa_generated,
        ),
    ]

    completed_count = sum(1 for item in checklist if item.completed)

    # Trial days remaining
    trial_days = None
    if account.status.value == "trial" and account.trial_ends_at:
        trial_days = max(0, (account.trial_ends_at - datetime.now(timezone.utc)).days)

    return DashboardSummaryResponse(
        compliance_checklist=checklist,
        completed_count=completed_count,
        total_count=len(checklist),
        data_sources_count=inventory_count,
        consent_records_count=consent_count,
        published_notice=published_notice,
        trial_days_remaining=trial_days,
        subscription_status=account.status.value,
    )


@router.get("/activity", response_model=DashboardActivityResponse)
async def get_recent_activity(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get last 10 activities for the account."""
    result = await db.execute(
        select(AuditLog, User)
        .outerjoin(User, AuditLog.user_id == User.id)
        .where(AuditLog.account_id == current_user.account_id)
        .order_by(AuditLog.created_at.desc())
        .limit(10)
    )

    activities = []
    for audit_log, user in result.all():
        activities.append(ActivityItem(
            event_type=audit_log.event_type,
            description=audit_log.event_details.get("description", "Activity recorded"),
            created_at=audit_log.created_at,
            user_name=user.full_name if user else None,
        ))

    return DashboardActivityResponse(activities=activities)
