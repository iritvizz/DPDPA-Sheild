"""SQLAlchemy models for DPDP Shield."""
import uuid
from datetime import datetime, timezone
from enum import Enum as PyEnum
from typing import List, Optional

from sqlalchemy import (
    BigInteger, Boolean, DateTime, ForeignKey, Integer, String, Text, func, UniqueConstraint, Index
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship, validates

from app.database import Base


class AccountStatus(str, PyEnum):
    TRIAL = "trial"
    ACTIVE = "active"
    EXPIRED = "expired"
    SUSPENDED = "suspended"
    DELETED = "deleted"


class UserRole(str, PyEnum):
    ADMIN = "admin"
    STAFF = "staff"
    SUPERADMIN = "superadmin"


class DataSourceType(str, PyEnum):
    UPLOAD = "upload"
    DRIVE = "drive"
    MANUAL = "manual"


class DataSourceStatus(str, PyEnum):
    DRAFT = "draft"
    CONFIRMED = "confirmed"


class DataCategory(str, PyEnum):
    PERSONAL = "personal"
    SENSITIVE_PERSONAL = "sensitive_personal"
    NOT_PERSONAL = "not_personal"


class ConsentMethod(str, PyEnum):
    WEBSITE_CHECKBOX = "website_checkbox"
    PHYSICAL_FORM = "physical_form"
    VERBAL = "verbal"
    EMAIL_CONFIRMATION = "email_confirmation"
    SMS_OTP = "sms_otp"
    OTHER = "other"


class SubscriptionStatus(str, PyEnum):
    TRIAL = "trial"
    ACTIVE = "active"
    CANCELLED = "cancelled"
    PAST_DUE = "past_due"


class Account(Base):
    __tablename__ = "accounts"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    public_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), default=uuid.uuid4, unique=True, nullable=False, index=True
    )
    business_name: Mapped[str] = mapped_column(String(255), nullable=False)
    business_slug: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    sector: Mapped[str] = mapped_column(String(100), nullable=False)
    employee_count_bracket: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    turnover_bracket: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    # Grievance contact
    grievance_email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    grievance_phone: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    grievance_address: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Subscription
    status: Mapped[AccountStatus] = mapped_column(
        String(20), default=AccountStatus.TRIAL, nullable=False
    )
    trial_ends_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Widget nonce secret for consent widget integrity
    widget_nonce_secret: Mapped[str] = mapped_column(String(64), nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    deletion_task_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    # Relationships
    google_drive_connection: Mapped[Optional["GoogleDriveConnection"]] = relationship(
        "GoogleDriveConnection", back_populates="account", uselist=False, cascade="all, delete-orphan"
    )

    users: Mapped[List["User"]] = relationship("User", back_populates="account", cascade="all, delete-orphan")
    data_sources: Mapped[List["DataSource"]] = relationship("DataSource", back_populates="account", cascade="all, delete-orphan")
    privacy_notices: Mapped[List["PrivacyNotice"]] = relationship("PrivacyNotice", back_populates="account", cascade="all, delete-orphan")
    consent_records: Mapped[List["ConsentRecord"]] = relationship("ConsentRecord", back_populates="account", cascade="all, delete-orphan")
    dsar_requests: Mapped[List["DSARRequest"]] = relationship("DSARRequest", back_populates="account", cascade="all, delete-orphan")
    subscriptions: Mapped[List["Subscription"]] = relationship("Subscription", back_populates="account", cascade="all, delete-orphan")
    audit_logs: Mapped[List["AuditLog"]] = relationship("AuditLog", back_populates="account")

    @validates("business_slug")
    def validate_slug(self, key, slug):
        return slug.lower().strip().replace(" ", "-")


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    public_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), default=uuid.uuid4, unique=True, nullable=False, index=True
    )
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False, index=True)
    email: Mapped[str] = mapped_column(String(255), nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    password_hash: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    full_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    role: Mapped[UserRole] = mapped_column(String(20), default=UserRole.ADMIN, nullable=False)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    account: Mapped["Account"] = relationship("Account", back_populates="users")
    audit_logs: Mapped[List["AuditLog"]] = relationship("AuditLog", back_populates="user")

    __table_args__ = (
        UniqueConstraint("account_id", "email", name="uq_user_account_email"),
    )


class UserInvitation(Base):
    __tablename__ = "user_invitations"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False, index=True)
    email: Mapped[str] = mapped_column(String(255), nullable=False)
    token: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    role: Mapped[UserRole] = mapped_column(String(20), default=UserRole.STAFF, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )


class DataSource(Base):
    __tablename__ = "data_sources"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    source_type: Mapped[DataSourceType] = mapped_column(String(20), nullable=False)
    status: Mapped[DataSourceStatus] = mapped_column(
        String(20), default=DataSourceStatus.DRAFT, nullable=False
    )
    row_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    column_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    account: Mapped["Account"] = relationship("Account", back_populates="data_sources")
    elements: Mapped[List["DataElement"]] = relationship(
        "DataElement", back_populates="data_source", cascade="all, delete-orphan"
    )


class DataElement(Base):
    __tablename__ = "data_elements"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    data_source_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("data_sources.id"), nullable=False, index=True)
    field_name: Mapped[str] = mapped_column(String(255), nullable=False)
    data_category: Mapped[DataCategory] = mapped_column(String(30), nullable=False)
    purposes: Mapped[List[str]] = mapped_column(ARRAY(String), default=list, nullable=False)
    legal_basis: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    retention_period_value: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    retention_period_unit: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    third_party_sharing: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    third_party_details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    data_source: Mapped["DataSource"] = relationship("DataSource", back_populates="elements")


class Purpose(Base):
    __tablename__ = "purposes"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)
    is_predefined: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class PrivacyNotice(Base):
    __tablename__ = "privacy_notices"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False, index=True)
    template_type: Mapped[str] = mapped_column(String(50), nullable=False)
    content: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    published_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    account: Mapped["Account"] = relationship("Account", back_populates="privacy_notices")

    __table_args__ = (
        UniqueConstraint("account_id", "version", name="uq_notice_account_version"),
    )


class ConsentRecord(Base):
    __tablename__ = "consent_records"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    public_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), default=uuid.uuid4, unique=True, nullable=False, index=True
    )
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False, index=True)
    customer_reference: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    purpose: Mapped[str] = mapped_column(String(100), nullable=False)
    consent_timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    method: Mapped[ConsentMethod] = mapped_column(String(30), nullable=False)
    proof_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    proof_file_s3_key: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    proof_file_status: Mapped[str] = mapped_column(
        String(20), default="none", nullable=False
    )  # none, pending, clean, quarantined
    is_revoked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    withdrawal_token: Mapped[Optional[str]] = mapped_column(String(255), unique=True, nullable=True, index=True)
    consent_expiry: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    account: Mapped["Account"] = relationship("Account", back_populates="consent_records")

    __table_args__ = (
        Index("ix_consent_account_customer", "account_id", "customer_reference"),
    )


class Subscription(Base):
    __tablename__ = "subscriptions"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False, index=True)
    razorpay_subscription_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    razorpay_customer_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    plan_id: Mapped[str] = mapped_column(String(100), default="dpdp-shield-pro", nullable=False)
    status: Mapped[SubscriptionStatus] = mapped_column(
        String(20), default=SubscriptionStatus.TRIAL, nullable=False
    )
    current_period_start: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    current_period_end: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    account: Mapped["Account"] = relationship("Account", back_populates="subscriptions")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    account_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=True, index=True)
    user_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=True, index=True)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    event_details: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    account: Mapped[Optional["Account"]] = relationship("Account", back_populates="audit_logs")
    user: Mapped[Optional["User"]] = relationship("User", back_populates="audit_logs")


class AuditPackGeneration(Base):
    __tablename__ = "audit_pack_generations"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False, index=True)
    requested_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending", nullable=False)
    file_s3_key: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)


class DSARType(str, PyEnum):
    ACCESS = "access"
    CORRECTION = "correction"
    DELETION = "deletion"
    PORTABILITY = "portability"


class DSARStatus(str, PyEnum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    FULFILLED = "fulfilled"
    REJECTED = "rejected"


class DSARRequest(Base):
    """Data Subject Access Request ticket (DPDPA Section 12) -- business-facing
    ticketing only, no customer-facing self-service portal, per spec."""
    __tablename__ = "dsar_requests"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    public_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), default=uuid.uuid4, unique=True, nullable=False, index=True
    )
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), nullable=False, index=True)
    principal_email: Mapped[str] = mapped_column(String(255), nullable=False)
    principal_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    principal_phone: Mapped[Optional[str]] = mapped_column(String(30), nullable=True)
    request_type: Mapped[DSARType] = mapped_column(String(20), nullable=False)
    status: Mapped[DSARStatus] = mapped_column(String(20), default=DSARStatus.PENDING.value, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    response_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    responded_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    responded_by_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    account: Mapped["Account"] = relationship("Account", back_populates="dsar_requests")

    __table_args__ = (
        Index("ix_dsar_account_status", "account_id", "status"),
    )


class DSARActionLog(Base):
    __tablename__ = "dsar_action_logs"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    dsar_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("dsar_requests.id"), nullable=False, index=True)
    action_text: Mapped[str] = mapped_column(Text, nullable=False)
    performed_by_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("users.id"), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    dsar: Mapped["DSARRequest"] = relationship("DSARRequest", back_populates="actions")
    performed_by: Mapped[Optional["User"]] = relationship("User")


class GoogleDriveConnection(Base):
    __tablename__ = "google_drive_connections"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    account_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("accounts.id"), unique=True, nullable=False)
    encrypted_token_json: Mapped[str] = mapped_column(Text, nullable=False)
    connected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    last_sync_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    account: Mapped["Account"] = relationship("Account", back_populates="google_drive_connection")


class DSARTemplate(Base):
    __tablename__ = "dsar_templates"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    request_type: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    language: Mapped[str] = mapped_column(String(5), nullable=False, index=True)
    subject_template: Mapped[str] = mapped_column(Text, nullable=False)
    body_template: Mapped[str] = mapped_column(Text, nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

