"""Logging utilities with PII scrubbing."""
import logging
import re
from typing import Optional

# Patterns for common PII
PII_PATTERNS = [
    (re.compile(r'[A-Z]{5}[0-9]{4}[A-Z]'), '[PAN]'),  # PAN
    (re.compile(r'\d{4}\s?\d{4}\s?\d{4}'), '[AADHAAR]'),  # Aadhaar (12 digits)
    (re.compile(r'\d{10}'), '[PHONE]'),  # 10-digit phone
    (re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}'), '[EMAIL]'),  # Email
    (re.compile(r'\d{6}'), '[PINCODE]'),  # 6-digit pincode
]


def scrub_pii(text: str) -> str:
    """Scrub PII from log messages."""
    if not text:
        return text

    scrubbed = text
    for pattern, replacement in PII_PATTERNS:
        scrubbed = pattern.sub(replacement, scrubbed)

    return scrubbed


class PIIScrubbingFilter(logging.Filter):
    """Logging filter that scrubs PII from log records."""

    def filter(self, record: logging.LogRecord) -> bool:
        if hasattr(record, 'msg') and isinstance(record.msg, str):
            record.msg = scrub_pii(record.msg)
        if hasattr(record, 'args') and record.args:
            record.args = tuple(
                scrub_pii(str(arg)) if isinstance(arg, str) else arg
                for arg in record.args
            )
        return True


def get_logger(name: str) -> logging.Logger:
    """Get a logger with PII scrubbing configured."""
    logger = logging.getLogger(name)

    # Add PII scrubbing filter if not already added
    if not any(isinstance(f, PIIScrubbingFilter) for f in logger.filters):
        logger.addFilter(PIIScrubbingFilter())

    return logger
