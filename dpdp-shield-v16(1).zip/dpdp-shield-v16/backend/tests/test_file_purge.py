"""Test file purge verification - MANDATORY per Section 4.1."""
import os
import tempfile
from datetime import datetime, timezone

import pytest
from fastapi import UploadFile
from io import BytesIO

from app.services.file_processing import process_inventory_file


class TestFilePurgeVerification:
    """These tests verify that uploaded inventory files are never persisted.

    Per Section 4.1: 'The file must never be written to S3 or any durable 
    storage at any point, even temporarily, even with a lifecycle/expiry policy.'
    """

    @pytest.mark.asyncio
    async def test_csv_processing_no_file_artifact(self):
        """Verify no file artifact remains after CSV processing."""
        # Create test CSV
        csv_content = b"name,email,phone\nJohn,john@example.com,9876543210\nJane,jane@example.com,9876543211"

        # Create UploadFile
        file = UploadFile(
            filename="test_customers.csv",
            file=BytesIO(csv_content),
        )
        file.size = len(csv_content)

        # Process
        suggestions, row_count, col_count, purge_log = await process_inventory_file(file)

        # Verify purge log
        assert purge_log["in_memory_object_dereferenced"] is True
        assert purge_log["temp_buffer_cleared"] is True
        assert purge_log["duration_ms"] < 60000  # Under 60 seconds

        # Verify no temp files exist
        temp_dir = tempfile.gettempdir()
        for f in os.listdir(temp_dir):
            assert "test_customers" not in f, f"File artifact found: {f}"

        # Verify results are metadata only
        assert row_count == 2
        assert col_count == 3
        assert len(suggestions) == 3
        assert suggestions[0]["field_name"] == "name"
        assert suggestions[1]["field_name"] == "email"
        assert suggestions[2]["field_name"] == "phone"

    @pytest.mark.asyncio
    async def test_excel_processing_no_file_artifact(self):
        """Verify no file artifact remains after Excel processing."""
        import pandas as pd

        # Create test Excel in memory
        df = pd.DataFrame({
            "customer_name": ["Alice", "Bob"],
            "pan": ["ABCDE1234F", "VWXYZ5678G"],
            "phone": ["9876543210", "9876543211"],
        })

        buffer = BytesIO()
        df.to_excel(buffer, index=False)
        buffer.seek(0)

        file = UploadFile(
            filename="test_data.xlsx",
            file=buffer,
        )
        file.size = buffer.getbuffer().nbytes

        # Process
        suggestions, row_count, col_count, purge_log = await process_inventory_file(file)

        # Verify no temp files
        temp_dir = tempfile.gettempdir()
        for f in os.listdir(temp_dir):
            assert "test_data" not in f, f"File artifact found: {f}"

        # Verify PAN detection
        pan_suggestion = next((s for s in suggestions if s["field_name"] == "pan"), None)
        assert pan_suggestion is not None
        assert pan_suggestion["suggested_category"] == "sensitive_personal"

    @pytest.mark.asyncio
    async def test_purge_log_structure(self):
        """Verify purge log contains all required fields per Section 4.1."""
        csv_content = b"col1,col2\n1,2"
        file = UploadFile(filename="test.csv", file=BytesIO(csv_content))
        file.size = len(csv_content)

        _, _, _, purge_log = await process_inventory_file(file)

        required_fields = [
            "file_received",
            "bytes_processed",
            "rows_processed",
            "columns_processed",
            "in_memory_object_dereferenced",
            "temp_buffer_cleared",
            "purge_completed",
            "duration_ms",
        ]

        for field in required_fields:
            assert field in purge_log, f"Missing required purge log field: {field}"

    @pytest.mark.asyncio
    async def test_no_s3_interaction(self):
        """Verify the file processing pipeline never touches S3.

        This test ensures no S3 client is instantiated during inventory processing.
        """
        csv_content = b"test,data\n1,2"
        file = UploadFile(filename="test.csv", file=BytesIO(csv_content))
        file.size = len(csv_content)

        # Mock S3 to detect any calls
        import app.services.s3_service as s3_module
        original_s3 = getattr(s3_module, "S3Service", None)

        call_detected = []

        class MockS3:
            def __init__(self, *args, **kwargs):
                call_detected.append("S3Service instantiated")

        s3_module.S3Service = MockS3

        try:
            await process_inventory_file(file)
            assert len(call_detected) == 0, "S3 was accessed during inventory processing"
        finally:
            if original_s3:
                s3_module.S3Service = original_s3
