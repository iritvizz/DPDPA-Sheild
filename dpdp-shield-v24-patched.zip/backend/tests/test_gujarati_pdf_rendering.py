"""Test Gujarati Unicode rendering in generated PDFs.

This test verifies that WeasyPrint correctly renders Gujarati Unicode
glyphs (not placeholder boxes) when fonts-noto-core is installed.

Run as part of the normal suite:
    cd backend
    pytest tests/test_gujarati_pdf_rendering.py -v
"""
import io
import os

import pytest
from fastapi import status
from httpx import AsyncClient
from pypdf import PdfReader

from app.models import Account, PrivacyNotice, User, UserRole
from app.utils.auth import create_access_token


GUJARATI_SAMPLE = (
    "અમે તમારા ડેટાનું સન્માન કરીએ છીએ. "
    "આ ગોપનીયતા સૂચના અમારી ડેટા પ્રેક્ટિસિસ વિશે જણાવે છે."
)


def _extract_pdf_text(pdf_bytes: bytes) -> str:
    """Extract text from PDF bytes using pypdf."""
    reader = PdfReader(io.BytesIO(pdf_bytes))
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text


@pytest.mark.asyncio
async def test_gujarati_privacy_notice_pdf_renders(async_client: AsyncClient, db_session):
    """Generate a privacy notice with Gujarati text and verify PDF creation."""
    account = Account(
        business_name="Gujarati Test",
        business_slug="gujarati-test",
        sector="E-commerce",
        widget_nonce_secret=os.urandom(32).hex(),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="guj@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    # Use "content" (not "body") to match the app's consistent key name
    notice = PrivacyNotice(
        account_id=account.id,
        template_type="generic",
        content={
            "title": GUJARATI_SAMPLE,
            "language": "gu",
            "sections": [
                {"title": "પરિચય", "content": GUJARATI_SAMPLE},
            ],
        },
        version=1,
        is_published=True,
    )
    db_session.add(notice)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    # Trigger PDF generation via the download endpoint
    response = await async_client.get(
        f"/api/v1/privacy-notice/{notice.public_id}/download",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.headers["content-type"] == "application/pdf"

    pdf_bytes = response.content
    assert len(pdf_bytes) > 1000, "PDF appears too small — likely empty or failed"

    # Validate PDF magic bytes
    assert pdf_bytes[:4] == b"%PDF", "Response does not start with PDF magic bytes"

    # Extract real text and check for Gujarati Unicode block (U+0A80–U+0AFF)
    extracted = _extract_pdf_text(pdf_bytes)
    assert any(
        "\u0A80" <= c <= "\u0AFF" for c in extracted
    ), f"Extracted PDF text does not contain Gujarati Unicode glyphs. Extracted: {extracted[:200]}"
