"""Retention & Deletion Logging routes (spec §7.2)."""
import uuid
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Account, AuditLog, DataElement, DataSource, User
from app.schemas import (
    DeletionLogCreateRequest,
    DeletionLogResponse,
    MessageResponse,
    RetentionExpiryResponse,
)
from app.utils.auth import get_current_active_user, require_admin
from app.utils.enums import enum_value
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/retention", tags=["retention"])


@router.get("/expiries", response_model=list[RetentionExpiryResponse])
async def list_retention_expiries(
    days_warning: int = 30,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List data elements/sources whose retention period ends within
    `days_warning` days.  Uses the retention_period_value and
    retention_period_unit fields already present on DataElement."""
    from app.models import DataElement, DataSource

    now = datetime.now(timezone.utc)
    cutoff = now + timedelta(days=days_warning)

    # Fetch all confirmed data sources for this account
    result = await db.execute(
        select(DataSource).where(
            DataSource.account_id == current_user.account_id,
            DataSource.status == "confirmed",
        )
    )
    sources = result.scalars().all()

    expiries = []
    for source in sources:
        # Fetch elements for this source
        elem_result = await db.execute(
            select(DataElement).where(DataElement.data_source_id == source.id)
        )
        elements = elem_result.scalars().all()

        for elem in elements:
            if not elem.retention_period_value or not elem.retention_period_unit:
                continue

            # Calculate expiry from source creation + retention period
            # (simplified: in production this would use the actual data
            # collection date, not source creation date)
            try:
                value = int(elem.retention_period_value)
                unit = elem.retention_period_unit.lower()
                if unit in ("day", "days"):
                    delta = timedelta(days=value)
                elif unit in ("month", "months"):
                    delta = timedelta(days=value * 30)
                elif unit in ("year", "years"):
                    delta = timedelta(days=value * 365)
                else:
                    continue

                expiry_date = source.created_at + delta
                if expiry_date <= cutoff:
                    expiries.append(RetentionExpiryResponse(
                        data_source_public_id=source.public_id,
                        data_source_name=source.name,
                        field_name=elem.field_name,
                        data_category=enum_value(elem.data_category),
                        retention_period=f"{elem.retention_period_value} {elem.retention_period_unit}",
                        expiry_date=expiry_date,
                        days_remaining=max(0, (expiry_date - now).days),
                    ))
            except (ValueError, TypeError):
                continue

    return sorted(expiries, key=lambda x: x.expiry_date)


@router.post("/deletion-log", response_model=DeletionLogResponse, status_code=status.HTTP_201_CREATED)
async def log_deletion_attestation(
    data: DeletionLogCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Record an attestation that deletion occurred (who, when, what, method).

    This is a logging/attestation endpoint, not an enforcement mechanism —
    the spec explicitly frames retention as "attestation, not enforcement."
    The attestation is written to the durable AuditLog table for regulatory
    evidence and customer queries.
    """
    source_check = await db.execute(
        select(DataSource).where(
            DataSource.public_id == data.data_source_public_id,
            DataSource.account_id == current_user.account_id,
        )
    )
    if not source_check.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Data source not found")

    audit = AuditLog(
        account_id=current_user.account_id,
        user_id=current_user.id,
        event_type="deletion_attestation",
        event_details={
            "data_source_public_id": str(data.data_source_public_id),
            "field_names": data.field_names,
            "deletion_method": data.deletion_method,
            "performed_by": str(current_user.public_id),
            "notes": data.notes,
        },
    )
    db.add(audit)
    await db.commit()
    await db.refresh(audit)

    logger.info(
        f"Deletion attestation logged by {current_user.public_id}: "
        f"source={data.data_source_public_id}, fields={data.field_names}"
    )

    return DeletionLogResponse(
        log_id=audit.public_id,
        action="deletion_attestation",
        performed_at=audit.created_at,
        performed_by=current_user.public_id,
        data_source_public_id=data.data_source_public_id,
        field_names=data.field_names,
        deletion_method=data.deletion_method,
    )
