# DPDP Shield v16 — Feature Build Completion

This document tracks the completion status of all MVP spec items from `DPDP_Shield_MVP_Spec_v3_final.md`.

---

## Backend — Complete Modules

| Module | Spec § | Status | Notes |
|--------|--------|--------|-------|
| Auth (register/login/refresh/logout) | §3 | ✅ Complete | Including forgot-password / reset-password |
| Account (CRUD, export, delete with cooling-off) | §6.1 | ✅ Complete | Including cancel-deletion |
| Users (invite, accept-invite, list, remove) | §6.1 | ✅ Complete | Consolidated via user_service |
| Dashboard (summary endpoint) | §6.1 | ✅ Complete | |
| Inventory (upload, parse, classify, confirm) | §6.2 | ✅ Complete | Including element-level PATCH/DELETE and PDF export |
| Privacy Notice (create, list, publish, versions) | §6.3 | ✅ Complete | Including version detail + restore |
| Consent (record CRUD, proof upload, revoke, widget capture, withdrawal link, export) | §6.4 | ✅ Complete | |
| DSAR (ticket CRUD, action log, response templates) | §7.1 | ✅ Complete | Templates seeded in EN/GU/HI |
| RoPA (generate from confirmed inventory) | §6.5 | ✅ Complete | |
| Subscription (checkout, cancel, webhook handling) | §6.6 | ✅ Complete | |
| Reports (audit-pack generation, monthly summary) | §7.3 | ✅ Complete | Celery-backed PDF generation |
| Admin (list accounts, suspend/activate, analytics, impersonation, detail view) | §15 | ✅ Complete | |
| Webhooks (Razorpay signature verification, event handling) | §6.6 | ✅ Complete | |
| File Processing (in-memory extract, purge, AuditLog) | §4.1/9.2 | ✅ Complete | |
| Malware Scan (async core, Celery wrapper, S3 promotion) | §9.2 | ✅ Complete | |
| Google Drive Integration | §4.3 | ✅ Complete | OAuth flow, file listing, in-memory extract |
| Retention & Deletion Logging | §7.2 | ✅ Complete | Expiries endpoint + deletion attestation |
| Alembic Migrations | §2.7 | ✅ Complete | Initialized with baseline migration |

## Backend — Pending / Known Gaps

| Item | Status | Notes |
|------|--------|-------|
| OTP verification (primary signup) | ⬜ Not built | Spec §3/6.1 calls for email/phone OTP |
| Google Drive: real OAuth testing | ⬜ Not verified | Architecturally correct, needs real Google app credentials |
| Razorpay sandbox verification | ⬜ Not verified | Notes-based account linking not tested against real API |
| Rate limiting: multi-worker load test | ⬜ Not tested | Against 500-concurrent-user NFR |
| `pip-audit` dependency scan | ⬜ Not done | 43+ advisories flagged in earlier rounds |

## Frontend — Complete Pages

| Page | Status | Notes |
|------|--------|-------|
| Auth: Login | ✅ Complete | Existing from earlier rounds |
| Auth: Signup | ✅ Complete | Existing from earlier rounds |
| Auth: Forgot/Reset Password | ⬜ UI not built | Backend endpoints work, needs UI |
| Dashboard (layout + checklist + quick actions) | ✅ Complete | Real next-intl i18n, sidebar nav |
| Data Inventory (drag-drop upload + file list) | ✅ Complete | Client Component with real drag-drop |
| Privacy Notice Builder | ✅ Complete | Editor + preview + publish controls |
| Consent Management (list + log + export) | ✅ Complete | Record list with status badges |
| DSAR (list + detail + action log) | ⬜ UI not built | Backend complete, needs rich UI |
| Reports (monthly summary + audit pack) | ⬜ UI not built | Backend complete, needs UI |
| Settings (business + staff + billing + danger zone) | ✅ Complete | Full settings page |
| Public: Privacy Notice View | ✅ Complete | `/public/notice/[businessSlug]` |
| Public: Withdrawal Confirmation | ✅ Complete | `/public/withdrawal/[token]` |
| Public: Consent Widget Embed | ⬜ Not built | JS snippet for business websites |

## Frontend — Technical Notes

- **i18n:** Real `next-intl` wired via `next.config.js` plugin. Dashboard uses `getTranslations` (Server Components). All other pages use `useTranslations` (Client Components) where interactivity is needed. All three locale files (EN/GU/HI) updated with new keys.
- **Missing dependency:** `@radix-ui/react-label` added to `package.json` (was imported but never declared).
- **Build config:** `next.config.js` has `output: 'standalone'` for production Docker builds, plus rewrite fallback for API proxying.

## Suggested Next Steps

1. **Run full verification:** `python -c "from app.main import app"` → `pytest tests/` → `cd frontend && npm install && npx tsc --noEmit`
2. **Build OTP verification flow** (backend + frontend) if that remains a Tier 1 requirement.
3. **Wire frontend pages to real backend data** — currently using placeholder data with `TODO: fetch from API` comments.
4. **Build DSAR and Reports UI** — backend is complete, frontend is the gap.
5. **Build consent widget embed script** — small standalone JS snippet.
6. **Run `pip-audit` and `npm audit`** — address disclosed vulnerabilities before production.
