"""Pydantic schemas for request/response validation."""
from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from app.models import (
    AccountStatus,
    ConsentMethod,
    DataCategory,
    DataSourceStatus,
    DataSourceType,
    SubscriptionStatus,
    UserRole,
)


# ─── Auth Schemas ──────────────────────────────────────────────────────────────

class UserRegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    business_name: str = Field(..., min_length=1, max_length=255)
    sector: str = Field(..., min_length=1, max_length=100)
    employee_count_bracket: Optional[str] = None
    turnover_bracket: Optional[str] = None
    phone: Optional[str] = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int = 900  # 15 minutes


class RefreshRequest(BaseModel):
    refresh_token: str


class OTPRequest(BaseModel):
    email: Optional[EmailStr] = None
    phone: Optional[str] = None


class OTPVerifyRequest(BaseModel):
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    otp: str = Field(..., min_length=4, max_length=8)


# ─── User Schemas ──────────────────────────────────────────────────────────────

class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    public_id: UUID
    email: str
    full_name: Optional[str]
    role: str
    is_verified: bool
    last_login_at: Optional[datetime]
    created_at: datetime


class UserInviteRequest(BaseModel):
    email: EmailStr
    role: UserRole = UserRole.STAFF


class AcceptInviteRequest(BaseModel):
    token: str = Field(..., min_length=1)
    password: str = Field(..., min_length=8, max_length=128)
    full_name: str = Field(..., min_length=1, max_length=255)


class UserInvitationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    email: str
    role: str
    expires_at: datetime
    created_at: datetime


# ─── Account Schemas ───────────────────────────────────────────────────────────

class AccountResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    public_id: UUID
    business_name: str
    business_slug: str
    sector: str
    employee_count_bracket: Optional[str]
    turnover_bracket: Optional[str]
    grievance_email: Optional[str]
    grievance_phone: Optional[str]
    grievance_address: Optional[str]
    status: str
    trial_ends_at: Optional[datetime]
    created_at: datetime


class AccountUpdateRequest(BaseModel):
    business_name: Optional[str] = None
    sector: Optional[str] = None
    employee_count_bracket: Optional[str] = None
    turnover_bracket: Optional[str] = None
    grievance_email: Optional[EmailStr] = None
    grievance_phone: Optional[str] = None
    grievance_address: Optional[str] = None


class AccountExportResponse(BaseModel):
    account: Dict[str, Any]
    data_sources: List[Dict[str, Any]]
    privacy_notices: List[Dict[str, Any]]
    consent_records: List[Dict[str, Any]]
    audit_logs: List[Dict[str, Any]]


# ─── Data Inventory Schemas ────────────────────────────────────────────────────

class DataSourceCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    source_type: DataSourceType


class DataSourceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    source_type: str
    status: str
    row_count: Optional[int]
    column_count: Optional[int]
    created_at: datetime
    updated_at: datetime


class ClassificationSuggestion(BaseModel):
    field_name: str
    suggested_category: DataCategory
    suggested_purposes: List[str]
    confidence: str  # high, medium, low


class ParseFileResponse(BaseModel):
    suggestions: List[ClassificationSuggestion]
    row_count: int
    column_count: int


class DataElementCreateRequest(BaseModel):
    field_name: str = Field(..., min_length=1, max_length=255)
    data_category: DataCategory
    purposes: List[str] = Field(default_factory=list)
    legal_basis: Optional[str] = None
    retention_period_value: Optional[int] = None
    retention_period_unit: Optional[str] = None
    third_party_sharing: bool = False
    third_party_details: Optional[str] = None


class DataElementResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    field_name: str
    data_category: str
    purposes: List[str]
    legal_basis: Optional[str]
    retention_period_value: Optional[int]
    retention_period_unit: Optional[str]
    third_party_sharing: bool
    third_party_details: Optional[str]
    created_at: datetime
    updated_at: datetime


class ConfirmElementsRequest(BaseModel):
    elements: List[DataElementCreateRequest]


# ─── Privacy Notice Schemas ────────────────────────────────────────────────────

class PrivacyNoticeSection(BaseModel):
    title: str
    content: str
    order: int


class PrivacyNoticeCreateRequest(BaseModel):
    template_type: str = Field(..., pattern="^(ecommerce|service|generic)$")
    content: Dict[str, Any]  # structured sections
    language: str = Field(default="en", pattern="^(en|hi|gu)$")


class PrivacyNoticeResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    template_type: str
    content: Dict[str, Any]
    is_published: bool
    version: int
    published_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime


class PublicNoticeResponse(BaseModel):
    business_name: str
    business_slug: str
    content: Dict[str, Any]
    published_at: Optional[datetime]
    version: int


# ─── Consent Schemas ───────────────────────────────────────────────────────────

class ConsentRecordCreateRequest(BaseModel):
    customer_reference: str = Field(..., min_length=1, max_length=255)
    purpose: str = Field(..., min_length=1, max_length=100)
    consent_timestamp: Optional[datetime] = None
    method: ConsentMethod
    proof_text: Optional[str] = None
    consent_expiry: Optional[datetime] = None


class ConsentRecordResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    public_id: UUID
    customer_reference: str
    purpose: str
    consent_timestamp: datetime
    method: str
    proof_text: Optional[str]
    proof_file_status: str
    is_revoked: bool
    revoked_at: Optional[datetime]
    consent_expiry: Optional[datetime]
    created_at: datetime


class WidgetCaptureRequest(BaseModel):
    business_slug: str
    customer_reference: str
    purpose: str
    nonce: str
    consent_timestamp: Optional[datetime] = None


class WithdrawalResponse(BaseModel):
    customer_reference: str
    purpose: str
    withdrawn_at: datetime
    message: str


# ─── Dashboard Schemas ─────────────────────────────────────────────────────────

class ComplianceChecklistItem(BaseModel):
    key: str
    label: str
    completed: bool


class DashboardSummaryResponse(BaseModel):
    compliance_checklist: List[ComplianceChecklistItem]
    completed_count: int
    total_count: int
    data_sources_count: int
    consent_records_count: int
    published_notice: bool
    trial_days_remaining: Optional[int] = None
    subscription_status: str


class ActivityItem(BaseModel):
    event_type: str
    description: str
    created_at: datetime
    user_name: Optional[str] = None


class DashboardActivityResponse(BaseModel):
    activities: List[ActivityItem]


# ─── Subscription Schemas ──────────────────────────────────────────────────────

class SubscriptionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    plan_id: str
    status: str
    current_period_start: Optional[datetime]
    current_period_end: Optional[datetime]
    created_at: datetime


class RazorpayCheckoutRequest(BaseModel):
    plan_id: str = "dpdp-shield-pro"


class RazorpayCheckoutResponse(BaseModel):
    order_id: str
    key_id: str
    amount: int
    currency: str


# ─── Audit Log Schemas ───────────────────────────────────────────────────────

class AuditLogResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    event_type: str
    event_details: Dict[str, Any]
    ip_address: Optional[str]
    created_at: datetime


# ─── Generic ───────────────────────────────────────────────────────────────────

class ErrorResponse(BaseModel):
    detail: str
    reference_id: Optional[str] = None


class MessageResponse(BaseModel):
    message: str


# --- DSAR Schemas ---

class DSARCreateRequest(BaseModel):
    principal_email: EmailStr
    principal_name: Optional[str] = None
    principal_phone: Optional[str] = None
    request_type: str = Field(..., pattern="^(access|correction|deletion|portability)$")
    description: Optional[str] = None


class DSARUpdateRequest(BaseModel):
    status: Optional[str] = Field(None, pattern="^(pending|in_progress|fulfilled|rejected)$")
    response_text: Optional[str] = None


class DSARResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    public_id: UUID
    principal_email: str
    principal_name: Optional[str]
    principal_phone: Optional[str]
    request_type: str
    status: str
    description: Optional[str]
    response_text: Optional[str]
    responded_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime


# --- Admin Panel Schemas ---

class AdminAccountListItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    public_id: UUID
    business_name: str
    business_slug: str
    sector: str
    status: str
    trial_ends_at: Optional[datetime]
    created_at: datetime
    user_count: int


class AdminAnalyticsResponse(BaseModel):
    total_accounts: int
    total_users: int
    total_consent_records: int
    total_data_sources: int
    active_subscriptions: int
    trial_accounts: int
    dsar_requests_pending: int

class AuditPackResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    generation_id: UUID
    status: str
    download_url: Optional[str]
    expires_at: Optional[datetime]

class DSARActionLogResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    dsar_id: int
    action_text: str
    performed_by_id: Optional[int]
    created_at: datetime

class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str = Field(..., min_length=1)
    new_password: str = Field(..., min_length=8, max_length=128)

# ─── Google Drive Schemas ─────────────────────────────────────────────────────

class GoogleDriveFileResponse(BaseModel):
    id: str
    name: str
    mime_type: str
    modified_time: Optional[datetime]


# ─── Retention & Deletion Logging Schemas ─────────────────────────────────────

class RetentionExpiryResponse(BaseModel):
    data_source_public_id: UUID
    data_source_name: str
    field_name: str
    data_category: str
    retention_period: str
    expiry_date: datetime
    days_remaining: int


class DeletionLogCreateRequest(BaseModel):
    data_source_public_id: UUID
    field_names: list[str]
    deletion_method: str = Field(..., min_length=1, max_length=255)
    notes: Optional[str] = None


class DeletionLogResponse(BaseModel):
    log_id: UUID
    action: str
    performed_at: datetime
    performed_by: UUID
    data_source_public_id: UUID
    field_names: list[str]
    deletion_method: str


# ─── DSAR Template Schemas ────────────────────────────────────────────────────

class DSARTemplateResponse(BaseModel):
    id: int
    request_type: str
    language: str
    subject_template: str
    body_template: str


# ─── Admin Impersonation Schemas ──────────────────────────────────────────────

class ImpersonationResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    message: str

class AdminAccountDetailResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    public_id: UUID
    business_name: str
    business_slug: str
    sector: str
    status: str
    trial_ends_at: Optional[datetime]
    created_at: datetime
    user_count: int
    data_source_count: int
    consent_record_count: int

