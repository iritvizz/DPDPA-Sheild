"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";

interface DSARTicket {
  public_id: string;
  principal_email: string;
  principal_name: string | null;
  principal_phone: string | null;
  request_type: string;
  status: string;
  description: string | null;
  response_text: string | null;
  responded_at: string | null;
  created_at: string;
  updated_at: string;
}

interface DSARAction {
  id: number;
  action_text: string;
  performed_by_id: number | null;
  created_at: string;
}

interface DSARTemplate {
  id: number;
  request_type: string;
  language: string;
  subject_template: string;
  body_template: string;
}

export default function DSARPage() {
  const t = useTranslations();
  const [tickets, setTickets] = useState<DSARTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<DSARTicket | null>(null);
  const [actions, setActions] = useState<DSARAction[]>([]);
  const [templates, setTemplates] = useState<DSARTemplate[]>([]);
  const [newAction, setNewAction] = useState("");
  const [responseText, setResponseText] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [createForm, setCreateForm] = useState({
    principal_email: "",
    principal_name: "",
    principal_phone: "",
    request_type: "access",
    description: "",
  });

  useEffect(() => { loadTickets(); }, []);

  useEffect(() => {
    if (selectedTicket) {
      loadActions(selectedTicket.public_id);
      loadTemplates("en");
    }
  }, [selectedTicket]);

  async function loadTickets() {
    setLoading(true);
    try {
      const data = await apiFetch("/api/v1/dsar");
      setTickets(data);
    } catch (err: any) {
      setError(err.message || "Failed to load tickets");
    } finally {
      setLoading(false);
    }
  }

  async function loadActions(ticketId: string) {
    try {
      const data = await apiFetch(`/api/v1/dsar/${ticketId}/actions`);
      setActions(data);
    } catch (err: any) {
      setError(err.message || "Failed to load actions");
    }
  }

  async function loadTemplates(lang: string) {
    try {
      const data = await apiFetch(`/api/v1/dsar/templates?language=${lang}`);
      setTemplates(data);
    } catch {}
  }

  async function createTicket(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch("/api/v1/dsar", {
        method: "POST",
        body: JSON.stringify(createForm),
      });
      setShowCreate(false);
      setCreateForm({ principal_email: "", principal_name: "", principal_phone: "", request_type: "access", description: "" });
      loadTickets();
    } catch (err: any) {
      setError(err.message || "Failed to create ticket");
    }
  }

  async function updateStatus(ticketId: string, status: string) {
    try {
      await apiFetch(`/api/v1/dsar/${ticketId}`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
      loadTickets();
      if (selectedTicket?.public_id === ticketId) {
        const updated = await apiFetch(`/api/v1/dsar/${ticketId}`);
        setSelectedTicket(updated);
      }
    } catch (err: any) {
      setError(err.message || "Failed to update status");
    }
  }

  async function submitResponse(ticketId: string) {
    try {
      await apiFetch(`/api/v1/dsar/${ticketId}`, {
        method: "PATCH",
        body: JSON.stringify({ response_text: responseText }),
      });
      setResponseText("");
      loadTickets();
      const updated = await apiFetch(`/api/v1/dsar/${ticketId}`);
      setSelectedTicket(updated);
    } catch (err: any) {
      setError(err.message || "Failed to submit response");
    }
  }

  async function addAction(ticketId: string) {
    if (!newAction.trim()) return;
    try {
      await apiFetch(`/api/v1/dsar/${ticketId}/actions`, {
        method: "POST",
        body: JSON.stringify({ action_text: newAction }),
      });
      setNewAction("");
      loadActions(ticketId);
    } catch (err: any) {
      setError(err.message || "Failed to add action");
    }
  }

  function applyTemplate(template: DSARTemplate) {
    setResponseText(template.body_template);
  }

  const statusColors: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-800",
    in_progress: "bg-blue-100 text-blue-800",
    fulfilled: "bg-green-100 text-green-800",
    rejected: "bg-red-100 text-red-800",
  };

  if (loading) return <p className="text-gray-500">Loading DSAR tickets...</p>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{t("dsar.title")}</h2>
        <Button onClick={() => setShowCreate(!showCreate)}>
          {showCreate ? t("auth.back") : t("dsar.createTicket")}
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {showCreate && (
        <Card>
          <CardHeader><CardTitle>{t("dsar.newTicket")}</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={createTicket} className="space-y-4">
              <div><Label>{t("dsar.principalEmail")}</Label><Input type="email" required value={createForm.principal_email} onChange={(e) => setCreateForm({ ...createForm, principal_email: e.target.value })} /></div>
              <div><Label>{t("dsar.principalName")}</Label><Input value={createForm.principal_name} onChange={(e) => setCreateForm({ ...createForm, principal_name: e.target.value })} /></div>
              <div><Label>{t("dsar.requestType")}</Label>
                <select className="w-full border rounded-md px-3 py-2" value={createForm.request_type} onChange={(e) => setCreateForm({ ...createForm, request_type: e.target.value })}>
                  <option value="access">Access</option>
                  <option value="correction">Correction</option>
                  <option value="deletion">Deletion</option>
                  <option value="portability">Portability</option>
                </select>
              </div>
              <div><Label>{t("dsar.description")}</Label><Textarea value={createForm.description} onChange={(e) => setCreateForm({ ...createForm, description: e.target.value })} /></div>
              <Button type="submit">{t("dsar.createTicket")}</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          {tickets.map((ticket) => (
            <Card key={ticket.public_id} className={`cursor-pointer hover:shadow-md transition ${selectedTicket?.public_id === ticket.public_id ? "ring-2 ring-blue-500" : ""}`} onClick={() => setSelectedTicket(ticket)}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">{ticket.principal_email}</span>
                  <Badge className={statusColors[ticket.status] || "bg-gray-100"}>{ticket.status}</Badge>
                </div>
                <p className="text-sm text-gray-500 capitalize">{ticket.request_type}</p>
                <p className="text-xs text-gray-400 mt-1">{new Date(ticket.created_at).toLocaleDateString()}</p>
              </CardContent>
            </Card>
          ))}
          {tickets.length === 0 && <p className="text-gray-500 text-center py-8">{t("dsar.noTickets")}</p>}
        </div>

        <div className="lg:col-span-2">
          {selectedTicket ? (
            <div className="space-y-6">
              <Card>
                <CardHeader><CardTitle>{t("dsar.ticketDetail")}</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><span className="text-gray-500">{t("dsar.principalEmail")}:</span> {selectedTicket.principal_email}</div>
                    <div><span className="text-gray-500">{t("dsar.status")}:</span> <Badge className={statusColors[selectedTicket.status] || "bg-gray-100"}>{selectedTicket.status}</Badge></div>
                    <div><span className="text-gray-500">{t("dsar.requestType")}:</span> {selectedTicket.request_type}</div>
                    <div><span className="text-gray-500">{t("dsar.created")}:</span> {new Date(selectedTicket.created_at).toLocaleString()}</div>
                  </div>
                  {selectedTicket.description && <div><span className="text-gray-500">{t("dsar.description")}:</span><p className="mt-1">{selectedTicket.description}</p></div>}
                  <div className="flex gap-2 pt-2">
                    {selectedTicket.status === "pending" && <Button size="sm" onClick={() => updateStatus(selectedTicket.public_id, "in_progress")}>{t("dsar.markInProgress")}</Button>}
                    {selectedTicket.status === "in_progress" && (
                      <>
                        <Button size="sm" onClick={() => updateStatus(selectedTicket.public_id, "fulfilled")}>{t("dsar.markFulfilled")}</Button>
                        <Button size="sm" variant="destructive" onClick={() => updateStatus(selectedTicket.public_id, "rejected")}>{t("dsar.markRejected")}</Button>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle>{t("dsar.response")}</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  {templates.length > 0 && (
                    <div>
                      <Label>{t("dsar.templates")}</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {templates.map((tmpl) => (
                          <Button key={tmpl.id} variant="outline" size="sm" onClick={() => applyTemplate(tmpl)}>
                            {tmpl.request_type} ({tmpl.language})
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                  <Textarea placeholder={t("dsar.responsePlaceholder")} value={responseText} onChange={(e) => setResponseText(e.target.value)} rows={6} />
                  <Button onClick={() => submitResponse(selectedTicket.public_id)}>{t("dsar.saveResponse")}</Button>
                  {selectedTicket.response_text && (
                    <div className="bg-gray-50 p-3 rounded-md mt-2">
                      <p className="text-sm text-gray-500 mb-1">{t("dsar.previousResponse")}:</p>
                      <p className="text-sm">{selectedTicket.response_text}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle>{t("dsar.actionLog")}</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {actions.map((action) => (
                      <div key={action.id} className="border-l-2 border-blue-300 pl-3">
                        <p className="text-sm">{action.action_text}</p>
                        <p className="text-xs text-gray-400">{new Date(action.created_at).toLocaleString()}</p>
                      </div>
                    ))}
                    {actions.length === 0 && <p className="text-gray-500 text-sm">{t("dsar.noActions")}</p>}
                  </div>
                  <div className="flex gap-2">
                    <Input placeholder={t("dsar.addActionPlaceholder")} value={newAction} onChange={(e) => setNewAction(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") addAction(selectedTicket.public_id); }} />
                    <Button onClick={() => addAction(selectedTicket.public_id)}>{t("dsar.addAction")}</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card><CardContent className="p-8 text-center text-gray-500">{t("dsar.selectTicket")}</CardContent></Card>
          )}
        </div>
      </div>
    </div>
  );
}
