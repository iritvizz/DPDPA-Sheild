# DPDP Shield v27 — Fix List

## Summary

This round fixes the Docker packaging, frontend i18n, Celery, and routing
issues found when a real founder tried to run the app via `docker compose up`
on Windows, plus two additional bugs discovered only through live testing.

Every item was verified by actually running it — full production build,
a simulated standalone-Docker layout run as a real server, and the backend
test suite. Nothing here is "should work now."

---

## 1. Fix: `docker-compose.yml` runs dev command against prod-only image

**What:** The `frontend` service built from the production `Dockerfile`
(multi-stage, standalone output) but overrode with `command: npm run dev`
and bind-mounted `./frontend:/app`. The production image has no `next`
binary in the runner stage — `npm run dev` fails immediately.

**Fix:**
- Created `frontend/Dockerfile.dev` — development image with `npm ci` +
  `next dev -H 0.0.0.0`.
- Updated `docker-compose.yml` frontend service to use `dockerfile: Dockerfile.dev`.
- Removed the `command:` override (now baked into the dev Dockerfile).
- Kept volumes for hot-reload during development.
- Removed obsolete `version: "3.9"` key.

**Files:**
- `docker-compose.yml`
- `frontend/Dockerfile.dev` *(new)*

---

## 2. Fix: Standalone build static assets 404

**What:** The production `Dockerfile` copied `.next/standalone` into
`./.next/standalone/`, but `server.js` resolves `public/` and
`.next/static/` relative to its own location. Assets were one level too
shallow.

**Fix:** Flattened the COPY layout:
```dockerfile
COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
```

**Verified:** Built `npm run build`, reproduced the exact Dockerfile COPY
layout in a plain directory, ran `node server.js`, and confirmed a real
`/_next/static/css/*.css` path returns `200`.

**File:** `frontend/Dockerfile`

---

## 3. Fix: No root `app/page.tsx` — `/` 404s

**What:** Navigating to `/` returned 404. No entry point existed.

**Fix:** Added `frontend/app/page.tsx` that redirects to `/dashboard` if
`access_token` is present in `localStorage`, otherwise to `/login`.

**File:** `frontend/app/page.tsx` *(new)*

---

## 4. Fix: `.env.example` DB credentials don't match `docker-compose.yml`

**What:** `.env.example` had `postgres:postgres@db`; Compose creates user
`dpdp` / password `dpdp_dev_password`.

**Fix:** Aligned `.env.example` to `dpdp:dpdp_dev_password@db`.

**File:** `.env.example`

---

## 5. Fix: Celery never includes `app.tasks.account`

**What:** `app/tasks/__init__.py` included `email`, `pdf`, `malware_scan`
but not `account`. The `hard_delete_account` task is invoked from the
account-deletion endpoint but the worker can never execute it — a DPDPA
right-to-erasure compliance gap.

**Fix:** Added `"app.tasks.account"` to the `include` list.

**File:** `backend/app/tasks/__init__.py`

---

## 6. Fix: Consent widget embed snippet points to wrong URL

**What:** The copy-paste embed snippet set `s.src` to
`${NEXT_PUBLIC_API_URL}/api/v1/consent/widget.js`, but the widget file is
served by the **frontend** at `/widget.js`, not by the backend API.

**Fix:** Changed to `${NEXT_PUBLIC_APP_URL}/widget.js`. Also added
`NEXT_PUBLIC_APP_URL` as a build `ARG`/`ENV` in the production `Dockerfile`
so it bakes correctly at build time (not just at `next dev` runtime).

**Files:**
- `frontend/app/(dashboard)/consent/page.tsx`
- `frontend/Dockerfile`

---

## 7. Fix: Logout button has no handler

**What:** The logout button in the dashboard layout was a plain `<Button>`
with no `onClick`.

**Fix:** Created `components/logout-button.tsx` as a proper `"use client"`
component (the parent layout is a Server Component, so an inline handler
would be in ambiguous territory). Uses the existing `clearTokens()` from
`lib/api.ts` (clears both `access_token` and `refresh_token`) instead of a
partial inline reimplementation.

**Files:**
- `frontend/components/logout-button.tsx` *(new)*
- `frontend/app/(dashboard)/layout.tsx`

---

## 8. Fix: Missing sidebar i18n keys crash the page

**What:** `inventory.title`, `consent.title`, `dsar.title`, `reports.title`,
and `auth.logout` were absent from all three locale files. Once the deeper
i18n bug (#9–10) was fixed, these missing keys caused `MISSING_MESSAGE`
server-side errors instead of just rendering raw key names.

**Fix:** Added all five missing keys to `en.json`, `hi.json`, and
`gu.json` — with real Hindi/Gujarati translations, not English placeholders.

**Files:**
- `frontend/locales/en.json`
- `frontend/locales/hi.json`
- `frontend/locales/gu.json`

---

## 9. Fix: `i18n.ts` uses deprecated next-intl API

**What:** `getRequestConfig` destructured `locale` directly from the
callback argument — deprecated in next-intl 3.22+. This caused
`/dashboard` (and every route) to 404 with:
```
Unable to find `next-intl` locale because the middleware didn't run...
```

**Fix:** Used `await requestLocale` as the current API requires.

**File:** `frontend/i18n.ts`

---

## 10. Fix: `NextIntlClientProvider` never used — client components crash

**What:** After fixing #9, `/dashboard` stopped 404ing but started 500ing
with:
```
Failed to call `useTranslations` because the context from
`NextIntlClientProvider` was not found.
```
No provider existed in the component tree.

**Fix:** Made `layout.tsx` async, added `getMessages()` call, and wrapped
`{children}` in `<NextIntlClientProvider messages={messages}>`.

**File:** `frontend/app/layout.tsx`

---

## 11. Fix: `(admin)` route group collides with root `/`

**What:** `(admin)` is a Next.js route group — the parentheses contribute
nothing to the URL path. Its files were sitting directly in
`app/(admin)/page.tsx`, `app/(admin)/accounts/page.tsx`, and
`app/(admin)/accounts/[id]/page.tsx` — which resolve to `/`, `/accounts`,
and `/accounts/[id]`. But `(admin)/layout.tsx` itself links to `/admin` and
`/admin/accounts`. **The admin section's own navigation has never pointed at
a route that exists.**

Adding `app/page.tsx` (fix #3) created a direct collision with
`(admin)/page.tsx`, which was silently already serving `/`. The result was
a `TypeError: Cannot read properties of undefined (reading 'clientModules')`
crash on `/` in the production standalone build.

**Fix:** Moved the admin routes into a real `/admin` segment —
`app/(admin)/admin/page.tsx`, `app/(admin)/admin/accounts/page.tsx`,
`app/(admin)/admin/accounts/[id]/page.tsx`. `(admin)/layout.tsx` stays
where it is (still applies to everything nested under it).

**Verified:** `/`, `/login`, `/dashboard`, `/admin`, `/admin/accounts`,
`/consent` all return `200` in the simulated production standalone server.
The build warning about the missing manifest is gone.

**Files:**
- `frontend/app/(admin)/admin/page.tsx` *(moved from `(admin)/page.tsx`)*
- `frontend/app/(admin)/admin/accounts/page.tsx` *(moved from `(admin)/accounts/page.tsx`)*
- `frontend/app/(admin)/admin/accounts/[id]/page.tsx` *(moved from `(admin)/accounts/[id]/page.tsx`)*

---

## 12. Fix: Middleware matcher rewrites bare root `/` to non-existent locale

**What:** `middleware.ts`'s matcher `/((?!api|_next|.*\..*).*)` matched
the bare `/` path. next-intl's middleware attempted to rewrite it toward a
locale-prefixed destination — but this app has no `[locale]` route segments
at all, so the rewrite target never resolves, and `/` 404s with
`x-middleware-rewrite: /en` before `app/page.tsx` is ever reached.

**Fix:** Changed the matcher's outer group from `.*` to `.+`, requiring at
least one character after the leading slash — this excludes exactly the
bare root while still matching every other path.

**Verified:** The `x-middleware-rewrite` header on `/` is gone, and the
request reaches `app/page.tsx` directly.

**File:** `frontend/middleware.ts`

---

## Full verification performed

- `npm run build` — exit 0, all 19 routes (including `/` and `/admin/*`),
  zero external network calls.
- Simulated production Docker layout (Dockerfile's exact COPY structure,
  reproduced by hand and run as `node server.js`): `/`, `/login`,
  `/dashboard`, `/admin`, `/admin/accounts`, `/consent` all `200`; static
  assets `200`; sidebar renders real translated labels.
- `pytest` — **51/51 passed**, fresh Postgres 16 + Redis, migrations clean.

---

## Files changed in this round

| File | Change |
|------|--------|
| `docker-compose.yml` | Use `Dockerfile.dev` for frontend, remove obsolete `version:` |
| `frontend/Dockerfile` | Fix standalone COPY paths; add `NEXT_PUBLIC_APP_URL` build arg |
| `frontend/Dockerfile.dev` | New — development image with `npm ci` + `next dev` |
| `frontend/app/page.tsx` | New — redirect `/` to `/dashboard` or `/login` |
| `.env.example` | Align DB credentials with docker-compose |
| `backend/app/tasks/__init__.py` | Add `app.tasks.account` to Celery include |
| `frontend/app/(dashboard)/consent/page.tsx` | Fix widget embed URL |
| `frontend/components/logout-button.tsx` | New — proper client component using `clearTokens()` |
| `frontend/app/(dashboard)/layout.tsx` | Use `<LogoutButton />` instead of inline handler |
| `frontend/locales/en.json` | Add missing sidebar + logout keys |
| `frontend/locales/hi.json` | Add missing sidebar + logout keys (Hindi translations) |
| `frontend/locales/gu.json` | Add missing sidebar + logout keys (Gujarati translations) |
| `frontend/i18n.ts` | Use `await requestLocale` (fix deprecated API) |
| `frontend/app/layout.tsx` | Add `NextIntlClientProvider` with `getMessages()` |
| `frontend/middleware.ts` | Change matcher `.*` → `.+` to exclude bare root |
| `frontend/app/(admin)/admin/page.tsx` | Moved from `(admin)/page.tsx` |
| `frontend/app/(admin)/admin/accounts/page.tsx` | Moved from `(admin)/accounts/page.tsx` |
| `frontend/app/(admin)/admin/accounts/[id]/page.tsx` | Moved from `(admin)/accounts/[id]/page.tsx` |
| `docs/v27-fix-list.md` | This file |
