"""Records of Processing Activities (RoPA) routes."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.utils.enums import enum_value
from app.models import DataElement, DataSource, User
from app.schemas import MessageResponse
from app.utils.auth import get_current_active_user
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/ropa", tags=["ropa"])


@router.get("/latest")
async def get_latest_ropa(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get the latest RoPA generated from confirmed data sources."""
    result = await db.execute(
        select(DataSource)
        .options(selectinload(DataSource.elements))
        .where(
            DataSource.account_id == current_user.account_id,
            DataSource.status == "confirmed",
        )
    )
    sources = result.scalars().all()

    if not sources:
        raise HTTPException(status_code=404, detail="No confirmed data sources found. Create and confirm a data inventory first.")

    ropa_entries = []
    for ds in sources:
        for elem in ds.elements:
            ropa_entries.append({
                "data_source": ds.name,
                "field_name": elem.field_name,
                "data_category": enum_value(elem.data_category),
                "purposes": elem.purposes,
                "legal_basis": elem.legal_basis or "Legitimate Interest",
                "retention": f"{elem.retention_period_value} {elem.retention_period_unit}" if elem.retention_period_value else "Not specified",
                "third_party_sharing": elem.third_party_sharing,
                "third_party_details": elem.third_party_details,
            })

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "entry_count": len(ropa_entries),
        "entries": ropa_entries,
    }


@router.post("/generate", status_code=201)
async def generate_ropa(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Generate/update RoPA from current confirmed data sources.

    This is a lightweight operation — RoPA is always generated on-demand
    from the current inventory state. The generation itself is just a
    confirmation that the user has reviewed and accepted the RoPA.
    """
    result = await db.execute(
        select(DataSource)
        .options(selectinload(DataSource.elements))
        .where(
            DataSource.account_id == current_user.account_id,
            DataSource.status == "confirmed",
        )
    )
    sources = result.scalars().all()

    if not sources:
        raise HTTPException(
            status_code=400,
            detail="No confirmed data sources. Complete your data inventory first.",
        )

    # Log the RoPA generation event
    from app.models import AuditLog
    audit = AuditLog(
        account_id=current_user.account_id,
        user_id=current_user.id,
        event_type="ropa_generated",
        event_details={
            "description": f"RoPA generated from {len(sources)} data source(s)",
            "source_count": len(sources),
            "element_count": sum(len(ds.elements) for ds in sources),
        },
    )
    db.add(audit)
    await db.commit()

    logger.info(f"RoPA generated for account {current_user.account_id}")

    return MessageResponse(
        message=f"RoPA generated successfully from {len(sources)} data source(s)."
    )
