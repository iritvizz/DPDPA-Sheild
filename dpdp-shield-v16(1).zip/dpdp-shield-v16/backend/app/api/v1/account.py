"""Account management routes."""
import json
import uuid
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.utils.enums import enum_value
from app.models import (
    Account,
    AccountStatus,
    AuditLog,
    ConsentRecord,
    DataSource,
    PrivacyNotice,
    User,
)
from app.schemas import (
    AccountResponse,
    AccountUpdateRequest,
    MessageResponse,
)
from app.utils.auth import (
    get_current_active_user,
    require_admin,
    require_admin_any_status,
)
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/account", tags=["account"])


@router.get("", response_model=AccountResponse)
async def get_account(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get current account details."""
    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    return result.scalar_one()


@router.patch("", response_model=AccountResponse)
async def update_account(
    data: AccountUpdateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Update account details."""
    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    account = result.scalar_one()

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(account, field, value)

    await db.commit()
    await db.refresh(account)

    return account


@router.delete("", response_model=MessageResponse)
async def delete_account(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Request account deletion (48h cooling off)."""
    from app.tasks.email import send_account_deletion_warning
    from app.tasks.account import hard_delete_account

    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    account = result.scalar_one()

    account.status = "deleted"
    account.deleted_at = datetime.now(timezone.utc) + timedelta(hours=48)
    await db.commit()

    # Send cooling-off email immediately
    send_account_deletion_warning.delay(account.id)

    # Schedule hard deletion after 48 hours and store the task ID so we
    # can revoke it if the user cancels deletion before the cooling-off
    # period expires.
    task = hard_delete_account.apply_async(
        args=[account.id],
        countdown=48 * 3600,  # 48 hours in seconds
    )
    account.deletion_task_id = task.id
    await db.commit()

    return MessageResponse(message="Account scheduled for deletion in 48 hours. A confirmation email has been sent.")


@router.post("/cancel-deletion", response_model=MessageResponse)
async def cancel_deletion(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin_any_status),
):
    """Cancel a pending account deletion before the cooling-off period ends."""
    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    account = result.scalar_one()

    if enum_value(account.status) != "deleted":
        raise HTTPException(
            status_code=400,
            detail="Account is not scheduled for deletion",
        )

    # Revoke the scheduled hard-deletion task if we have its ID
    if account.deletion_task_id:
        from app.tasks import celery_app
        celery_app.control.revoke(account.deletion_task_id, terminate=False)

    account.status = AccountStatus.ACTIVE
    account.deleted_at = None
    account.deletion_task_id = None
    await db.commit()

    return MessageResponse(message="Account deletion cancelled. Your account is now active again.")


@router.get("/export")
async def export_account_data(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Export all account data as machine-readable JSON."""
    account_id = current_user.account_id

    # Get account
    result = await db.execute(select(Account).where(Account.id == account_id))
    account = result.scalar_one()

    # Get data sources
    result = await db.execute(
        select(DataSource)
        .options(selectinload(DataSource.elements))
        .where(DataSource.account_id == account_id)
    )
    data_sources = result.scalars().all()

    # Get privacy notices
    result = await db.execute(select(PrivacyNotice).where(PrivacyNotice.account_id == account_id))
    notices = result.scalars().all()

    # Get consent records (metadata only, no PII)
    result = await db.execute(select(ConsentRecord).where(ConsentRecord.account_id == account_id))
    consent = result.scalars().all()

    # Get audit logs
    result = await db.execute(select(AuditLog).where(AuditLog.account_id == account_id))
    logs = result.scalars().all()

    export_data = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "account": {
            "public_id": str(account.public_id),
            "business_name": account.business_name,
            "business_slug": account.business_slug,
            "sector": account.sector,
            "status": enum_value(account.status),
            "created_at": account.created_at.isoformat() if account.created_at else None,
        },
        "data_sources": [
            {
                "id": ds.id,
                "name": ds.name,
                "source_type": enum_value(ds.source_type),
                "status": enum_value(ds.status),
                "row_count": ds.row_count,
                "column_count": ds.column_count,
                "elements": [
                    {
                        "field_name": e.field_name,
                        "data_category": enum_value(e.data_category),
                        "purposes": e.purposes,
                        "retention": f"{e.retention_period_value} {e.retention_period_unit}" if e.retention_period_value else None,
                    }
                    for e in ds.elements
                ],
            }
            for ds in data_sources
        ],
        "privacy_notices": [
            {
                "version": n.version,
                "template_type": n.template_type,
                "is_published": n.is_published,
                "published_at": n.published_at.isoformat() if n.published_at else None,
            }
            for n in notices
        ],
        "consent_records": [
            {
                "public_id": str(c.public_id),
                "purpose": c.purpose,
                "method": enum_value(c.method),
                "is_revoked": c.is_revoked,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
            for c in consent
        ],
        "audit_logs": [
            {
                "event_type": l.event_type,
                "event_details": l.event_details,
                "created_at": l.created_at.isoformat() if l.created_at else None,
            }
            for l in logs
        ],
    }

    return export_data


# User management (staff invites)
