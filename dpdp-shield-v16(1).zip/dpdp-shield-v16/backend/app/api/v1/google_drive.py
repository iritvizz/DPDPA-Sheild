"""Google Drive integration routes."""
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.models import Account, GoogleDriveConnection, User
from app.schemas import MessageResponse
from app.services.google_drive_service import GoogleDriveService
from app.utils.auth import get_current_active_user, require_admin
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/inventory/google-drive", tags=["google-drive"])


@router.post("/connect", response_model=MessageResponse)
async def connect_google_drive(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Generate an OAuth URL for the admin to authorize Google Drive access."""
    settings = get_settings()
    if not settings.GOOGLE_CLIENT_ID or not settings.GOOGLE_CLIENT_SECRET:
        raise HTTPException(status_code=503, detail="Google Drive integration not configured")

    auth_url = GoogleDriveService.get_auth_url(current_user.account_id)
    return MessageResponse(message=auth_url)


@router.get("/callback")
async def google_drive_callback(
    code: str,
    state: str,
    db: AsyncSession = Depends(get_db),
):
    """OAuth callback — exchange code for tokens and store encrypted."""
    try:
        account_id = int(state)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid state parameter")

    result = await db.execute(select(Account).where(Account.id == account_id))
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    try:
        token_data = GoogleDriveService.exchange_code(code, account_id)
    except Exception as exc:
        logger.error(f"Google Drive OAuth exchange failed: {exc}")
        raise HTTPException(status_code=400, detail="OAuth exchange failed")

    import json
    from app.utils.auth import get_settings as auth_settings
    settings = auth_settings()

    # Encrypt token JSON with Fernet (using SECRET_KEY as base)
    from cryptography.fernet import Fernet
    import base64
    key = base64.urlsafe_b64encode(settings.SECRET_KEY.encode()[:32].ljust(32, b"0"))
    fernet = Fernet(key)
    encrypted = fernet.encrypt(json.dumps(token_data).encode()).decode()

    # Upsert connection record
    result = await db.execute(
        select(GoogleDriveConnection).where(GoogleDriveConnection.account_id == account_id)
    )
    conn = result.scalar_one_or_none()
    if conn:
        conn.encrypted_token_json = encrypted
        conn.last_sync_at = datetime.now(timezone.utc)
    else:
        conn = GoogleDriveConnection(
            account_id=account_id,
            encrypted_token_json=encrypted,
        )
        db.add(conn)

    await db.commit()
    logger.info(f"Google Drive connected for account {account_id}")
    return {"status": "connected"}


@router.get("/files", response_model=list[dict])
async def list_drive_files(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """List spreadsheet/CSV files from the connected Google Drive."""
    result = await db.execute(
        select(GoogleDriveConnection).where(
            GoogleDriveConnection.account_id == current_user.account_id
        )
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(status_code=404, detail="Google Drive not connected")

    from cryptography.fernet import Fernet
    import base64
    settings = get_settings()
    key = base64.urlsafe_b64encode(settings.SECRET_KEY.encode()[:32].ljust(32, b"0"))
    fernet = Fernet(key)
    token_json = fernet.decrypt(conn.encrypted_token_json.encode()).decode()

    try:
        files = GoogleDriveService.list_files(token_json)
        return files
    except Exception as exc:
        logger.error(f"Failed to list Drive files: {exc}")
        raise HTTPException(status_code=502, detail="Failed to list Google Drive files")


@router.post("/disconnect", response_model=MessageResponse)
async def disconnect_google_drive(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Revoke Google Drive access and delete stored tokens."""
    result = await db.execute(
        select(GoogleDriveConnection).where(
            GoogleDriveConnection.account_id == current_user.account_id
        )
    )
    conn = result.scalar_one_or_none()
    if not conn:
        raise HTTPException(status_code=404, detail="Google Drive not connected")

    await db.delete(conn)
    await db.commit()
    logger.info(f"Google Drive disconnected for account {current_user.account_id}")
    return MessageResponse(message="Google Drive disconnected successfully")
