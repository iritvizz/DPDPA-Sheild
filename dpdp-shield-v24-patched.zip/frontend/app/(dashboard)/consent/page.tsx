"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

interface ConsentRecord {
  public_id: string;
  customer_reference: string;
  purpose: string;
  method: string;
  is_revoked: boolean;
  created_at: string;
}

const METHODS = [
  { value: "website_checkbox", label: "Website Checkbox" },
  { value: "physical_form", label: "Physical Form" },
  { value: "verbal", label: "Verbal" },
  { value: "email_confirmation", label: "Email Confirmation" },
  { value: "sms_otp", label: "SMS OTP" },
  { value: "other", label: "Other" },
];

export default function ConsentPage() {
  const t = useTranslations();
  const [records, setRecords] = useState<ConsentRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [businessSlug, setBusinessSlug] = useState("");

  useEffect(() => {
    apiFetch("/api/v1/account")
      .then((data) => setBusinessSlug(data.business_slug))
      .catch(() => {});
  }, []);
  const [success, setSuccess] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);

  const [customerRef, setCustomerRef] = useState("");
  const [purpose, setPurpose] = useState("");
  const [method, setMethod] = useState("website_checkbox");

  const loadRecords = () => {
    setLoading(true);
    apiFetch("/api/v1/consent/records")
      .then((data) => setRecords(data))
      .catch((err) => setError(err.message || "Failed to load consent records"))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadRecords();
  }, []);

  const handleLogConsent = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    setSuccess("");
    try {
      await apiFetch("/api/v1/consent/records", {
        method: "POST",
        body: JSON.stringify({ customer_reference: customerRef, purpose, method }),
      });
      setSuccess("Consent record logged.");
      setCustomerRef("");
      setPurpose("");
      setShowForm(false);
      loadRecords();
    } catch (err: any) {
      setError(err.message || "Failed to log consent.");
    } finally {
      setSaving(false);
    }
  };

  const handleRevoke = async (id: string) => {
    setError("");
    setSuccess("");
    try {
      await apiFetch(`/api/v1/consent/records/${id}/revoke`, { method: "POST" });
      setSuccess("Consent revoked.");
      loadRecords();
    } catch (err: any) {
      setError(err.message || "Failed to revoke consent.");
    }
  };

  const handleWithdrawalLink = async (id: string) => {
    setError("");
    setSuccess("");
    try {
      const res = await apiFetch(`/api/v1/consent/records/${id}/withdrawal-link`, { method: "POST" });
      const url = res.message?.match(/https?:\/\/\S+/)?.[0];
      if (url && typeof navigator !== "undefined" && navigator.clipboard) {
        await navigator.clipboard.writeText(url);
        setSuccess("Withdrawal link copied to clipboard.");
      } else {
        setSuccess(res.message);
      }
    } catch (err: any) {
      setError(err.message || "Failed to generate withdrawal link.");
    }
  };

  const handleExport = async () => {
    setError("");
    try {
      const token = typeof window !== "undefined" ? localStorage.getItem("access_token") : null;
      const base = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
      const res = await fetch(`${base}/api/v1/consent/export?format=csv`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "consent_records.csv";
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      setError(err.message || "Failed to export consent records.");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{t("consent.title")}</h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleExport}>
            {t("consent.export")}
          </Button>
          <Button onClick={() => setShowForm(!showForm)}>{t("consent.logConsent")}</Button>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {success && (
        <Alert>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{t("consent.logConsent")}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogConsent} className="space-y-4">
              <div className="space-y-2">
                <Label>{t("consent.customerReference")}</Label>
                <Input value={customerRef} onChange={(e) => setCustomerRef(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label>{t("consent.purpose")}</Label>
                <Input value={purpose} onChange={(e) => setPurpose(e.target.value)} required placeholder="e.g. marketing, analytics" />
              </div>
              <div className="space-y-2">
                <Label>{t("consent.method")}</Label>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={method}
                  onChange={(e) => setMethod(e.target.value)}
                >
                  {METHODS.map((m) => (
                    <option key={m.value} value={m.value}>{m.label}</option>
                  ))}
                </select>
              </div>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving..." : t("consent.saveAddAnother")}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardContent className="pt-6">
          {loading ? (
            <p className="text-gray-500">Loading consent records...</p>
          ) : records.length === 0 ? (
            <p className="text-gray-500">No consent records yet.</p>
          ) : (
            <div className="space-y-3">
              {records.map((r) => (
                <div key={r.public_id} className="flex items-center justify-between border-b pb-3">
                  <div>
                    <p className="font-medium">
                      {r.customer_reference} <span className="text-gray-400 text-sm">— {r.purpose}</span>
                    </p>
                    <p className="text-sm text-gray-500">
                      {r.method} · {new Date(r.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={r.is_revoked ? "secondary" : "default"}>
                      {r.is_revoked ? t("consent.status") + ": revoked" : "active"}
                    </Badge>
                    {!r.is_revoked && (
                      <>
                        <Button size="sm" variant="outline" onClick={() => handleWithdrawalLink(r.public_id)}>
                          {t("consent.sendLink")}
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleRevoke(r.public_id)}>
                          {t("consent.revoke")}
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>{t("consent.embedWidget")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600">{t("consent.embedDescription")}</p>
          {businessSlug ? (
            <>
              <pre className="bg-gray-900 text-gray-100 p-4 rounded-md text-sm overflow-x-auto">
{`<script>
(function() {
  var s = document.createElement('script');
  s.src = '${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}/api/v1/consent/widget.js';
  s.async = true;
  s.setAttribute('data-business-slug', '${businessSlug}');
  document.head.appendChild(s);
})();
</script>
<div id="dpdp-consent-widget"></div>`}
              </pre>
              <Button onClick={() => {
                navigator.clipboard.writeText(
`<script>
(function() {
  var s = document.createElement('script');
  s.src = '${process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}/api/v1/consent/widget.js';
  s.async = true;
  s.setAttribute('data-business-slug', '${businessSlug}');
  document.head.appendChild(s);
})();
</script>
<div id="dpdp-consent-widget"></div>`
                );
                alert("Copied!");
              }}>
                {t("consent.copyCode")}
              </Button>
            </>
          ) : (
            <p className="text-gray-500">{t("consent.loadingSlug")}</p>
          )}
        </CardContent>
      </Card>

    </div>
  );
}
