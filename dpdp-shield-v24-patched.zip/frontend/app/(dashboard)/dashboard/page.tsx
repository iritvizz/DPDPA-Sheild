"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import Link from "next/link";

interface ChecklistItem {
  key: string;
  label: string;
  completed: boolean;
}

interface DashboardSummary {
  compliance_checklist: ChecklistItem[];
  completed_count: number;
  total_count: number;
  trial_days_remaining: number | null;
  subscription_status: string;
}

export default function DashboardPage() {
  const t = useTranslations();
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiFetch("/api/v1/dashboard/summary")
      .then((data) => setSummary(data))
      .catch((err) => setError(err.message || "Failed to load dashboard"))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <p className="text-gray-500">Loading dashboard...</p>;
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!summary) return null;

  const completed = summary.completed_count;
  const total = summary.total_count;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">{t("dashboard.title")}</h2>
        {summary.subscription_status === "trial" && summary.trial_days_remaining !== null && (
          <p className="text-gray-500 mt-1">
            {t("dashboard.trialDaysRemaining", { days: summary.trial_days_remaining })}
          </p>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t("dashboard.complianceChecklist")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <span className="text-lg font-semibold">
              {completed} {t("dashboard.ofComplete")}
            </span>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all"
                style={{ width: `${total > 0 ? (completed / total) * 100 : 0}%` }}
              />
            </div>
          </div>
          <ul className="space-y-2">
            {summary.compliance_checklist.map((item) => (
              <li key={item.key} className="flex items-center gap-2">
                <Badge variant={item.completed ? "default" : "secondary"}>
                  {item.completed ? "✓" : "○"}
                </Badge>
                <span className={item.completed ? "line-through text-gray-400" : ""}>
                  {item.label}
                </span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div>
        <h3 className="text-lg font-semibold mb-3">{t("dashboard.quickActions")}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { href: "/inventory", label: t("dashboard.dataInventory") },
            { href: "/privacy-notice", label: t("dashboard.privacyNotice") },
            { href: "/consent", label: t("dashboard.consentManagement") },
            { href: "/reports", label: t("dashboard.generateAuditPack") },
          ].map((action) => (
            <Link key={action.href} href={action.href}>
              <Button variant="outline" className="w-full h-24 flex flex-col gap-2">
                <span className="text-2xl">→</span>
                <span>{action.label}</span>
              </Button>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
