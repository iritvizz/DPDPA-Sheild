"""User management routes."""
import uuid
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.services.user_service import remove_user_from_account
from app.models import User, UserInvitation, UserRole
from app.schemas import (
    MessageResponse,
    UserInviteRequest,
    UserInvitationResponse,
    UserResponse,
)
from app.utils.auth import (
    generate_invitation_token,
    get_current_active_user,
    get_password_hash,
    require_admin,
)
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/users", tags=["users"])


@router.get("", response_model=list[UserResponse])
async def list_users(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List all users in the account."""
    result = await db.execute(
        select(User).where(User.account_id == current_user.account_id)
    )
    return result.scalars().all()


@router.post("/invite", response_model=MessageResponse, status_code=status.HTTP_201_CREATED)
async def invite_user(
    data: UserInviteRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Invite a new staff user by email."""
    # Check if email already exists
    existing = await db.execute(
        select(User).where(
            User.account_id == current_user.account_id,
            User.email == data.email,
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="User already exists in this account")

    # Check for pending invitation
    pending = await db.execute(
        select(UserInvitation).where(
            UserInvitation.account_id == current_user.account_id,
            UserInvitation.email == data.email,
            UserInvitation.used_at.is_(None),
            UserInvitation.expires_at > datetime.now(timezone.utc),
        )
    )
    if pending.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Pending invitation already exists")

    token = generate_invitation_token()
    invitation = UserInvitation(
        account_id=current_user.account_id,
        email=data.email,
        token=token,
        role=data.role,
        expires_at=datetime.now(timezone.utc) + timedelta(hours=48),
    )
    db.add(invitation)
    await db.commit()

    # TODO: Send invitation email
    logger.info(f"Invitation sent to {data.email} for account {current_user.account_id}")

    return MessageResponse(
        message=f"Invitation sent to {data.email}. Valid for 48 hours."
    )


@router.post("/accept-invite", response_model=MessageResponse)
async def accept_invitation(
    token: str,
    password: str,
    full_name: str,
    db: AsyncSession = Depends(get_db),
):
    """Accept an invitation and create user account."""
    result = await db.execute(
        select(UserInvitation).where(
            UserInvitation.token == token,
            UserInvitation.used_at.is_(None),
            UserInvitation.expires_at > datetime.now(timezone.utc),
        )
    )
    invitation = result.scalar_one_or_none()

    if not invitation:
        raise HTTPException(status_code=400, detail="Invalid or expired invitation token")

    # Create user
    user = User(
        account_id=invitation.account_id,
        email=invitation.email,
        password_hash=get_password_hash(password),
        full_name=full_name,
        role=invitation.role,
        is_verified=True,
    )
    db.add(user)

    invitation.used_at = datetime.now(timezone.utc)
    await db.commit()

    return MessageResponse(message="Invitation accepted. You can now log in.")


@router.delete("/{user_id}", response_model=MessageResponse)
async def remove_user(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Remove a staff user from the account."""
    message = await remove_user_from_account(
        user_id=user_id,
        account_id=current_user.account_id,
        db=db,
    )
    return MessageResponse(message=message)
