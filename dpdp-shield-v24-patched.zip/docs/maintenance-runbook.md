# DPDP Shield — Maintenance Runbook

## 1. Daily Checks

### 1.1 Application Health

```bash
# Backend health
curl -s https://api.dpdp-shield.in/health | jq .

# Frontend health (Vercel status page)
curl -s https://app.dpdp-shield.in | head -1

# Celery worker queue depth
redis-cli -h <elasticache-endpoint> LLEN celery
# Expected: < 100. If > 1000, investigate stuck tasks.
```

### 1.2 Error Logs

```bash
# ECS backend logs (CloudWatch)
aws logs tail /ecs/dpdp-backend --follow --region ap-south-1

# Filter for 5xx errors
aws logs filter-log-events \
  --log-group-name /ecs/dpdp-backend \
  --filter-pattern '{ $.status_code >= 500 }' \
  --region ap-south-1
```

### 1.3 Database Metrics

```bash
# RDS CloudWatch metrics (via console or CLI)
aws cloudwatch get-metric-statistics \
  --namespace AWS/RDS \
  --metric-name DatabaseConnections \
  --dimensions Name=DBInstanceIdentifier,Value=dpdp-shield-db \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Average \
  --region ap-south-1
```

## 2. Backup & Restore

### 2.1 Automated Backups

RDS automated daily backups are enabled (30-day retention). Point-in-time recovery is available.

### 2.2 Manual Snapshot

```bash
aws rds create-db-snapshot \
  --db-instance-identifier dpdp-shield-db \
  --db-snapshot-identifier dpdp-shield-manual-$(date +%Y%m%d) \
  --region ap-south-1
```

### 2.3 Restore from Snapshot

```bash
aws rds restore-db-instance-from-db-snapshot \
  --db-instance-identifier dpdp-shield-db-restored \
  --db-snapshot-identifier dpdp-shield-manual-20240115 \
  --vpc-security-group-ids sg-rds \
  --db-subnet-group-name dpdp-private \
  --region ap-south-1
```

**After restore:** Update `DATABASE_URL` in ECS task definition, redeploy.

### 2.4 S3 Backup Verification

```bash
# List proof bucket versions (should show multiple versions if enabled)
aws s3api list-object-versions --bucket dpdp-shield-proofs-ap-south-1 --prefix audit/

# Verify PDF bucket lifecycle
aws s3api get-bucket-lifecycle-configuration --bucket dpdp-shield-pdfs-ap-south-1
```

## 3. Common Troubleshooting

### 3.1 High Error Rate (5xx)

1. Check CloudWatch logs for stack traces
2. Check RDS connection count (max ~100 for db.t3.medium)
3. Check Redis memory usage (ElastiCache dashboard)
4. If DB connections maxed: restart ECS service to clear connection pool

### 3.2 Celery Tasks Stuck

```bash
# Inspect queue
redis-cli -h <elasticache-endpoint> LRANGE celery 0 10

# Purge queue (nuclear option — only if tasks are genuinely dead)
redis-cli -h <elasticache-endpoint> DEL celery

# Restart worker ECS service
aws ecs update-service --cluster dpdp-shield --service dpdp-worker --force-new-deployment
```

### 3.3 Alembic Migration Failed

```bash
# Check current revision
alembic current

# Check history
alembic history --verbose

# Manual fix: mark as applied (only if you know the schema is correct)
alembic stamp <revision-id>

# Or downgrade and retry
alembic downgrade -1
alembic upgrade head
```

### 3.4 S3 Pre-signed URL Expired

Pre-signed URLs expire after 5 minutes (proofs) or 7 days (audit packs). If users report broken download links:

1. Check `expires_at` on `AuditPackGeneration` record
2. If expired: trigger new generation via Reports page
3. For consent proofs: link is generated on-demand, so just refresh the page

### 3.5 Google Drive OAuth Failing

1. Verify `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in ECS task definition
2. Check redirect URI in Google Cloud Console matches `FRONTEND_URL`/inventory
3. Verify OAuth consent screen is published (not in testing mode)

### 3.6 Razorpay Webhook Not Arriving

1. Verify webhook URL in Razorpay dashboard: `https://api.dpdp-shield.in/api/v1/webhooks/razorpay`
2. Check `RAZORPAY_WEBHOOK_SECRET` matches dashboard value
3. Check CloudWatch logs for `razorpay` webhook handler entries

## 4. Security Incidents

### 4.1 Suspected Data Breach

1. **Isolate:** Change `SECRET_KEY` immediately, force all users to re-login
2. **Audit:** Export `AuditLog` table for the incident window
3. **Notify:** Check DPDPA breach notification requirements (72 hours to Data Protection Board)
4. **Preserve:** Create RDS snapshot and S3 object version capture before any cleanup

### 4.2 Dependency Vulnerability Discovered

```bash
# Run audit
pip-audit
npm audit

# If critical: bump version in requirements.txt or package.json
# Test in staging first
# Deploy via standard CI/CD pipeline
```

## 5. Scaling

### 5.1 Horizontal Scaling (ECS)

```bash
# Increase desired count
aws ecs update-service --cluster dpdp-shield --service dpdp-backend --desired-count 4

# Auto-scaling policy (target CPU 70%)
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --resource-id service/dpdp-shield/dpdp-backend \
  --scalable-dimension ecs:service:DesiredCount \
  --min-capacity 2 \
  --max-capacity 10 \
  --region ap-south-1
```

### 5.2 Database Scaling

- Read replicas: Add up to 5 read replicas for reporting queries
- Instance class: `db.t3.medium` → `db.r6g.large` for CPU/memory bound workloads
- Connection pooling: PgBouncer in front of RDS if connections exceed ~200

## 6. Contact Escalation

| Severity | Response Time | Action |
|---|---|---|
| Critical (data breach, full outage) | 15 min | Page on-call engineer, begin incident response |
| High (partial outage, payment failure) | 1 hour | Investigate logs, escalate if not resolved in 2 hours |
| Medium (slow performance, non-critical bug) | 4 hours | Add to sprint, deploy in next release |
| Low (UI polish, feature request) | 48 hours | Backlog, prioritize in next planning |
