"""Retention & Deletion Logging tests."""
import secrets
import uuid

import pytest
from fastapi import status
from httpx import AsyncClient

from app.models import Account, DataElement, DataSource, DataSourceStatus, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_list_retention_expiries_empty(async_client: AsyncClient, db_session):
    """Retention expiries returns empty list when no confirmed sources."""
    account = Account(
        business_name="Retention Test",
        business_slug="retention-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="ret@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})
    response = await async_client.get(
        "/api/v1/retention/expiries",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    assert response.json() == []


@pytest.mark.asyncio
async def test_list_retention_expiries_with_data(async_client: AsyncClient, db_session):
    """Retention expiries lists elements whose retention period is within warning window."""
    from datetime import datetime, timezone, timedelta

    account = Account(
        business_name="Retention Test",
        business_slug="retention-test-2",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="ret2@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    source = DataSource(
        account_id=account.id,
        name="Customers",
        source_type="upload",
        status=DataSourceStatus.CONFIRMED,
        created_at=datetime.now(timezone.utc) - timedelta(days=350),
    )
    db_session.add(source)
    await db_session.flush()

    element = DataElement(
        data_source_id=source.id,
        field_name="email",
        data_category="personal",
        purposes=["marketing"],
        retention_period_value=1,
        retention_period_unit="year",
    )
    db_session.add(element)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})
    response = await async_client.get(
        "/api/v1/retention/expiries?days_warning=30",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["field_name"] == "email"
    assert data[0]["days_remaining"] <= 15  # 365 - 350 = ~15 days remaining


@pytest.mark.asyncio
async def test_deletion_log_creation(async_client: AsyncClient, db_session):
    """Deletion attestation is logged to AuditLog."""
    account = Account(
        business_name="Deletion Test",
        business_slug="deletion-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="del@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    source = DataSource(
        account_id=account.id,
        name="Old Customers",
        source_type="upload",
        status=DataSourceStatus.CONFIRMED,
    )
    db_session.add(source)
    await db_session.commit()
    await db_session.refresh(source)

    token = create_access_token({"sub": str(user.public_id)})
    response = await async_client.post(
        "/api/v1/retention/deletion-log",
        json={
            "data_source_public_id": str(source.public_id),
            "field_names": ["email", "phone"],
            "deletion_method": "Secure wipe via DB admin panel",
            "notes": "Confirmed by IT head",
        },
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["action"] == "deletion_attestation"
    assert data["data_source_public_id"] == str(source.public_id)
    assert data["field_names"] == ["email", "phone"]
    assert data["deletion_method"] == "Secure wipe via DB admin panel"
    assert "log_id" in data


@pytest.mark.asyncio
async def test_deletion_log_rejects_other_account_source(async_client: AsyncClient, db_session):
    """Submitting another account's data_source_public_id returns 404."""
    account_a = Account(
        business_name="Account A",
        business_slug="account-a",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account_a)
    await db_session.flush()

    account_b = Account(
        business_name="Account B",
        business_slug="account-b",
        sector="Services",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account_b)
    await db_session.flush()

    user_b = User(
        account_id=account_b.id,
        email="user-b@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user_b)

    source_a = DataSource(
        account_id=account_a.id,
        name="A's Data",
        source_type="upload",
        status=DataSourceStatus.CONFIRMED,
    )
    db_session.add(source_a)
    await db_session.commit()
    await db_session.refresh(source_a)

    token_b = create_access_token({"sub": str(user_b.public_id)})
    response = await async_client.post(
        "/api/v1/retention/deletion-log",
        json={
            "data_source_public_id": str(source_a.public_id),
            "field_names": ["email"],
            "deletion_method": "Wipe",
        },
        headers={"Authorization": f"Bearer {token_b}"},
    )
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()
