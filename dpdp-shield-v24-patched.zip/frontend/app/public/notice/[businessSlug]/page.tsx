import { getTranslations } from "next-intl/server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface NoticeSection {
  order: number;
  title: string;
  content: string;
}

interface PublicNotice {
  business_name: string;
  business_slug: string;
  content: { language: string; sections: NoticeSection[] };
}

async function getNotice(businessSlug: string): Promise<PublicNotice | null> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const res = await fetch(`${apiUrl}/api/v1/privacy-notice/public/${businessSlug}`, {
      cache: "no-store",
    });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

export default async function PublicNoticePage({
  params,
}: {
  params: { businessSlug: string };
}) {
  const t = await getTranslations();
  const notice = await getNotice(params.businessSlug);

  if (!notice) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-3xl mx-auto px-4">
          <Card>
            <CardContent className="pt-6">
              <p className="text-gray-500">
                No published privacy notice was found for this business.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const sections = [...(notice.content?.sections || [])].sort((a, b) => a.order - b.order);

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4">
        <Card>
          <CardHeader>
            <CardTitle>{notice.business_name} — {t("privacyNotice.title")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {sections.map((s) => (
                <div key={s.order}>
                  <h3 className="font-semibold text-lg mb-1">{s.title}</h3>
                  <p className="text-gray-700 whitespace-pre-line">{s.content}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
