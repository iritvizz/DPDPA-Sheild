# DPDP Shield — Deployment Guide (AWS Mumbai, ap-south-1)

## Architecture Overview

```
+---------------+     +---------------+     +---------------+
|  CloudFront   |---->| Vercel / ECS  |---->| FastAPI (ECS) |
|  (Frontend)   |     |  (Next.js)    |     |  (Backend)    |
+---------------+     +---------------+     +---------------+
                                                  |
                      +---------------+            |
                      | PostgreSQL RDS|<-----------+
                      | (ap-south-1)  |
                      +---------------+
                              |
                      +---------------+
                      | ElastiCache   |
                      |   (Redis)     |
                      +---------------+
                              |
                      +---------------+
                      |   S3 Mumbai   |
                      | (PDFs+proofs) |
                      +---------------+
```

## 1. Infrastructure Provisioning

### 1.1 VPC & Networking

- Create VPC in `ap-south-1` with 2 public + 2 private subnets across AZs
- Internet Gateway for public subnets
- NAT Gateway for private subnets (ECS tasks, RDS, Redis)
- Security groups:
  - `sg-backend`: Inbound 8000 from ALB only
  - `sg-rds`: Inbound 5432 from `sg-backend` only
  - `sg-redis`: Inbound 6379 from `sg-backend` only
  - `sg-alb`: Inbound 80/443 from 0.0.0.0/0

### 1.2 RDS PostgreSQL 15

```bash
aws rds create-db-instance \
  --db-instance-identifier dpdp-shield-db \
  --db-instance-class db.t3.medium \
  --engine postgres \
  --engine-version 15.4 \
  --allocated-storage 20 \
  --storage-type gp3 \
  --master-username dpdp_admin \
  --master-user-password <strong-password> \
  --vpc-security-group-ids sg-rds \
  --db-subnet-group-name dpdp-private \
  --backup-retention-period 30 \
  --preferred-backup-window 03:00-04:00 \
  --enable-performance-insights \
  --region ap-south-1
```

### 1.3 ElastiCache Redis 7

```bash
aws elasticache create-cache-cluster \
  --cache-cluster-id dpdp-shield-redis \
  --engine redis \
  --cache-node-type cache.t3.micro \
  --num-cache-nodes 1 \
  --security-group-ids sg-redis \
  --region ap-south-1
```

### 1.4 S3 Buckets (Mumbai)

```bash
# Generated PDFs (public read via CloudFront, private direct)
aws s3 mb s3://dpdp-shield-pdfs-ap-south-1 --region ap-south-1
aws s3api put-bucket-versioning --bucket dpdp-shield-pdfs-ap-south-1 --versioning-configuration Status=Enabled

# Consent proof attachments (private, encrypted, scanned)
aws s3 mb s3://dpdp-shield-proofs-ap-south-1 --region ap-south-1
aws s3api put-bucket-encryption --bucket dpdp-shield-proofs-ap-south-1 \
  --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

# Block all public access on proof bucket
aws s3api put-public-access-block --bucket dpdp-shield-proofs-ap-south-1 \
  --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
```

### 1.5 ECS Fargate (Backend)

```bash
# Create cluster
aws ecs create-cluster --cluster-name dpdp-shield --region ap-south-1

# Create task definition (see backend/task-definition.json)
aws ecs register-task-definition --cli-input-json file://backend/task-definition.json

# Create service behind ALB
aws ecs create-service \
  --cluster dpdp-shield \
  --service-name dpdp-backend \
  --task-definition dpdp-backend:1 \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx,subnet-yyy],securityGroups=[sg-backend],assignPublicIp=DISABLED}" \
  --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:ap-south-1:xxx:targetgroup/dpdp-backend-tg,containerName=backend,containerPort=8000" \
  --region ap-south-1
```

### 1.6 Vercel (Frontend)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
# Set environment variables in Vercel dashboard:
#   NEXT_PUBLIC_API_URL=https://api.dpdp-shield.in
```

## 2. Environment Variables

### Backend (ECS Task Definition / .env)

| Variable | Value | Source |
|---|---|---|
| `DATABASE_URL` | `postgresql+asyncpg://...` | RDS endpoint |
| `REDIS_URL` | `redis://...` | ElastiCache endpoint |
| `SECRET_KEY` | 64-char hex | `openssl rand -hex 32` |
| `FRONTEND_URL` | `https://app.dpdp-shield.in` | Vercel domain |
| `AWS_ACCESS_KEY_ID` | IAM key | ECS task role (preferred) |
| `AWS_SECRET_ACCESS_KEY` | IAM secret | ECS task role (preferred) |
| `AWS_REGION` | `ap-south-1` | Hardcoded |
| `S3_BUCKET_PDFS` | `dpdp-shield-pdfs-ap-south-1` | S3 bucket name |
| `S3_BUCKET_PROOFS` | `dpdp-shield-proofs-ap-south-1` | S3 bucket name |
| `GOOGLE_CLIENT_ID` | OAuth client ID | Google Cloud Console |
| `GOOGLE_CLIENT_SECRET` | OAuth secret | Google Cloud Console |
| `RAZORPAY_KEY_ID` | Razorpay key | Razorpay Dashboard |
| `RAZORPAY_KEY_SECRET` | Razorpay secret | Razorpay Dashboard |
| `RAZORPAY_WEBHOOK_SECRET` | Webhook verify secret | Razorpay Dashboard |
| `SES_FROM_EMAIL` | `noreply@dpdp-shield.in` | AWS SES verified |
| `TWILIO_ACCOUNT_SID` | Twilio SID | Twilio Console (optional) |
| `TWILIO_AUTH_TOKEN` | Twilio token | Twilio Console (optional) |

### Frontend

**Build verification:** Before any deploy, run `npm run build` and confirm exit code 0. This is the exact command the Dockerfile runs — if it fails here, the container image cannot be built.
 (Vercel Environment)

| Variable | Value |
|---|---|
| `NEXT_PUBLIC_API_URL` | `https://api.dpdp-shield.in` |
| `NEXT_PUBLIC_APP_NAME` | `DPDP Shield` |

## 3. Database Migration on Deploy

```bash
# Run from an ECS task or local machine with DB access
alembic upgrade head
```

## 4. SSL / HTTPS

- ALB uses ACM certificate for `api.dpdp-shield.in`
- CloudFront uses ACM certificate for `app.dpdp-shield.in`
- HSTS header enabled at ALB level

## 5. Health Checks

```bash
curl https://api.dpdp-shield.in/health
curl https://api.dpdp-shield.in/api/v1/health
```

Expected: `{"status":"ok"}`

## 6. Rollback Procedure

```bash
# Database rollback (last migration)
alembic downgrade -1

# ECS rollback (previous task definition)
aws ecs update-service --cluster dpdp-shield --service dpdp-backend --task-definition dpdp-backend:<prev-revision>

# Vercel rollback
vercel --prod --target=production --meta rollback=true
```
