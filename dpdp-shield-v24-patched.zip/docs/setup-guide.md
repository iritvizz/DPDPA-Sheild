# DPDP Shield — Local Development Setup Guide

## Prerequisites

- Python 3.11+
- Node.js 18+ (LTS)
- PostgreSQL 15+ (local or Docker)
- Redis 7+ (local or Docker)
- AWS CLI configured (for S3 access, or use `moto` for local testing)
- Google OAuth credentials (optional, for Drive integration testing)

## 1. Clone & Enter Directory

```bash
git clone <repo-url>
cd dpdp-shield
```

## 2. Backend Setup

### 2.1 Create Python virtual environment

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

### 2.2 Install dependencies

```bash
pip install -r requirements.txt
```

### 2.3 Configure environment

```bash
cp ../.env.example .env
# Edit .env with your local values:
#   DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/dpdp_shield
#   REDIS_URL=redis://localhost:6379/0
#   SECRET_KEY=<generate with: openssl rand -hex 32>
#   FRONTEND_URL=http://localhost:3000
```

### 2.4 Initialize database

```bash
alembic upgrade head
```

### 2.5 Start backend

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Health check: `curl http://localhost:8000/health`

## 3. Frontend Setup

```bash
cd ../frontend
npm install
```

### 3.1 Configure environment

```bash
# No separate .env.example in frontend/ — use the root one or create manually:
echo "NEXT_PUBLIC_API_URL=http://localhost:8000" > .env.local
```

### 3.2 Start frontend

```bash
npm run dev
```

Visit: `http://localhost:3000`

## 4. Celery Worker (for background tasks)

In a separate terminal:

```bash
cd backend
source venv/bin/activate
celery -A app.tasks worker --loglevel=info
```

## 5. Celery Beat (for scheduled jobs)

In another terminal:

```bash
cd backend
source venv/bin/activate
celery -A app.tasks beat --loglevel=info
```

## 6. Verify Everything Works

Run the full test suite:

```bash
cd backend
pytest tests/ -v
```

Expected: 50+ tests passing, zero failures.

## 7. Common Issues

| Issue | Fix |
|---|---|
| `asyncpg` connection refused | Ensure PostgreSQL is running and credentials match `.env` |
| `redis` connection refused | Start Redis: `redis-server` or `docker run -p 6379:6379 redis:7` |
| `libmagic` missing | `apt-get install libmagic1` (Ubuntu/Debian) or `brew install libmagic` (macOS) |
| Gujarati fonts not rendering in PDF | Install system fonts: `apt-get install fonts-noto` |
| `next/font/google` fetch fails during build | Use local font files instead: place `.woff2` files in `frontend/public/fonts/` and reference them in your CSS or component imports. Do not rely on `next/font/google` in sandboxed or air-gapped environments. |
