"""PDF generation service."""
import tempfile
from datetime import datetime, timezone
from typing import Optional

from app.config import get_settings
from app.utils.logging import get_logger

logger = get_logger(__name__)


class PDFService:
    """PDF generation with WeasyPrint (primary) and headless Chrome fallback."""

    def __init__(self):
        self.settings = get_settings()
        self._engine = None
        self._tested = False

    def _get_engine(self):
        """Lazy-load and test the PDF engine."""
        if self._engine is not None:
            return self._engine

        # Try WeasyPrint first
        try:
            import weasyprint
            # Quick test with sample text
            test_html = "<html><body><p>Test</p></body></html>"
            weasyprint.HTML(string=test_html).write_pdf()
            self._engine = "weasyprint"
            logger.info("PDF engine: WeasyPrint")
            return self._engine
        except Exception as e:
            logger.warning(f"WeasyPrint failed: {e}")

        # Fallback to headless Chrome
        try:
            import subprocess
            result = subprocess.run(
                ["google-chrome", "--version"],
                capture_output=True,
                timeout=5,
            )
            if result.returncode == 0:
                self._engine = "chrome"
                logger.info("PDF engine: Headless Chrome")
                return self._engine
        except Exception:
            pass

        # Ultimate fallback: generate HTML file
        self._engine = "html"
        logger.warning("PDF engine: HTML fallback (no PDF library available)")
        return self._engine

    def generate_pdf(self, html_content: str, output_path: str) -> str:
        """Generate PDF from HTML content.

        Returns the path to the generated PDF file.
        """
        engine = self._get_engine()

        if engine == "weasyprint":
            import weasyprint
            pdf = weasyprint.HTML(string=html_content).write_pdf()
            with open(output_path, "wb") as f:
                f.write(pdf)
            return output_path

        elif engine == "chrome":
            import subprocess
            # Write HTML to temp file
            html_path = output_path.replace(".pdf", ".html")
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(html_content)

            subprocess.run([
                "google-chrome",
                "--headless",
                "--disable-gpu",
                "--print-to-pdf=" + output_path,
                html_path,
            ], check=True, timeout=30)

            # Clean up temp HTML
            os.remove(html_path)
            return output_path

        else:
            # HTML fallback
            html_path = output_path.replace(".pdf", ".html")
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(html_content)
            logger.warning(f"PDF generation unavailable. HTML saved to {html_path}")
            return html_path

    def generate_audit_pack_html(
        self,
        account: dict,
        data_sources: list,
        privacy_notices: list,
        consent_records: list,
        audit_logs: list,
    ) -> str:
        """Generate HTML content for the audit pack."""

        now = datetime.now(timezone.utc).strftime("%B %d, %Y at %H:%M UTC")

        # Build data sources table
        ds_html = ""
        for ds in data_sources:
            elements = ds.get("elements", [])
            elements_rows = ""
            for elem in elements:
                elements_rows += f"""
                <tr>
                    <td>{elem.get("field_name", "")}</td>
                    <td>{elem.get("data_category", "")}</td>
                    <td>{", ".join(elem.get("purposes", []))}</td>
                    <td>{elem.get("retention", "N/A")}</td>
                </tr>
                """

            ds_html += f"""
            <div style="margin-bottom: 20px; page-break-inside: avoid;">
                <h3>{ds.get("name", "Unnamed Source")}</h3>
                <p>Type: {ds.get("source_type", "N/A")} | Status: {ds.get("status", "N/A")} | 
                   Columns: {ds.get("column_count", "N/A")} | Rows: {ds.get("row_count", "N/A")}</p>
                <table>
                    <thead>
                        <tr><th>Field</th><th>Category</th><th>Purposes</th><th>Retention</th></tr>
                    </thead>
                    <tbody>{elements_rows}</tbody>
                </table>
            </div>
            """

        # Build consent summary
        consent_summary = ""
        active_count = sum(1 for c in consent_records if not c.get("is_revoked"))
        revoked_count = len(consent_records) - active_count

        consent_summary = f"""
        <p>Total Records: {len(consent_records)} | Active: {active_count} | Revoked: {revoked_count}</p>
        <table>
            <thead>
                <tr><th>Reference</th><th>Purpose</th><th>Method</th><th>Status</th><th>Date</th></tr>
            </thead>
            <tbody>
        """
        for record in consent_records[:50]:  # Limit to 50 for PDF size
            status = "Revoked" if record.get("is_revoked") else "Active"
            date_str = record.get("created_at", "N/A")
            if isinstance(date_str, str) and "T" in date_str:
                date_str = date_str[:10]
            consent_summary += f"""
            <tr>
                <td>{record.get("customer_reference", "N/A")}</td>
                <td>{record.get("purpose", "N/A")}</td>
                <td>{record.get("method", "N/A")}</td>
                <td>{status}</td>
                <td>{date_str}</td>
            </tr>
            """
        consent_summary += "</tbody></table>"

        # Published notice info
        published_notice = next((n for n in privacy_notices if n.get("is_published")), None)
        notice_info = "No privacy notice published."
        if published_notice:
            notice_info = f"""
            <p>Version {published_notice.get("version", "N/A")} | 
               Published: {published_notice.get("published_at", "N/A")}</p>
            <p>Template: {published_notice.get("template_type", "N/A")}</p>
            """

        # Grievance contact
        grievance = ""
        if account.get("grievance_email"):
            grievance += f"<p>Email: {account['grievance_email']}</p>"
        if account.get("grievance_phone"):
            grievance += f"<p>Phone: {account['grievance_phone']}</p>"
        if account.get("grievance_address"):
            grievance += f"<p>Address: {account['grievance_address']}</p>"
        if not grievance:
            grievance = "<p>Not configured.</p>"

        # Assemble full HTML
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Audit Pack - {account.get("business_name", "Unknown")}</title>
    <style>
        @page {{ size: A4; margin: 2cm; }}
        body {{ font-family: "Noto Sans Gujarati", "Noto Sans Devanagari", "Noto Sans", "DejaVu Sans", Arial, sans-serif; font-size: 11pt; line-height: 1.5; color: #333; }}
        h1 {{ font-size: 24pt; color: #1a365d; border-bottom: 3px solid #1a365d; padding-bottom: 10px; }}
        h2 {{ font-size: 16pt; color: #2c5282; margin-top: 30px; border-bottom: 1px solid #e2e8f0; padding-bottom: 5px; }}
        h3 {{ font-size: 13pt; color: #2d3748; margin-top: 20px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 10pt; }}
        th, td {{ border: 1px solid #cbd5e0; padding: 8px; text-align: left; }}
        th {{ background: #edf2f7; font-weight: 600; }}
        tr:nth-child(even) {{ background: #f7fafc; }}
        .cover {{ text-align: center; padding: 100px 0; }}
        .cover h1 {{ border: none; font-size: 28pt; }}
        .meta {{ color: #718096; font-size: 10pt; margin-top: 20px; }}
        .footer {{ margin-top: 50px; padding-top: 20px; border-top: 1px solid #e2e8f0; font-size: 9pt; color: #a0aec0; text-align: center; }}
        .checklist {{ background: #f0fff4; border: 1px solid #9ae6b4; padding: 15px; border-radius: 5px; }}
        .checklist-item {{ margin: 5px 0; }}
        .check {{ color: #38a169; font-weight: bold; }}
        .cross {{ color: #e53e3e; font-weight: bold; }}
    </style>
</head>
<body>
    <div class="cover">
        <h1>DPDPA Compliance Audit Pack</h1>
        <p style="font-size: 18pt; color: #4a5568;">{account.get("business_name", "Unknown Business")}</p>
        <p class="meta">Generated on {now}<br>
        Generated by DPDP Shield<br>
        Business ID: {account.get("public_id", "N/A")}</p>
    </div>

    <div style="page-break-before: always;">
        <h2>1. Compliance Checklist</h2>
        <div class="checklist">
            <div class="checklist-item"><span class="check">✓</span> Data Inventory: {len(data_sources)} source(s) mapped</div>
            <div class="checklist-item"><span class="{'check' if published_notice else 'cross'}">{'✓' if published_notice else '✗'}</span> Privacy Notice: {'Published' if published_notice else 'Not published'}</div>
            <div class="checklist-item"><span class="check">✓</span> Consent Records: {len(consent_records)} record(s)</div>
            <div class="checklist-item"><span class="{'check' if account.get('grievance_email') else 'cross'}">{'✓' if account.get('grievance_email') else '✗'}</span> Grievance Contact: {'Configured' if account.get('grievance_email') else 'Not configured'}</div>
        </div>
    </div>

    <div style="page-break-before: always;">
        <h2>2. Data Inventory Summary</h2>
        {ds_html if ds_html else "<p>No data sources configured.</p>"}
    </div>

    <div style="page-break-before: always;">
        <h2>3. Privacy Notice</h2>
        {notice_info}
    </div>

    <div style="page-break-before: always;">
        <h2>4. Consent Records Summary</h2>
        {consent_summary}
    </div>

    <div style="page-break-before: always;">
        <h2>5. Grievance Mechanism</h2>
        {grievance}
    </div>

    <div style="page-break-before: always;">
        <h2>6. Records of Processing Activities (RoPA)</h2>
        <p>The following table summarizes processing activities based on confirmed data inventory entries:</p>
        <table>
            <thead>
                <tr>
                    <th>Data Source</th>
                    <th>Data Categories</th>
                    <th>Purposes</th>
                    <th>Legal Basis</th>
                    <th>Retention</th>
                    <th>Third-Party Sharing</th>
                </tr>
            </thead>
            <tbody>
        """

        # RoPA rows from data sources
        for ds in data_sources:
            for elem in ds.get("elements", []):
                third_party = "Yes" if elem.get("third_party_sharing") else "No"
                html += f"""
                <tr>
                    <td>{ds.get("name", "N/A")}</td>
                    <td>{elem.get("field_name", "N/A")} ({elem.get("data_category", "N/A")})</td>
                    <td>{", ".join(elem.get("purposes", []))}</td>
                    <td>{elem.get("legal_basis") or "Legitimate Interest"}</td>
                    <td>{elem.get("retention") or "Not specified"}</td>
                    <td>{third_party}</td>
                </tr>
                """

        html += """
            </tbody>
        </table>
    </div>

    <div class="footer">
        <p>This audit pack was generated by DPDP Shield and is intended for internal compliance documentation.</p>
        <p>It does not constitute legal advice. Please consult a qualified legal professional for DPDPA compliance matters.</p>
    </div>
</body>
</html>"""

        return html
