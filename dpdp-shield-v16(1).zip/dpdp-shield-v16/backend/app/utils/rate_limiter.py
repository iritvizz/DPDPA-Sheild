"""Rate limiting middleware with Redis support."""
import time
from typing import Optional

from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import get_settings
from app.utils.logging import get_logger

logger = get_logger(__name__)

# In-memory store for rate limiting (fallback when Redis unavailable)
_memory_store: dict = {}


def _get_redis_client():
    """Get Redis client if available."""
    try:
        import redis
        settings = get_settings()
        client = redis.from_url(settings.REDIS_URL, decode_responses=True)
        client.ping()
        return client
    except Exception:
        return None


def _get_client_ip(request: Request) -> str:
    """Get client IP from request."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def _check_rate_limit(key: str, limit: int, window: int) -> bool:
    """Check if request is within rate limit using Redis or in-memory fallback."""
    now = time.time()

    # Try Redis first
    redis_client = _get_redis_client()
    if redis_client:
        try:
            # Use Redis sorted set for sliding window
            pipe = redis_client.pipeline()
            # Remove old entries
            pipe.zremrangebyscore(key, 0, now - window)
            # Count current entries
            pipe.zcard(key)
            # Add current request
            pipe.zadd(key, {str(now): now})
            # Set expiry on the key
            pipe.expire(key, window)
            results = pipe.execute()
            current_count = results[1]

            return current_count < limit
        except Exception as e:
            logger.warning(f"Redis rate limit failed, falling back to memory: {e}")

    # In-memory fallback
    if key in _memory_store:
        _memory_store[key] = [
            t for t in _memory_store[key] if now - t < window
        ]
    else:
        _memory_store[key] = []

    if len(_memory_store[key]) >= limit:
        return False

    _memory_store[key].append(now)
    return True


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware for FastAPI.

    Uses Redis when available for distributed rate limiting across workers.
    Falls back to in-memory dict for single-instance deployments.

    NOTE: In-memory fallback will not work correctly with multiple workers
    or containers. Use Redis in production.
    """

    async def dispatch(self, request: Request, call_next):
        settings = get_settings()
        path = request.url.path
        method = request.method

        # Skip rate limiting for health checks and public notice pages
        if path in ("/health", "/docs", "/openapi.json"):
            return await call_next(request)

        client_ip = _get_client_ip(request)

        def _too_many_requests(detail: str) -> JSONResponse:
            # Returning a Response here, not raising HTTPException.
            # Confirmed live by direct testing: BaseHTTPMiddleware.dispatch()
            # does not catch a raised HTTPException the way FastAPI's route
            # handling does -- it escapes as an unhandled exception and
            # becomes a bare 500, not the intended 429. Reproduced directly:
            # attempts 6-8 of a login-rate-limit test returned
            # "500 Internal Server Error" instead of 429 until this was fixed.
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={"detail": detail},
                headers={"Retry-After": "60"},
            )

        # Login endpoint: 5 per minute per IP
        if path == "/api/v1/auth/login" and method == "POST":
            key = f"ratelimit:login:{client_ip}"
            if not _check_rate_limit(key, settings.RATE_LIMIT_LOGIN_PER_MINUTE, 60):
                logger.warning(f"Rate limit exceeded for login: {client_ip}")
                return _too_many_requests("Too many login attempts. Please try again later.")

        # Public consent widget: its own, more generous bucket -- must not
        # share the strict login limit, since real customers behind a shared
        # office/campus/carrier IP can easily exceed 5 consent submissions a
        # minute, and that isn't the same threat as repeated login attempts.
        elif path == "/api/v1/consent/widget/capture" and method == "POST":
            key = f"ratelimit:widget:{client_ip}"
            if not _check_rate_limit(key, settings.RATE_LIMIT_WIDGET_PER_MINUTE, 60):
                logger.warning(f"Rate limit exceeded for widget capture: {client_ip}")
                return _too_many_requests("Too many requests. Please try again shortly.")

        # Other API endpoints: 100 per minute per IP
        elif path.startswith("/api/v1/"):
            auth_header = request.headers.get("Authorization", "")
            if auth_header.startswith("Bearer "):
                key = f"ratelimit:api:auth:{client_ip}"
                limit = settings.RATE_LIMIT_API_PER_MINUTE
            else:
                key = f"ratelimit:api:anon:{client_ip}"
                limit = settings.RATE_LIMIT_LOGIN_PER_MINUTE

            if not _check_rate_limit(key, limit, 60):
                logger.warning(f"Rate limit exceeded for API: {client_ip}")
                return _too_many_requests("Rate limit exceeded. Please slow down.")

        return await call_next(request)
