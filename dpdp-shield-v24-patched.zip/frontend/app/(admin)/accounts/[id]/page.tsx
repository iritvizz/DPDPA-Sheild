"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { useParams } from "next/navigation";
import { apiFetch, setTokens, clearTokens } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

interface AccountDetail {
  public_id: string;
  business_name: string;
  business_slug: string;
  sector: string;
  status: string;
  trial_ends_at: string | null;
  created_at: string;
  user_count: number;
  data_source_count: number;
  consent_record_count: number;
}

export default function AdminAccountDetailPage() {
  const t = useTranslations();
  const params = useParams();
  const id = params.id as string;
  const [account, setAccount] = useState<AccountDetail | null>(null);
  const [error, setError] = useState("");
  const [impersonating, setImpersonating] = useState(false);

  useEffect(() => {
    if (id) loadAccount();
  }, [id]);

  async function loadAccount() {
    try {
      const data = await apiFetch(`/api/v1/admin/accounts/${id}`);
      setAccount(data);
    } catch (err: any) {
      if (err.status === 403) {
        window.location.href = "/dashboard";
      } else {
        setError(err.message || "Failed to load account");
      }
    }
  }

  async function impersonate() {
    try {
      const data = await apiFetch(`/api/v1/admin/accounts/${id}/impersonate`, { method: "POST" });
      clearTokens();
      setTokens(data.access_token, "");
      setImpersonating(true);
      window.location.href = "/dashboard";
    } catch (err: any) {
      setError(err.message || "Failed to impersonate");
    }
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!account) {
    return <p className="text-gray-500">Loading account...</p>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{account.business_name}</h2>
        <Button onClick={impersonate} disabled={impersonating}>
          {impersonating ? t("admin.impersonating") : t("admin.impersonate")}
        </Button>
      </div>

      {impersonating && (
        <Alert className="bg-yellow-50 border-yellow-200">
          <AlertDescription className="text-yellow-800">
            {t("admin.impersonationWarning")}
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>{t("admin.accountDetails")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div><span className="text-gray-500">Slug:</span> {account.business_slug}</div>
            <div><span className="text-gray-500">Sector:</span> {account.sector}</div>
            <div><span className="text-gray-500">Status:</span> <Badge>{account.status}</Badge></div>
            <div><span className="text-gray-500">Users:</span> {account.user_count}</div>
            <div><span className="text-gray-500">Data Sources:</span> {account.data_source_count}</div>
            <div><span className="text-gray-500">Consent Records:</span> {account.consent_record_count}</div>
            <div><span className="text-gray-500">Created:</span> {new Date(account.created_at).toLocaleString()}</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
