"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";

export default function InventoryPage() {
  const t = useTranslations();
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      setFiles(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{t("inventory.title")}</h2>
        <Button>{t("inventory.addSource")}</Button>
      </div>

      <Alert>{t("inventory.dragDrop")}</Alert>

      <Card>
        <CardHeader>
          <CardTitle>{t("inventory.title")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
              isDragging ? "border-blue-500 bg-blue-50" : "border-gray-300"
            }`}
          >
            <Input
              type="file"
              accept=".csv,.xlsx,.xls"
              multiple
              className="hidden"
              id="file-upload"
              onChange={handleFileChange}
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <p className="text-gray-500">{t("inventory.dragDrop")}</p>
              <p className="text-sm text-gray-400 mt-2">{t("inventory.fileTypes")}</p>
            </label>
          </div>

          {files.length > 0 && (
            <div className="mt-4 space-y-2">
              <h4 className="font-medium">Selected files:</h4>
              {files.map((file) => (
                <div key={file.name} className="flex items-center gap-2 text-sm">
                  <span className="text-green-600">✓</span>
                  <span>{file.name}</span>
                  <span className="text-gray-400">({(file.size / 1024).toFixed(1)} KB)</span>
                </div>
              ))}
              <Button className="mt-2">{t("inventory.uploadAndParse")}</Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
