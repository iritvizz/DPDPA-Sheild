"use client";

import { Button } from "@/components/ui/button";
import { clearTokens } from "@/lib/api";
import { useTranslations } from "next-intl";

export default function LogoutButton() {
  const t = useTranslations();

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={() => {
        clearTokens();
        window.location.href = "/login";
      }}
    >
      {t("auth.logout")}
    </Button>
  );
}
