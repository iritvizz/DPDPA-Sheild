"""Test Gujarati Unicode rendering in generated PDFs.

This test is a release checklist item per Section 9.4 of the spec:
"PDF generation must correctly render Gujarati Unicode. Test with real
Gujarati text in Week 1 — do not assume it works."

Run manually before go-live:
    cd backend
    pytest tests/test_gujarati_pdf_rendering.py -v -s

If this test fails (boxes instead of glyphs), the fallback is:
1. Install system Gujarati fonts: apt-get install fonts-noto
2. Or switch PDF library to WeasyPrint with Pango/Cairo backend
3. Or use headless Chrome for PDF generation
""""
import os
import tempfile

import pytest
from fastapi import status
from httpx import AsyncClient

from app.models import Account, PrivacyNotice, User, UserRole
from app.utils.auth import create_access_token


GUJARATI_SAMPLE = (
    "અમે તમારા ડેટાનું સન્માન કરીએ છીએ. "
    "આ ગોપનીયતા સૂચના અમારી ડેટા પ્રેક્ટિસિસ વિશે જણાવે છે."
)


@pytest.mark.asyncio
async def test_gujarati_privacy_notice_pdf_renders(async_client: AsyncClient, db_session):
    """Generate a privacy notice with Gujarati text and verify PDF creation."""
    account = Account(
        business_name="Gujarati Test",
        business_slug="gujarati-test",
        sector="E-commerce",
        widget_nonce_secret=os.urandom(32).hex(),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="guj@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    notice = PrivacyNotice(
        account_id=account.id,
        template_type="generic",
        content={
            "title": GUJARATI_SAMPLE,
            "sections": [
                {"heading": "પરિચય", "body": GUJARATI_SAMPLE},
            ],
        },
        version=1,
        is_published=True,
    )
    db_session.add(notice)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    # Trigger PDF generation
    response = await async_client.get(
        f"/api/v1/privacy-notice/{notice.public_id}/download",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == status.HTTP_200_OK
    assert response.headers["content-type"] == "application/pdf"

    pdf_bytes = response.content
    assert len(pdf_bytes) > 1000, "PDF appears too small — likely empty or failed"

    # Save for manual inspection
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False, mode="wb") as f:
        f.write(pdf_bytes)
        print(f"\n📄 Gujarati PDF saved for manual inspection: {f.name}")
        print("   Open this file and verify Gujarati glyphs render correctly.")
        print("   If you see boxes (□) instead of text, the font is missing.")

    # Heuristic: PDF should contain the Gujarati text (or its UTF-16BE encoding)
    # This is a weak check — visual inspection is the real gate.
    pdf_text = pdf_bytes.decode("latin-1", errors="ignore")
    assert "Gujarati" in pdf_text or len(pdf_bytes) > 5000, (
        "PDF may not contain Gujarati text — check font embedding"
    )


@pytest.mark.manual
@pytest.mark.skip(reason="Run manually before go-live — requires visual inspection")
def test_gujarati_glyph_visual_inspection():
    """Placeholder for the manual visual check.

    Steps:
    1. Run test_gujarati_privacy_notice_pdf_renders above
    2. Open the saved PDF in a PDF viewer (Adobe Reader, browser, etc.)
    3. Verify every Gujarati character renders as a glyph, not a box (□)
    4. If boxes appear: install fonts-noto, regenerate, re-check
    5. Sign off on the smoke test checklist (Section 4.3)
    """
    pass
