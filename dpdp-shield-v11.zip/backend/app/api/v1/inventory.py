"""Data inventory routes."""
from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile, status
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import DataElement, DataSource, DataSourceStatus, User
from app.schemas import (
    ConfirmElementsRequest,
    DataElementCreateRequest,
    DataElementResponse,
    DataSourceCreateRequest,
    DataSourceResponse,
    ParseFileResponse,
)
from app.services.file_processing import process_inventory_file
from app.utils.auth import get_current_active_user, require_admin
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/inventory", tags=["inventory"])


@router.post("/sources", response_model=DataSourceResponse, status_code=status.HTTP_201_CREATED)
async def create_source(
    request: Request,
    data: DataSourceCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Create a new data source (manual entry)."""
    source = DataSource(
        account_id=current_user.account_id,
        name=data.name,
        source_type=data.source_type,
    )
    db.add(source)
    await db.commit()
    await db.refresh(source)

    logger.info(f"Data source created: {source.id} for account {current_user.account_id}")
    return source


@router.post("/sources/parse-headers", response_model=ParseFileResponse)
async def parse_file_headers(
    request: Request,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Upload and parse file - in-memory only, never persists file content."""
    # Create source record first
    source = DataSource(
        account_id=current_user.account_id,
        name=file.filename or "Uploaded File",
        source_type="upload",
    )
    db.add(source)
    await db.flush()

    try:
        suggestions, row_count, col_count, purge_log = await process_inventory_file(file)

        # Update source with metadata
        source.row_count = row_count
        source.column_count = col_count
        await db.commit()

        # Log the purge verification
        logger.info(
            "File purge verified",
            extra={
                "account_id": current_user.account_id,
                "source_id": source.id,
                "purge_log": purge_log,
            },
        )

        return ParseFileResponse(
            data_source_id=source.id,
            suggestions=suggestions,
            row_count=row_count,
            column_count=col_count,
        )

    except ValueError as e:
        # Clean up source on error
        await db.delete(source)
        await db.commit()
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/sources/{source_id}/elements", response_model=list[DataElementResponse])
async def confirm_elements(
    source_id: int,
    data: ConfirmElementsRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Confirm and save data elements - replaces any existing draft elements."""
    # Verify source belongs to account
    result = await db.execute(
        select(DataSource).where(
            DataSource.id == source_id,
            DataSource.account_id == current_user.account_id,
        )
    )
    source = result.scalar_one_or_none()
    if not source:
        raise HTTPException(status_code=404, detail="Data source not found")

    # Delete existing elements
    await db.execute(
        delete(DataElement).where(DataElement.data_source_id == source_id)
    )

    # Create new elements
    elements = []
    for elem_data in data.elements:
        element = DataElement(
            data_source_id=source_id,
            field_name=elem_data.field_name,
            data_category=elem_data.data_category,
            purposes=elem_data.purposes,
            legal_basis=elem_data.legal_basis,
            retention_period_value=elem_data.retention_period_value,
            retention_period_unit=elem_data.retention_period_unit,
            third_party_sharing=elem_data.third_party_sharing,
            third_party_details=elem_data.third_party_details,
        )
        db.add(element)
        elements.append(element)

    # Update source status
    source.status = DataSourceStatus.CONFIRMED
    await db.commit()

    # Refresh all elements
    for elem in elements:
        await db.refresh(elem)

    return elements


@router.get("/sources", response_model=list[DataSourceResponse])
async def list_sources(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List all data sources for the account."""
    result = await db.execute(
        select(DataSource).where(DataSource.account_id == current_user.account_id)
    )
    return result.scalars().all()


@router.get("/sources/{source_id}", response_model=DataSourceResponse)
async def get_source(
    source_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get a specific data source."""
    result = await db.execute(
        select(DataSource).where(
            DataSource.id == source_id,
            DataSource.account_id == current_user.account_id,
        )
    )
    source = result.scalar_one_or_none()
    if not source:
        raise HTTPException(status_code=404, detail="Data source not found")
    return source


@router.delete("/sources/{source_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_source(
    source_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Delete a data source and all its elements."""
    result = await db.execute(
        select(DataSource).where(
            DataSource.id == source_id,
            DataSource.account_id == current_user.account_id,
        )
    )
    source = result.scalar_one_or_none()
    if not source:
        raise HTTPException(status_code=404, detail="Data source not found")

    await db.delete(source)
    await db.commit()

    return None
