"use client";

import { useTranslations } from "next-intl";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export default function ConsentPage() {
  const t = useTranslations();

  // TODO: fetch real consent records from GET /api/v1/consent/records
  const records = [
    {
      id: "1",
      customer_reference: "cust-001",
      purpose: "marketing",
      method: "website_checkbox",
      is_revoked: false,
      created_at: "2026-08-01",
    },
    {
      id: "2",
      customer_reference: "cust-002",
      purpose: "analytics",
      method: "email_link",
      is_revoked: true,
      created_at: "2026-07-15",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{t("consent.title")}</h2>
        <Button>{t("consent.logConsent")}</Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t("consent.title")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-4">
            <Input placeholder={t("consent.searchPlaceholder")} className="max-w-sm" />
            <Button variant="outline">{t("consent.exportCSV")}</Button>
          </div>

          <div className="space-y-2">
            {records.map((r) => (
              <div
                key={r.id}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
              >
                <div>
                  <p className="font-medium">{r.customer_reference}</p>
                  <p className="text-sm text-gray-500">
                    {r.purpose} • {r.method} • {r.created_at}
                  </p>
                </div>
                <Badge variant={r.is_revoked ? "destructive" : "default"}>
                  {r.is_revoked ? t("consent.revoked") : t("consent.active")}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
