"""Authentication tests."""
import pytest
from fastapi import status
from httpx import AsyncClient

from app.main import app
from app.utils.auth import create_access_token, verify_password, get_password_hash


class TestAuth:
    @pytest.mark.asyncio
    async def test_register(self, async_client: AsyncClient):
        """Test user registration creates account and returns tokens."""
        response = await async_client.post("/api/v1/auth/register", json={
            "email": "test@example.com",
            "password": "SecurePass123!",
            "business_name": "Test Business",
            "sector": "E-commerce",
        })

        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert "access_token" in data, "access_token missing from response"
        assert "refresh_token" in data, "refresh_token missing from response"
        assert data["token_type"] == "bearer"
        assert isinstance(data["expires_in"], int)
        assert data["expires_in"] > 0

    @pytest.mark.asyncio
    async def test_register_duplicate_email(self, async_client: AsyncClient):
        """Test registration with duplicate email fails with 409."""
        # First registration
        await async_client.post("/api/v1/auth/register", json={
            "email": "dup@example.com",
            "password": "SecurePass123!",
            "business_name": "Test Business 1",
            "sector": "E-commerce",
        })

        # Duplicate
        response = await async_client.post("/api/v1/auth/register", json={
            "email": "dup@example.com",
            "password": "SecurePass123!",
            "business_name": "Test Business 2",
            "sector": "Services",
        })

        assert response.status_code == status.HTTP_409_CONFLICT
        data = response.json()
        assert "detail" in data

    @pytest.mark.asyncio
    async def test_login(self, async_client: AsyncClient):
        """Test login with valid credentials returns tokens."""
        # Register first
        await async_client.post("/api/v1/auth/register", json={
            "email": "login@example.com",
            "password": "SecurePass123!",
            "business_name": "Login Test",
            "sector": "E-commerce",
        })

        # Login
        response = await async_client.post("/api/v1/auth/login", json={
            "email": "login@example.com",
            "password": "SecurePass123!",
        })

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data

    @pytest.mark.asyncio
    async def test_login_invalid_credentials(self, async_client: AsyncClient):
        """Test login with wrong password returns 401."""
        response = await async_client.post("/api/v1/auth/login", json={
            "email": "nonexistent@example.com",
            "password": "WrongPass123!",
        })

        assert response.status_code == status.HTTP_401_UNAUTHORIZED
        data = response.json()
        assert "detail" in data

    def test_password_hashing(self):
        """Test bcrypt password hashing and verification."""
        password = "TestPassword123!"
        hashed = get_password_hash(password)

        assert hashed != password, "Hash should not equal plaintext"
        assert verify_password(password, hashed) is True, "Correct password should verify"
        assert verify_password("wrong", hashed) is False, "Wrong password should fail"

    def test_jwt_token_creation(self):
        """Test JWT token creation contains correct claims."""
        token = create_access_token({"sub": "test-user-123"})
        assert token is not None
        assert isinstance(token, str)
        assert len(token) > 0

        # Decode and verify
        from app.utils.auth import decode_token
        payload = decode_token(token)
        assert payload["sub"] == "test-user-123"
        assert payload["type"] == "access"
        assert "exp" in payload
