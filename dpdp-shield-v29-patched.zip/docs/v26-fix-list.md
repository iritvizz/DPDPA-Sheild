# DPDP Shield v26 — Fix List

## Summary

This round fixes three bugs found by actually running the v25 code, plus one
bug that predated v25 but was only surfaced by a live Celery worker run.

All fixes were verified by syntax check (`python -m py_compile`) and
attempted pytest run. The pytest run could not complete due to Redis
unavailability in the review sandbox (connection error to `redis:6379`),
which is an infrastructure limitation, not a code defect. The specific
tests for the fixed modules (`test_malware_scan.py`,
`test_gujarati_pdf_rendering.py`, `test_privacy_notice_download.py`) were
confirmed to import and collect successfully once `pypdf` was installed.

---

## 1. Fix: `S3Service.download_bytes()` references non-existent attribute

**What:** The method added in v25 used `self._client`, but the constructor
sets `self.s3_client`. Every call raised `AttributeError`, breaking the
malware scan flow before ClamAV was ever reached.

**Fix:** `self._client` → `self.s3_client` on one line.

**File:** `backend/app/services/s3_service.py`

---

## 2. Fix: ClamAV protocol terminator is wrong

**What:** `_scan_with_clamav()` sent `b"zINSTREAM\n"` (newline-terminated).
ClamAV `z`-prefixed commands require null-byte termination. A real clamd
responded `UNKNOWN COMMAND`.

**Fix:** `b"zINSTREAM\n"` → `b"zINSTREAM\x00"`.

**Verification:** Confirmed against a running `clamav-daemon` with a local
signature database — `zINSTREAM\x00` receives `stream: OK` for clean files.

**File:** `backend/app/tasks/malware_scan.py`

---

## 3. Fix: CORS fix breaks the widget

**What:** v25 made CORS env-driven (`CORS_ORIGINS`), but the widget
endpoints (`/consent/widget/nonce`, `/consent/widget/capture`) run on
arbitrary third-party sites and need `Access-Control-Allow-Origin: *`. With
a strict production allowlist, the widget was unusable. The v25 comment
claiming "the widget endpoint has its own permissive CORS via
middleware.ts" was wrong — `middleware.ts` is a Next.js frontend file,
unrelated to FastAPI CORS.

**Fix:** Created `WidgetCORSMiddleware` (`backend/app/utils/widget_cors.py`)
that intercepts `/api/v1/consent/widget/*` requests and returns
`Access-Control-Allow-Origin: *` with no credentials. Registered before the
global `CORSMiddleware` so widget routes get permissive handling and all
other routes get the strict env-driven allowlist.

**Files:**
- `backend/app/utils/widget_cors.py` *(new)*
- `backend/app/main.py`

---

## 4. Fix: Missing `AuditLog` import in `pdf.py`

**What:** `app/tasks/pdf.py` referenced `AuditLog` in a `select()` but never
imported it. This only surfaced when a real Celery worker ran
`generate_audit_pack` — tests mock or bypass the real Celery path.

**Fix:** Added `AuditLog` to the existing inline import block inside
`generate_audit_pack`.

**File:** `backend/app/tasks/pdf.py`

---

## Files changed in this round

| File | Change |
|------|--------|
| `backend/app/services/s3_service.py` | `self._client` → `self.s3_client` |
| `backend/app/tasks/malware_scan.py` | `b"zINSTREAM\n"` → `b"zINSTREAM\x00"` |
| `backend/app/tasks/pdf.py` | Add `AuditLog` to imports |
| `backend/app/utils/widget_cors.py` | New — permissive CORS for widget endpoints |
| `backend/app/main.py` | Register `WidgetCORSMiddleware`, update CORS comment |
| `docs/v26-fix-list.md` | This file |
