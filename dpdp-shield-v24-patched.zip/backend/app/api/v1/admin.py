"""Admin panel routes -- superadmin only."""
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Account, AccountStatus, AuditLog, ConsentRecord, DataSource, DSARRequest, Subscription, SubscriptionStatus, User
from app.schemas import AdminAccountDetailResponse, AdminAccountListItem, AdminAnalyticsResponse, ImpersonationResponse, MessageResponse
from app.utils.auth import create_access_token, require_superadmin
from app.utils.enums import enum_value
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/accounts", response_model=list[AdminAccountListItem])
async def list_all_accounts(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """List all accounts with user counts (superadmin only)."""
    result = await db.execute(
        select(Account).order_by(Account.created_at.desc()).offset(skip).limit(limit)
    )
    accounts = result.scalars().all()

    items = []
    for account in accounts:
        user_count_result = await db.execute(
            select(func.count(User.id)).where(User.account_id == account.id)
        )
        user_count = user_count_result.scalar() or 0

        items.append(AdminAccountListItem(
            public_id=account.public_id,
            business_name=account.business_name,
            business_slug=account.business_slug,
            sector=account.sector,
            status=enum_value(account.status),
            trial_ends_at=account.trial_ends_at,
            created_at=account.created_at,
            user_count=user_count,
        ))

    return items


@router.post("/accounts/{account_id}/suspend", response_model=MessageResponse)
async def suspend_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """Suspend an account (superadmin only)."""
    result = await db.execute(select(Account).where(Account.public_id == account_id))
    account = result.scalar_one_or_none()

    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    account.status = AccountStatus.SUSPENDED
    await db.commit()

    logger.warning(f"Account suspended by superadmin: {account.public_id}")
    return MessageResponse(message=f"Account {account.business_name} suspended.")


@router.post("/accounts/{account_id}/activate", response_model=MessageResponse)
async def activate_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """Activate a suspended account (superadmin only)."""
    result = await db.execute(select(Account).where(Account.public_id == account_id))
    account = result.scalar_one_or_none()

    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    account.status = AccountStatus.ACTIVE
    await db.commit()

    logger.info(f"Account activated by superadmin: {account.public_id}")
    return MessageResponse(message=f"Account {account.business_name} activated.")




@router.get("/accounts/{account_id}", response_model=AdminAccountDetailResponse)
async def get_account_detail(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """Read-only full account detail view (drill-down from list)."""
    result = await db.execute(select(Account).where(Account.public_id == account_id))
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    # Count users
    user_count = (
        await db.execute(select(func.count(User.id)).where(User.account_id == account.id))
    ).scalar() or 0

    # Count data sources
    source_count = (
        await db.execute(select(func.count(DataSource.id)).where(DataSource.account_id == account.id))
    ).scalar() or 0

    # Count consent records
    consent_count = (
        await db.execute(select(func.count(ConsentRecord.id)).where(ConsentRecord.account_id == account.id))
    ).scalar() or 0

    return AdminAccountDetailResponse(
        public_id=account.public_id,
        business_name=account.business_name,
        business_slug=account.business_slug,
        sector=account.sector,
        status=enum_value(account.status),
        trial_ends_at=account.trial_ends_at,
        created_at=account.created_at,
        user_count=user_count,
        data_source_count=source_count,
        consent_record_count=consent_count,
    )


@router.post("/accounts/{account_id}/impersonate", response_model=ImpersonationResponse)
async def impersonate_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """Issue a scoped impersonation token for support debugging.

    The token is short-lived (15 minutes) and grants access to the
    target account as an admin.  The action is fully logged to AuditLog.
    """
    result = await db.execute(select(Account).where(Account.public_id == account_id))
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    # Find an admin user in the target account to impersonate
    result = await db.execute(
        select(User).where(
            User.account_id == account.id,
            User.role.in_(["admin", "superadmin"]),
        )
    )
    target_user = result.scalar_one_or_none()
    if not target_user:
        raise HTTPException(status_code=404, detail="No admin user found in target account")

    # Create short-lived scoped token
    token = create_access_token(
        {"sub": str(target_user.public_id), "impersonated_by": str(current_user.public_id)},
        expires_delta=timedelta(minutes=15),
    )

    # Log to AuditLog
    audit = AuditLog(
        account_id=account.id,
        user_id=current_user.id,
        event_type="admin_impersonation",
        event_details={
            "impersonated_by": str(current_user.public_id),
            "impersonated_user": str(target_user.public_id),
            "account_id": str(account.public_id),
        },
    )
    db.add(audit)
    await db.commit()

    logger.warning(
        f"SUPERADMIN IMPERSONATION: {current_user.public_id} -> {target_user.public_id} "
        f"(account {account.public_id})"
    )

    return ImpersonationResponse(
        access_token=token,
        expires_in=900,
        message=f"Impersonating {account.business_name} as {target_user.email}. Token expires in 15 minutes.",
    )


@router.get("/analytics", response_model=AdminAnalyticsResponse)
async def get_analytics(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """Platform-wide analytics (superadmin only)."""
    total_accounts = (await db.execute(select(func.count(Account.id)))).scalar() or 0
    total_users = (await db.execute(select(func.count(User.id)))).scalar() or 0
    total_consent = (await db.execute(select(func.count(ConsentRecord.id)))).scalar() or 0
    total_sources = (await db.execute(select(func.count(DataSource.id)))).scalar() or 0
    active_subs = (await db.execute(
        select(func.count(Subscription.id)).where(Subscription.status == SubscriptionStatus.ACTIVE)
    )).scalar() or 0
    trial_accs = (await db.execute(
        select(func.count(Account.id)).where(Account.status == AccountStatus.TRIAL)
    )).scalar() or 0
    pending_dsars = (await db.execute(
        select(func.count(DSARRequest.id)).where(DSARRequest.status == "pending")
    )).scalar() or 0

    return AdminAnalyticsResponse(
        total_accounts=total_accounts,
        total_users=total_users,
        total_consent_records=total_consent,
        total_data_sources=total_sources,
        active_subscriptions=active_subs,
        trial_accounts=trial_accs,
        dsar_requests_pending=pending_dsars,
    )
