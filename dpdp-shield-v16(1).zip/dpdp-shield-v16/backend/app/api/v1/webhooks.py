"""Webhook handlers."""
import json
import uuid
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.models import Account, AccountStatus, Subscription, SubscriptionStatus
from app.services.payment_service import verify_razorpay_signature
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/webhooks", tags=["webhooks"])


@router.post("/razorpay")
async def razorpay_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Handle Razorpay webhook events."""
    settings = get_settings()

    # Get raw body for signature verification
    body = await request.body()
    body_str = body.decode()

    # Verify signature
    signature = request.headers.get("X-Razorpay-Signature", "")
    if not settings.RAZORPAY_WEBHOOK_SECRET:
        logger.warning("Razorpay webhook secret not configured, skipping verification")
    elif not verify_razorpay_signature(body_str, signature, settings.RAZORPAY_WEBHOOK_SECRET):
        logger.error("Razorpay webhook signature verification failed")
        raise HTTPException(status_code=400, detail="Invalid signature")

    # Parse payload
    try:
        payload = json.loads(body_str)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    event = payload.get("event")
    data = payload.get("payload", {}).get("subscription", {}).get("entity", {})

    razorpay_sub_id = data.get("id")
    razorpay_customer_id = data.get("customer_id")

    logger.info(f"Razorpay webhook received: {event}, sub_id={razorpay_sub_id}")

    # GUARD: reject payloads with no subscription id. Without this, the
    # query below (Subscription.razorpay_subscription_id == razorpay_sub_id)
    # becomes "... IS NULL" when razorpay_sub_id is None -- SQLAlchemy
    # correctly translates a Python None comparison to IS NULL rather than
    # the always-false "= NULL" -- which means it WOULD genuinely match any
    # pending/trial subscription that was created (per create_checkout
    # above) but never yet linked to a real Razorpay subscription. A
    # malformed or unverified webhook could then activate or cancel an
    # unrelated account's trial subscription. Confirmed real by reading the
    # actual query logic, not assumed.
    if not razorpay_sub_id:
        logger.error("Razorpay webhook missing subscription id -- rejecting")
        raise HTTPException(status_code=400, detail="Missing subscription id")

    result = await db.execute(
        select(Subscription).where(Subscription.razorpay_subscription_id == razorpay_sub_id)
    )
    sub = result.scalar_one_or_none()

    if event == "subscription.activated":
        if sub:
            sub.status = SubscriptionStatus.ACTIVE
            sub.current_period_start = datetime.now(timezone.utc)
            sub.current_period_end = datetime.now(timezone.utc) + timedelta(days=30)

            result = await db.execute(select(Account).where(Account.id == sub.account_id))
            account = result.scalar_one()
            account.status = AccountStatus.ACTIVE

            await db.commit()
            logger.info(f"Subscription activated: {razorpay_sub_id}")
        else:
            # Attempt to link via Razorpay's `notes` field, which Razorpay
            # echoes back on every webhook. This requires the frontend to
            # actually pass notes={"account_id": <account's public_id UUID
            # as a string>} when creating the Razorpay subscription/order --
            # deliberately using the account's public_id (not the internal
            # integer id) so a malformed or spoofed notes value can't be
            # used to guess at or enumerate other accounts. This still
            # needs a real Razorpay sandbox to confirm the exact notes-echo
            # payload shape before trusting it in production.
            notes = data.get("notes", {})
            account_public_id_from_notes = notes.get("account_id")
            linked = False
            if account_public_id_from_notes:
                try:
                    account_uuid = uuid.UUID(account_public_id_from_notes)
                    result = await db.execute(select(Account).where(Account.public_id == account_uuid))
                    account = result.scalar_one_or_none()
                    if account:
                        sub = Subscription(
                            account_id=account.id,
                            razorpay_subscription_id=razorpay_sub_id,
                            razorpay_customer_id=razorpay_customer_id,
                            plan_id="dpdp-shield-pro",
                            status=SubscriptionStatus.ACTIVE,
                            current_period_start=datetime.now(timezone.utc),
                            current_period_end=datetime.now(timezone.utc) + timedelta(days=30),
                        )
                        db.add(sub)
                        account.status = AccountStatus.ACTIVE
                        await db.commit()
                        logger.info(f"Subscription activated via notes linking: {razorpay_sub_id}")
                        linked = True
                except (ValueError, TypeError):
                    pass

            if not linked:
                logger.error(
                    f"Received activation for unknown subscription {razorpay_sub_id} "
                    f"(customer_id={razorpay_customer_id}) -- no matching pending record and "
                    f"no usable account_id in notes. This needs real Razorpay sandbox testing "
                    f"to confirm the notes echo shape; see comment above."
                )
                raise HTTPException(status_code=404, detail="No matching pending subscription found")

    elif event == "subscription.charged":
        if sub:
            sub.status = SubscriptionStatus.ACTIVE
            sub.current_period_start = datetime.now(timezone.utc)
            sub.current_period_end = datetime.now(timezone.utc) + timedelta(days=30)
            await db.commit()
            logger.info(f"Subscription charged: {razorpay_sub_id}")
        else:
            logger.warning(f"Charged event for unknown subscription: {razorpay_sub_id}")

    elif event in ("subscription.cancelled", "subscription.halted"):
        if sub:
            sub.status = SubscriptionStatus.CANCELLED
            await db.commit()

            result = await db.execute(select(Account).where(Account.id == sub.account_id))
            account = result.scalar_one()
            if sub.current_period_end and sub.current_period_end < datetime.now(timezone.utc):
                account.status = AccountStatus.EXPIRED
                await db.commit()

            logger.info(f"Subscription cancelled: {razorpay_sub_id}")
        else:
            logger.warning(f"Cancel event for unknown subscription: {razorpay_sub_id}")

    elif event == "subscription.paused":
        if sub:
            sub.status = SubscriptionStatus.PAST_DUE
            await db.commit()
            logger.info(f"Subscription paused: {razorpay_sub_id}")

    return {"status": "processed"}
