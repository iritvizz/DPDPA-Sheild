import { getTranslations } from "next-intl/server";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function Page() {
  const t = await getTranslations();
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t("reports.title")}</h2>
      <Card>
        <CardHeader><CardTitle>{t("reports.title")}</CardTitle></CardHeader>
        <CardContent>
          <p className="text-gray-500">{t("reports.title")} page coming soon.</p>
        </CardContent>
      </Card>
    </div>
  );
}
