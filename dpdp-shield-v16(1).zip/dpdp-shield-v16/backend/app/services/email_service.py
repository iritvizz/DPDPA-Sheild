"""Email service using AWS SES."""
from typing import Optional

from app.config import get_settings
from app.utils.logging import get_logger

logger = get_logger(__name__)


class EmailService:
    """Email service with AWS SES backend."""

    def __init__(self):
        self.settings = get_settings()
        self._client = None

    def _get_client(self):
        """Lazy-load boto3 SES client."""
        if self._client is None:
            import boto3
            self._client = boto3.client(
                "ses",
                region_name=self.settings.AWS_REGION,
                aws_access_key_id=self.settings.AWS_ACCESS_KEY_ID,
                aws_secret_access_key=self.settings.AWS_SECRET_ACCESS_KEY,
            )
        return self._client

    async def send_email(
        self,
        to_email: str,
        subject: str,
        body_text: str,
        body_html: Optional[str] = None,
    ) -> bool:
        """Send an email via AWS SES.

        In development, logs instead of sending.
        """
        if self.settings.ENVIRONMENT == "development":
            logger.info(f"[DEV EMAIL] To: {to_email}, Subject: {subject}")
            return True

        try:
            client = self._get_client()
            response = client.send_email(
                Source=self.settings.SES_FROM_EMAIL,
                Destination={"ToAddresses": [to_email]},
                Message={
                    "Subject": {"Data": subject},
                    "Body": {
                        "Text": {"Data": body_text},
                        **({"Html": {"Data": body_html}} if body_html else {}),
                    },
                },
            )
            logger.info(f"Email sent to {to_email}: {response['MessageId']}")
            return True
        except Exception as e:
            logger.error(f"Failed to send email to {to_email}: {e}")
            return False

    async def send_invitation_email(self, to_email: str, invite_token: str) -> bool:
        """Send staff invitation email."""
        settings = get_settings()
        invite_url = f"{settings.FRONTEND_URL}/accept-invite?token={invite_token}"

        return await self.send_email(
            to_email=to_email,
            subject="You\'ve been invited to DPDP Shield",
            body_text=f"""You have been invited to join a DPDP Shield account.

Click the link below to accept your invitation:
{invite_url}

This link will expire in 48 hours.
""",
            body_html=f"""
<html>
<body>
    <h2>You\'ve been invited to DPDP Shield</h2>
    <p>You have been invited to join a DPDP Shield account.</p>
    <p><a href="{invite_url}" style="padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px;">Accept Invitation</a></p>
    <p>This link will expire in 48 hours.</p>
</body>
</html>
""",
        )

    async def send_trial_expiry_reminder(self, to_email: str, days_remaining: int) -> bool:
        """Send trial expiry reminder."""
        return await self.send_email(
            to_email=to_email,
            subject=f"Your DPDP Shield trial expires in {days_remaining} days",
            body_text=f"""Your DPDP Shield free trial will expire in {days_remaining} days.

Subscribe now to continue using all features.
""",
        )
