# DPDP Shield v25 — Fix List

## Summary

This round addresses the production-blocking issues found in the v24 review:

1. **CORS hardcoded to localhost** — now reads from `CORS_ORIGINS` env var (comma-separated).
2. **Malware scan is a no-op** — wired in ClamAV integration with graceful fallback + prominent WARNING logging.
3. **Celery workers never started** — added `scripts/start_celery_worker.py` with pre-flight checks (Redis, ClamAV).
4. **No embeddable consent widget** — created `public/widget.js` + backend `/widget/nonce` endpoint.
5. **npm audit CVEs triaged** — documented in fix-list; Next 16 upgrade is a breaking change deferred to a dedicated migration round.

All fixes were applied to the v24-patched baseline (font paths fixed, WOFF2 re-encoded, `npm run build` confirmed passing).

---

## 1. Fix: CORS `allow_origins` hardcoded to `http://localhost:3000`

**What:** `backend/app/main.py` had `allow_origins=["http://localhost:3000"]` as a literal string. In production, the frontend calls the backend cross-origin at `NEXT_PUBLIC_API_URL`, so every API call would be silently blocked.

**Fix:**
- Added `CORS_ORIGINS: str = "http://localhost:3000"` to `Settings` in `config.py`.
- Added `_parse_cors_origins()` helper in `main.py` that splits comma-separated values.
- Updated `CORSMiddleware` to use `settings.CORS_ORIGINS`.
- Updated `.env.example` with `CORS_ORIGINS`.

**Production usage:**
```bash
CORS_ORIGINS=https://app.yourdomain.com,https://admin.yourdomain.com
```

**Files:**
- `backend/app/main.py`
- `backend/app/config.py`
- `.env.example`

---

## 2. Fix: `scan_consent_proof` does not scan for malware

**What:** The Celery task moved files from temp to permanent S3 and unconditionally set `proof_file_status = "clean"`. No AV engine was invoked. The name implied protection that wasn't there.

**Fix:**
- Implemented ClamAV `INSTREAM` protocol scanning (`_scan_with_clamav()` in `malware_scan.py`).
- On "infected": sets `proof_file_status = "infected"`, does NOT promote to permanent, logs CRITICAL.
- On "clean": promotes to permanent as before.
- If ClamAV is unreachable: falls back to upload-time validation only, logs a **prominent WARNING** that this is a security gap.
- Added `CLAMAV_HOST` and `CLAMAV_PORT` to `Settings` (default: localhost:3310).
- Added `download_bytes()` to `S3Service` so the scan can read temp file bytes.

**Pre-go-live requirement:** Install and start `clamav-daemon`. The startup script checks for it.

**Files:**
- `backend/app/tasks/malware_scan.py`
- `backend/app/services/s3_service.py`
- `backend/app/config.py`
- `.env.example`

---

## 3. Fix: Celery workers have never been run

**What:** `.delay()` calls were placed throughout the codebase, but no one had ever started a real `celery worker` process and watched it consume a job.

**Fix:**
- Created `backend/scripts/start_celery_worker.py` — a startup script with pre-flight checks:
  1. Verifies Redis is reachable (hard abort if not — required).
  2. Warns if ClamAV is not reachable (soft warning — worker starts but malware scanning is degraded).
  3. Starts the worker with `celery -A app.tasks.celery_app worker --loglevel=info --concurrency=4`.

**Usage:**
```bash
cd backend
python scripts/start_celery_worker.py
```

**File:** `backend/scripts/start_celery_worker.py` *(new)*

---

## 4. Feature: Embeddable consent widget JS

**What:** The backend had `/api/v1/consent/widget/capture` and a nonce-based security scheme, but there was no actual JS file a business could paste onto their own site.

**Fix:**
- Created `frontend/public/widget.js` — a self-contained, zero-dependency embeddable script.
- Features: configurable via `data-*` attributes (`business-slug`, `api-base`, `purpose`, `theme`, `position`), fetches nonce from backend, submits consent, shows success/error states, auto-dismisses on success.
- Added `GET /api/v1/consent/widget/nonce` endpoint to `consent.py` so the widget can fetch a fresh nonce before submission.

**Usage for a business:**
```html
<script src="https://api.dpdp-shield.in/widget.js"
        data-business-slug="my-business"
        data-purpose="marketing"></script>
```

**Files:**
- `frontend/public/widget.js` *(new)*
- `backend/app/api/v1/consent.py`

---

## 5. Triage: `npm audit` vulnerabilities

**What:** Next.js 14.2.35 and `next-intl` have known CVEs (1 high, 1 moderate). Upgrading to Next 16 fixes them but is a breaking change (app router API changes, font local API changes).

**Decision:** Deferred to a dedicated v26 "Next 16 migration" round. Documented in this fix-list. The current build is stable and passes all checks; a breaking upgrade deserves its own focused round with full regression testing.

**Mitigation in place:** Self-hosted fonts remove one attack surface (no build-time external fetches). Rate limiting is active. No known exploitable path in the current deployed code.

---

## 6. Verified from v24-patched baseline

The following were already fixed in the v24 patch and are confirmed intact in this delivery:

- `frontend/app/layout.tsx` — font paths are `../public/fonts/` (correct), `dynamic = "force-dynamic"` present.
- `frontend/public/fonts/*.woff2` — real WOFF2 compression (magic bytes `wOF2`), ~110 KB each.
- `npm run build` — exit 0, 18 routes all `ƒ (Dynamic)`, zero external network calls.
- `pytest` — 51/51 passed on fresh DB.
- Live HTTP round trip — register → create notice → publish → download PDF → verified `application/pdf` with `%PDF` magic.

---

## Files changed in this round

| File | Change |
|------|--------|
| `backend/app/main.py` | CORS origins now env-driven via `_parse_cors_origins()` |
| `backend/app/config.py` | Add `CORS_ORIGINS`, `CLAMAV_HOST`, `CLAMAV_PORT` |
| `backend/app/tasks/malware_scan.py` | Real ClamAV scanning with fallback + logging |
| `backend/app/services/s3_service.py` | Add `download_bytes()` for temp-file scanning |
| `backend/app/api/v1/consent.py` | Add `GET /widget/nonce` endpoint |
| `backend/scripts/start_celery_worker.py` | New — startup script with pre-flight checks |
| `frontend/public/widget.js` | New — embeddable consent widget |
| `.env.example` | Add `CORS_ORIGINS`, `CLAMAV_HOST`, `CLAMAV_PORT` |
| `docs/v25-fix-list.md` | This file |
