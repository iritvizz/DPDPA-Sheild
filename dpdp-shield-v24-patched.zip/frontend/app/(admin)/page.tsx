"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Analytics {
  total_accounts: number;
  total_users: number;
  total_consent_records: number;
  total_data_sources: number;
  active_subscriptions: number;
  trial_accounts: number;
  dsar_requests_pending: number;
}

export default function AdminDashboardPage() {
  const t = useTranslations();
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    apiFetch("/api/v1/admin/analytics")
      .then((data) => setAnalytics(data))
      .catch((err) => {
        if (err.status === 403) {
          window.location.href = "/dashboard";
        } else {
          setError(err.message || "Failed to load analytics");
        }
      });
  }, []);

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!analytics) {
    return <p className="text-gray-500">Loading analytics...</p>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t("admin.analytics")}</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{analytics.total_accounts}</p><p className="text-sm text-gray-500">{t("admin.totalAccounts")}</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{analytics.total_users}</p><p className="text-sm text-gray-500">{t("admin.totalUsers")}</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{analytics.active_subscriptions}</p><p className="text-sm text-gray-500">{t("admin.activeSubscriptions")}</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{analytics.trial_accounts}</p><p className="text-sm text-gray-500">{t("admin.trialAccounts")}</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{analytics.total_consent_records}</p><p className="text-sm text-gray-500">{t("admin.totalConsentRecords")}</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{analytics.total_data_sources}</p><p className="text-sm text-gray-500">{t("admin.totalDataSources")}</p></CardContent></Card>
        <Card><CardContent className="p-4 text-center"><p className="text-2xl font-bold">{analytics.dsar_requests_pending}</p><p className="text-sm text-gray-500">{t("admin.pendingDSARs")}</p></CardContent></Card>
      </div>
    </div>
  );
}
