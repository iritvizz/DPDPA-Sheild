"""DSAR template tests -- verify per-language responses and route ordering."""
import secrets

import pytest
from fastapi import status
from httpx import AsyncClient

from app.models import Account, DSARTemplate, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_dsar_templates_return_per_language(async_client: AsyncClient, db_session):
    """Templates endpoint returns correctly translated templates per language."""
    account = Account(
        business_name="Template Test",
        business_slug="template-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="tmpl@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    # Seed templates for multiple languages
    for lang in ["en", "hi", "gu"]:
        for req_type in ["access", "correction", "deletion"]:
            db_session.add(DSARTemplate(
                request_type=req_type,
                language=lang,
                subject_template=f"Subject {lang}",
                body_template=f"Body {lang}",
            ))
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    for lang in ["en", "hi", "gu"]:
        response = await async_client.get(
            f"/api/v1/dsar/templates?language={lang}",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 200
        templates = response.json()
        assert len(templates) == 3
        for t in templates:
            assert t["language"] == lang
            assert f"Subject {lang}" in t["subject_template"]


@pytest.mark.asyncio
async def test_dsar_templates_route_ordering(async_client: AsyncClient, db_session):
    """GET /templates must not be shadowed by /{dsar_id} route."""
    account = Account(
        business_name="Route Test",
        business_slug="route-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="route@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    # This must hit /templates, not be interpreted as a dsar_id
    response = await async_client.get(
        "/api/v1/dsar/templates",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    assert isinstance(response.json(), list)
