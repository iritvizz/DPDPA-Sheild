"""Privacy Notice Builder routes."""
import io
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import StreamingResponse
from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Account, DataElement, DataSource, PrivacyNotice, User
from app.schemas import (
    PrivacyNoticeCreateRequest,
    PrivacyNoticeResponse,
    PublicNoticeResponse,
    MessageResponse,
)
from app.utils.auth import get_current_active_user, require_admin, get_account_from_slug
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/privacy-notice", tags=["privacy-notice"])

# Predefined templates
TEMPLATES = {
    "ecommerce": {
        "name": "E-commerce / D2C",
        "sections": [
            {"title": "Introduction", "content": "", "order": 1},
            {"title": "Data We Collect", "content": "", "order": 2},
            {"title": "Purposes of Processing", "content": "", "order": 3},
            {"title": "Legal Basis", "content": "", "order": 4},
            {"title": "Third-Party Sharing", "content": "", "order": 5},
            {"title": "Data Retention", "content": "", "order": 6},
            {"title": "Your Rights Under DPDPA", "content": "", "order": 7},
            {"title": "Grievance Contact", "content": "", "order": 8},
            {"title": "Updates to This Notice", "content": "", "order": 9},
        ]
    },
    "service": {
        "name": "Service Business",
        "sections": [
            {"title": "Introduction", "content": "", "order": 1},
            {"title": "Client Data We Collect", "content": "", "order": 2},
            {"title": "Purposes of Processing", "content": "", "order": 3},
            {"title": "Communications", "content": "", "order": 4},
            {"title": "Billing & Payments", "content": "", "order": 5},
            {"title": "Data Retention", "content": "", "order": 6},
            {"title": "Your Rights Under DPDPA", "content": "", "order": 7},
            {"title": "Grievance Contact", "content": "", "order": 8},
            {"title": "Updates to This Notice", "content": "", "order": 9},
        ]
    },
    "generic": {
        "name": "Generic",
        "sections": [
            {"title": "Introduction", "content": "", "order": 1},
            {"title": "Data We Collect", "content": "", "order": 2},
            {"title": "Purposes of Processing", "content": "", "order": 3},
            {"title": "Legal Basis", "content": "", "order": 4},
            {"title": "Third-Party Sharing", "content": "", "order": 5},
            {"title": "Data Retention", "content": "", "order": 6},
            {"title": "Your Rights Under DPDPA", "content": "", "order": 7},
            {"title": "Grievance Contact", "content": "", "order": 8},
            {"title": "Updates to This Notice", "content": "", "order": 9},
        ]
    },
}


def _escape_html(text: str) -> str:
    """Escape HTML special characters for safe embedding."""
    if not text:
        return ""
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _generate_privacy_notice_html(notice: PrivacyNotice, account: Account) -> str:
    """Generate HTML content for a privacy notice PDF.

    Uses a Noto Sans font stack to ensure Gujarati and other Unicode
    scripts render correctly when fonts-noto-core is installed.
    """
    content = notice.content or {}
    sections = content.get("sections", [])
    title = content.get("title", "Privacy Notice")
    language = content.get("language", "en")

    sections_html = ""
    for section in sections:
        sec_title = _escape_html(section.get("title", ""))
        sec_body = _escape_html(section.get("content", "")).replace("\n", "<br>")
        if sec_title:
            sections_html += f"<h2>{sec_title}</h2>"
        if sec_body:
            sections_html += f"<p>{sec_body}</p>"

    published_at_str = ""
    if notice.published_at:
        if isinstance(notice.published_at, datetime):
            published_at_str = notice.published_at.strftime("%B %d, %Y")
        else:
            published_at_str = str(notice.published_at)

    version_line = f"Version {notice.version}"
    if published_at_str:
        version_line += f" | Published: {published_at_str}"

    return f"""<!DOCTYPE html>
<html lang="{language}">
<head>
    <meta charset="UTF-8">
    <style>
        @page {{ size: A4; margin: 2cm; }}
        body {{
            font-family: 'Noto Sans', 'Noto Sans Gujarati', 'Noto Sans Devanagari', sans-serif;
            font-size: 11pt;
            line-height: 1.6;
            color: #1a202c;
        }}
        h1 {{
            font-size: 22pt;
            color: #1a365d;
            border-bottom: 2px solid #1a365d;
            padding-bottom: 12px;
            margin-bottom: 24px;
        }}
        h2 {{
            font-size: 14pt;
            color: #2c5282;
            margin-top: 24px;
            margin-bottom: 8px;
        }}
        p {{ margin: 0 0 12px 0; }}
        .header {{
            margin-bottom: 32px;
        }}
        .business-name {{
            font-size: 13pt;
            color: #4a5568;
            margin-top: 4px;
        }}
        .footer {{
            margin-top: 48px;
            padding-top: 12px;
            border-top: 1px solid #e2e8f0;
            font-size: 9pt;
            color: #718096;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{_escape_html(title)}</h1>
        <div class="business-name">{_escape_html(account.business_name)}</div>
    </div>
    {sections_html}
    <div class="footer">
        <p>{version_line}</p>
        <p>This privacy notice is published in accordance with the Digital Personal Data Protection Act, 2023 (DPDPA) of India.</p>
    </div>
</body>
</html>"""


def _generate_pdf_from_html(html_content: str) -> bytes:
    """Generate PDF bytes from HTML using WeasyPrint."""
    import weasyprint
    return weasyprint.HTML(string=html_content).write_pdf()


def _prefill_sections(template_type: str, account: Account, inventory_elements: list) -> list:
    """Pre-fill notice sections with account data and inventory."""
    template = TEMPLATES.get(template_type, TEMPLATES["generic"])
    sections = [s.copy() for s in template["sections"]]

    for section in sections:
        if section["title"] == "Introduction":
            section["content"] = (
                f"This Privacy Notice explains how {account.business_name} "
                f'(\"we\", "us", "our") collects, uses, stores, and protects '
                f"your personal data in accordance with the Digital Personal Data "
                f"Protection Act, 2023 (DPDPA) of India.\n\n"
                f"By using our services, you consent to the practices described in this notice."
            )

        elif section["title"] in ("Data We Collect", "Client Data We Collect"):
            if inventory_elements:
                fields = ", ".join([e.field_name for e in inventory_elements[:10]])
                section["content"] = f"We collect the following categories of personal data: {fields}"
            else:
                section["content"] = "We collect personal data necessary to provide our services to you."

        elif section["title"] == "Grievance Contact":
            contact_parts = []
            if account.grievance_email:
                contact_parts.append(f"Email: {account.grievance_email}")
            if account.grievance_phone:
                contact_parts.append(f"Phone: {account.grievance_phone}")
            if account.grievance_address:
                contact_parts.append(f"Address: {account.grievance_address}")

            if contact_parts:
                section["content"] = (
                    "If you have any concerns about how we handle your personal data, "
                    f"please contact our Grievance Officer:\n\n" + "\n".join(contact_parts)
                )
            else:
                section["content"] = "Grievance contact information will be updated shortly."

        elif section["title"] == "Your Rights Under DPDPA":
            section["content"] = (
                "Under the DPDPA, you have the following rights:\n\n"
                "1. Right to Access: You can request a copy of your personal data we hold.\n"
                "2. Right to Correction: You can request correction of inaccurate or misleading data.\n"
                "3. Right to Erasure: You can request deletion of your personal data.\n"
                "4. Right to Grievance Redressal: You can file a complaint with our Grievance Officer.\n"
                "5. Right to Nominate: You can nominate another individual to exercise your rights.\n\n"
                "To exercise any of these rights, please contact us using the Grievance Contact information below."
            )

    return sections


@router.post("", response_model=PrivacyNoticeResponse, status_code=status.HTTP_201_CREATED)
async def create_notice(
    request: Request,
    data: PrivacyNoticeCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Create a new privacy notice from template."""
    # Get inventory elements for pre-fill
    result = await db.execute(
        select(DataElement)
        .join(DataSource)
        .where(
            DataSource.account_id == current_user.account_id,
            DataSource.status == "confirmed",
        )
    )
    elements = result.scalars().all()

    # Get account for business details
    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    account = result.scalar_one()

    # Pre-fill sections
    sections = _prefill_sections(data.template_type, account, elements)

    # If content provided, merge with pre-filled
    if data.content:
        provided_sections = data.content.get("sections", [])
        for ps in provided_sections:
            for s in sections:
                if s["title"] == ps.get("title"):
                    s["content"] = ps.get("content", s["content"])
                    break

    # Unpublish any existing published notice
    await db.execute(
        update(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == current_user.account_id,
            PrivacyNotice.is_published == True,
        )
        .values(is_published=False)
    )

    # Get next version number
    result = await db.execute(
        select(PrivacyNotice)
        .where(PrivacyNotice.account_id == current_user.account_id)
        .order_by(PrivacyNotice.version.desc())
    )
    latest = result.scalar_one_or_none()
    version = (latest.version + 1) if latest else 1

    notice = PrivacyNotice(
        account_id=current_user.account_id,
        template_type=data.template_type,
        content={"sections": sections, "language": data.language},
        is_published=False,
        version=version,
    )
    db.add(notice)
    await db.commit()
    await db.refresh(notice)

    logger.info(f"Privacy notice created: v{version} for account {current_user.account_id}")
    return notice


@router.get("/current", response_model=PrivacyNoticeResponse)
async def get_current_notice(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get the current published privacy notice."""
    result = await db.execute(
        select(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == current_user.account_id,
            PrivacyNotice.is_published == True,
        )
        .order_by(PrivacyNotice.version.desc())
    )
    notice = result.scalar_one_or_none()

    if not notice:
        raise HTTPException(status_code=404, detail="No published privacy notice found")

    return notice


@router.get("/versions", response_model=list[PrivacyNoticeResponse])
async def list_versions(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List all privacy notice versions."""
    result = await db.execute(
        select(PrivacyNotice)
        .where(PrivacyNotice.account_id == current_user.account_id)
        .order_by(PrivacyNotice.version.desc())
    )
    return result.scalars().all()


@router.post("/{notice_id}/publish", response_model=PrivacyNoticeResponse)
async def publish_notice(
    notice_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Publish a privacy notice."""
    # Unpublish current
    await db.execute(
        update(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == current_user.account_id,
            PrivacyNotice.is_published == True,
        )
        .values(is_published=False)
    )

    # Publish requested
    result = await db.execute(
        select(PrivacyNotice).where(
            PrivacyNotice.public_id == notice_id,
            PrivacyNotice.account_id == current_user.account_id,
        )
    )
    notice = result.scalar_one_or_none()
    if not notice:
        raise HTTPException(status_code=404, detail="Privacy notice not found")

    notice.is_published = True
    notice.published_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(notice)

    return notice


@router.post("/{notice_id}/unpublish", response_model=PrivacyNoticeResponse)
async def unpublish_notice(
    notice_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Unpublish a privacy notice."""
    result = await db.execute(
        select(PrivacyNotice).where(
            PrivacyNotice.public_id == notice_id,
            PrivacyNotice.account_id == current_user.account_id,
        )
    )
    notice = result.scalar_one_or_none()
    if not notice:
        raise HTTPException(status_code=404, detail="Privacy notice not found")

    notice.is_published = False
    notice.published_at = None
    await db.commit()
    await db.refresh(notice)

    return notice


@router.get("/{notice_id}/download")
async def download_privacy_notice_pdf(
    notice_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Download a privacy notice as a PDF.

    Generates the PDF synchronously using WeasyPrint and returns it
    directly as an attachment. Gujarati and other Unicode scripts are
    supported when fonts-noto-core is installed.
    """
    from app.models import AuditLog

    # Fetch notice
    result = await db.execute(
        select(PrivacyNotice).where(
            PrivacyNotice.public_id == notice_id,
            PrivacyNotice.account_id == current_user.account_id,
        )
    )
    notice = result.scalar_one_or_none()
    if not notice:
        raise HTTPException(status_code=404, detail="Privacy notice not found")

    # Fetch account for business name
    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    account = result.scalar_one()

    # Generate HTML and PDF
    html = _generate_privacy_notice_html(notice, account)
    try:
        pdf_bytes = _generate_pdf_from_html(html)
    except Exception as exc:
        logger.error(f"PDF generation failed for notice {notice_id}: {exc}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="PDF generation failed. Ensure WeasyPrint and system fonts are installed.",
        )

    # Audit log
    audit = AuditLog(
        account_id=current_user.account_id,
        user_id=current_user.id,
        event_type="privacy_notice_downloaded",
        event_details={
            "notice_public_id": str(notice.public_id),
            "version": notice.version,
        },
    )
    db.add(audit)
    await db.commit()

    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="privacy-notice-v{notice.version}.pdf"'
        },
    )


# Public endpoints (no auth)
@router.get("/public/{business_slug}", response_model=PublicNoticeResponse)
async def public_notice(
    business_slug: str,
    db: AsyncSession = Depends(get_db),
):
    """Public privacy notice page for embedding."""
    account = await get_account_from_slug(business_slug, db)

    result = await db.execute(
        select(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == account.id,
            PrivacyNotice.is_published == True,
        )
        .order_by(PrivacyNotice.version.desc())
    )
    notice = result.scalar_one_or_none()

    if not notice:
        raise HTTPException(status_code=404, detail="No published notice found")

    return PublicNoticeResponse(
        business_name=account.business_name,
        business_slug=account.business_slug,
        content=notice.content,
        published_at=notice.published_at,
        version=notice.version,
    )


@router.get("/versions/{version_id}", response_model=PrivacyNoticeResponse)
async def get_version_detail(
    version_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get a specific version of the privacy notice by its public_id."""
    result = await db.execute(
        select(PrivacyNotice).where(
            PrivacyNotice.public_id == version_id,
            PrivacyNotice.account_id == current_user.account_id,
        )
    )
    notice = result.scalar_one_or_none()
    if not notice:
        raise HTTPException(status_code=404, detail="Version not found")
    return notice


@router.post("/versions/{version_id}/restore", response_model=MessageResponse)
async def restore_version(
    version_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Restore a previous privacy notice version as the current published one.

    Creates a NEW version with the old content, increments version_number,
    and sets is_current=True (unsettling any other current version).
    """
    result = await db.execute(
        select(PrivacyNotice).where(
            PrivacyNotice.public_id == version_id,
            PrivacyNotice.account_id == current_user.account_id,
        )
    )
    old_notice = result.scalar_one_or_none()
    if not old_notice:
        raise HTTPException(status_code=404, detail="Version not found")

    # Unpublish any currently published version
    await db.execute(
        update(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == current_user.account_id,
            PrivacyNotice.is_published == True,
        )
        .values(is_published=False)
    )

    # Determine next version number
    max_version = (
        await db.execute(
            select(func.max(PrivacyNotice.version)).where(
                PrivacyNotice.account_id == current_user.account_id
            )
        )
    ).scalar() or 0

    # Create new version with old content, published as the active notice
    new_notice = PrivacyNotice(
        account_id=current_user.account_id,
        template_type=old_notice.template_type,
        content=old_notice.content,
        version=max_version + 1,
        is_published=True,
        published_at=datetime.now(timezone.utc),
    )
    db.add(new_notice)
    await db.commit()
    await db.refresh(new_notice)

    logger.info(f"Privacy notice restored from version {version_id} to {new_notice.public_id}")
    return MessageResponse(
        message=f"Restored as version {new_notice.version}: {new_notice.public_id}"
    )
