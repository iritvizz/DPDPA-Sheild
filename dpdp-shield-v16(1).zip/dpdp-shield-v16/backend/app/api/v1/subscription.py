"""Subscription and payment routes."""
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.models import Account, AccountStatus, Subscription, SubscriptionStatus, User
from app.schemas import (
    MessageResponse,
    RazorpayCheckoutRequest,
    RazorpayCheckoutResponse,
    SubscriptionResponse,
)
from app.services.payment_service import verify_razorpay_signature
from app.utils.auth import get_current_active_user, require_admin
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/subscription", tags=["subscription"])

# Plan configuration
PLANS = {
    "dpdp-shield-pro": {
        "name": "DPDP Shield Pro",
        "monthly_price": 1999,  # INR
        "yearly_price": 19999,  # INR
        "currency": "INR",
    }
}


@router.get("", response_model=SubscriptionResponse)
async def get_subscription(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get current subscription details."""
    result = await db.execute(
        select(Subscription)
        .where(Subscription.account_id == current_user.account_id)
        .order_by(Subscription.created_at.desc())
    )
    sub = result.scalar_one_or_none()

    if not sub:
        # Return trial status if no subscription record
        return SubscriptionResponse(
            id=0,
            plan_id="dpdp-shield-pro",
            status="trial",
            current_period_start=None,
            current_period_end=None,
            created_at=current_user.account.created_at,
        )

    return sub


@router.post("/checkout", response_model=RazorpayCheckoutResponse)
async def create_checkout(
    data: RazorpayCheckoutRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Create Razorpay checkout session."""
    settings = get_settings()
    plan = PLANS.get(data.plan_id, PLANS["dpdp-shield-pro"])

    # Ensure a pending subscription row exists to link back to this account
    # once Razorpay's webhook arrives. Previously this endpoint returned
    # checkout config without persisting anything at all -- the webhook
    # handler had no record to find, ever, for a genuinely new subscription.
    result = await db.execute(
        select(Subscription).where(
            Subscription.account_id == current_user.account_id,
            Subscription.status.in_([SubscriptionStatus.TRIAL, SubscriptionStatus.ACTIVE]),
        )
    )
    existing = result.scalar_one_or_none()
    if not existing:
        sub = Subscription(
            account_id=current_user.account_id,
            plan_id=data.plan_id,
            status=SubscriptionStatus.TRIAL,
        )
        db.add(sub)
        await db.commit()

    # NOTE: this still doesn't fully close the loop -- see webhooks.py's
    # razorpay_webhook for the honest explanation of what's still unverified
    # here (linking the eventual real razorpay_subscription_id back to this
    # account depends on passing account_id through Razorpay's `notes` field
    # at actual subscription-creation time via their real API, which requires
    # a live Razorpay sandbox to verify -- not something confirmable from
    # this codebase alone).
    return RazorpayCheckoutResponse(
        order_id=f"order_{current_user.account_id}_{datetime.now(timezone.utc).timestamp()}",
        key_id=settings.RAZORPAY_KEY_ID or "test_key",
        amount=plan["monthly_price"] * 100,  # Razorpay expects paise
        currency=plan["currency"],
    )


@router.post("/cancel", response_model=MessageResponse)
async def cancel_subscription(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Cancel subscription (access continues until period end)."""
    result = await db.execute(
        select(Subscription)
        .where(
            Subscription.account_id == current_user.account_id,
            Subscription.status == SubscriptionStatus.ACTIVE,
        )
    )
    sub = result.scalar_one_or_none()

    if not sub:
        raise HTTPException(status_code=404, detail="No active subscription found")

    sub.status = SubscriptionStatus.CANCELLED
    await db.commit()

    return MessageResponse(message="Subscription cancelled. Access continues until end of current period.")
