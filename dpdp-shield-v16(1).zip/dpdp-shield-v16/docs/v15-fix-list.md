# DPDP Shield v15 — Verified Fixes & Remaining Work

Continuing from v14.

---

## Confirmed fixed and verified in this pass

1. **Malware-scan test passes cleanly — assertion, not just "not hanging."** The v14 fix eliminated the deadlock by extracting `scan_consent_proof_async` as a plain async function, but the test's final verification read through `db_session` which had the row in its identity map from the test setup, returning a stale in-memory copy (`proof_file_status == "none"`) instead of the committed update (`"clean"`). Fixed by wrapping the final read-back in a fresh `async with TestingSessionLocal() as fresh_session:` block, restoring the pattern the pre-rewrite test used. Confirmed: the test now passes on its own and the full suite completes without hangs or assertion failures.
2. **Cancel-deletion endpoint is actually reachable during cooling-off.** The v14 endpoint used `require_admin`, which chains through `get_current_active_user` — that dependency rejects any account with status `"deleted"` with 403 before the endpoint body ever runs. Since the entire 48-hour cooling-off window uses status `"deleted"`, the endpoint was unreachable for its one intended use case. Fixed by adding `require_admin_any_status` (uses `get_current_user` for auth, checks role manually, skips the active-account gate) and wiring it into `cancel_deletion`. Confirmed live: `POST /api/v1/account/cancel-deletion` with a `"deleted"` account now returns 200 and flips status back to `ACTIVE`, instead of 403.
3. **Cancel-deletion has test coverage.** New `tests/test_account_cancel_deletion.py` with three cases: successful cancellation during cooling-off, 400 when account is not scheduled for deletion, and 403 when caller is staff (not admin). Prevents the "endpoint exists but is unreachable" class of bug from regressing.

---

## Carried forward from v14 (genuinely fixed, not re-verified this round)

- Internal-ID exposure sweep completed across all response schemas.
- Malware-scan deadlock eliminated via `scan_consent_proof_async` async core.
- Razorpay webhook secret enforced in production.
- Redis rate-limit test isolation.
- `moto` / `pytest-mock` declared.
- `lib/api.ts` syntax error fixed.
- Duplicate endpoints removed, accept-invite uses JSON body.
- Dead Celery task files deleted.

---

## Still open / carried forward

- **Real Docker build end-to-end.** No Docker daemon available in the verification environment.
- **Real Razorpay sandbox verification.** Notes-based account linking not exercised against real API.
- **Rate limiting under genuine multi-worker concurrency.** Not load-tested against 500-concurrent-user NFR.
- **`pip-audit` on Python dependencies.** 43 advisories across `starlette`, `pillow`, `python-multipart`, `weasyprint`, `pytest` — unchanged.
- **Frontend pages beyond auth.** Dashboard, Inventory, Consent, Privacy Notice, RoPA, Account, Subscription, DSAR, and Admin panels still unbuilt.
- **Alembic migrations.** `dsar_requests` table, `deletion_task_id` column, `superadmin` enum value still need production migrations.
- **pytest-asyncio deprecation.** `event_loop` fixture override works on 0.23.7 but triggers deprecation warning.
- **`npm audit` on frontend.** Moderate/high advisories remain in `next-intl` and transitive `postcss`.
- **`next/font/google` build-time network dependency.** Consider `next/font/local` with vendored font files for restricted CI environments.

---

## Process note

This round's miss pattern: "the new code is correct in isolation and wrong in context." The malware-scan test stopped hanging (the specific thing being fixed) but failed on an assertion (a different problem introduced by the same rewrite). The cancel-deletion endpoint's internal logic was correct but its dependency chain blocked it from ever executing. Both were caught by calling the code the way it's meant to be called, in the state it's meant to be called in — not by reading the code or confirming it runs without crashing. The fix for both was small once the root cause was isolated; the work was in getting to the root cause rather than stopping at the symptom.
