"use client";

import { useTranslations } from "next-intl";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function SettingsPage() {
  const t = useTranslations();

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t("settings.title")}</h2>

      <Card>
        <CardHeader>
          <CardTitle>{t("settings.businessDetails")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">{t("settings.businessName")}</label>
            <Input placeholder="Your Business Name" />
          </div>
          <div>
            <label className="text-sm font-medium">{t("settings.businessSlug")}</label>
            <Input placeholder="your-business" />
          </div>
          <div>
            <label className="text-sm font-medium">{t("settings.sector")}</label>
            <Input placeholder="E-commerce" />
          </div>
          <Button>{t("settings.saveChanges")}</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("settings.staffManagement")}</CardTitle>
        </CardHeader>
        <CardContent>
          <Button variant="outline">{t("settings.inviteStaff")}</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("settings.billing")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p className="text-gray-500">{t("settings.currentPlan")}: DPDP Shield Pro</p>
          <Button variant="outline">{t("settings.manageSubscription")}</Button>
        </CardContent>
      </Card>

      <Card className="border-red-200">
        <CardHeader>
          <CardTitle className="text-red-600">{t("settings.dangerZone")}</CardTitle>
        </CardHeader>
        <CardContent>
          <Button variant="destructive">{t("settings.deleteAccount")}</Button>
        </CardContent>
      </Card>
    </div>
  );
}
