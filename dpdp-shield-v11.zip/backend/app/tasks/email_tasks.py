"""Celery tasks for email dispatch."""
from app.tasks import celery_app
from app.services.email_service import EmailService
from app.utils.logging import get_logger

logger = get_logger(__name__)


@celery_app.task(bind=True, max_retries=3)
def send_email_task(self, to_email: str, subject: str, body_text: str, body_html: str = None):
    """Send email asynchronously."""
    try:
        import asyncio
        service = EmailService()
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(
            service.send_email(to_email, subject, body_text, body_html)
        )
        loop.close()
        return {"status": "success", "sent": result}
    except Exception as exc:
        logger.error(f"Email sending failed: {exc}")
        raise self.retry(exc=exc, countdown=60)
