# DPDP Shield v17 — Applied and Verified Changes

**Important context for whoever picks this up next:** this round was done by the reviewer (Claude), not the usual developer agent, at the user's explicit request. That means the usual "developer claims, reviewer verifies" structure doesn't apply here — there was no independent check on this work. Treat this zip the same way you'd treat any other round's submission: verify it fresh, don't assume it's correct because of who wrote it.

Everything below was actually run, not just written. Methodology: fresh venv, fresh Postgres/Redis, live HTTP calls against every endpoint touched, `pytest` run twice back to back, `tsc --noEmit` across the whole frontend, `npm run build`.

---

## Backend

### The root-cause fix (previously blocked 3 "complete" features)
- Added `public_id` (UUID) to `DataSource` and `PrivacyNotice` — neither had one before, despite every new endpoint built in the prior round assuming they did.
- Found a third instance while fixing Retention: `AuditLog` also had no `public_id`, needed for `DeletionLogResponse.log_id`. Added it too.
- Discovered the older endpoints in `inventory.py` and `privacy_notice.py` (source CRUD, notice publish/unpublish) were using raw `int` ids while the newer endpoints (element PATCH/DELETE, version detail/restore) expected UUIDs for the *same resource*. Converted everything to `public_id` consistently — 5 endpoints in `inventory.py`, 4 in `privacy_notice.py`.
- Live-verified end to end: element PATCH/DELETE, retention deletion-log, privacy notice publish → version-detail → unpublish → restore. All work now with real `public_id`s.

### Alembic — made genuinely real, not just initialized
- The baseline migration (`001_initial_schema.py`) was an empty `pass` — confirmed by testing that `alembic upgrade head` on a truly fresh database created zero application tables. Replaced it with a real schema snapshot generated via `alembic revision --autogenerate` against an empty database at the current model state.
- Added a proper incremental migration for the `AuditLog.public_id` column, and specifically tested it against a table with a pre-existing row to confirm the NOT-NULL backfill doesn't break real data (add nullable → backfill with generated UUIDs → enforce NOT NULL, rather than adding NOT NULL directly).
- Verified twice: `alembic upgrade head` alone now creates the full, correct schema on a fresh database, and a follow-up `--autogenerate` against that result shows zero diff.

### A serious, unrelated, pre-existing bug: all PDF generation was broken
- `weasyprint==62.3` is pinned in `requirements.txt`; its transitive dependency `pydyf` was not, so a clean install resolves an incompatible version (0.12.1) whose breaking API changes crash *any* `weasyprint.HTML(...).write_pdf()` call. Confirmed with raw WeasyPrint, zero app code involved — this affected the pre-existing audit-pack generator too, not just anything new.
- Pinned `pydyf==0.10.0` (the version weasyprint 62.3 actually declares as its minimum). Confirmed clean, no dependency-resolver conflict warning.

### Newly implemented (were called/referenced, never written)
- `generate_inventory_pdf` in `app/tasks/pdf.py` — the export endpoint called this and it didn't exist.
- `S3Service.upload_file` — the same export endpoint called this too; also didn't exist.

### Other fixes found while live-testing (each confirmed by reproducing and then fixing the exact failure)
- `retention.py`: no validation that a submitted `data_source_public_id` actually belongs to the account — added an existence/ownership check before logging the attestation.
- `retention.py`: `AuditLog` construction used fictional field names (`action`, `details`) instead of the model's real ones (`event_type`, `event_details`).
- `privacy_notice.py restore_version`: referenced three fields that don't exist on `PrivacyNotice` at all (`title`, `version_number`, `is_current` — real fields are none of these; there's no title field, the real version field is `version`, and there's no separate "current" flag beyond `is_published`). Rewritten using real fields and sensible semantics (unpublish the currently-published version, create the restored content as a new, published version).
- `inventory.py parse_file_headers`: `ParseFileResponse` had no `data_source_id` field at all, and the endpoint passed one as an unrecognized kwarg that Pydantic silently dropped — meaning the frontend had no way to know which `DataSource` an upload created. Added the field (as `public_id`), fixed the endpoint to actually return it.
- `consent.py generate_withdrawal_link`: referenced `settings.APP_URL`, which doesn't exist (real field is `FRONTEND_URL`).
- **`consent.py public withdrawal flow` — a design gap, not just a bug**: the original `GET /public/withdrawal/{token}` required the record to already be revoked to return anything but 404, meaning there was no way for a customer to actually *use* their withdrawal link to withdraw consent — only to confirm one a business admin had already revoked internally. Rewritten: `GET` now shows current status either way, and a new `POST` to the same path performs the actual self-service withdrawal (same pattern as the existing password-reset token flow). Verified live: GET before → POST to withdraw → GET after, all three show correct, consistent state.
- Plus the same class of import/naming bugs the last review already caught in this exact zip (missing `uuid` imports in two files, a wrong schema class name, a missing `MessageResponse` import, a missing `enum_value` import) — all fixed, all confirmed live.

### Verified stable throughout
`pytest tests/` — 28/28, run twice back to back after every batch of changes, no hang, no rate-limit bleed, at the end of the whole session.

---

## Frontend

All 7 dashboard pages plus both public pages were rewritten from placeholder/disconnected shells to actually call the backend:

- **Dashboard**: real `GET /dashboard/summary` call, real checklist and trial-days data, loading/error states.
- **Settings**: every control is now functional — business details form (real PATCH), staff list + invite + remove, subscription status + cancel, and the delete-account / cancel-deletion flow (including the 48-hour cooling-off banner). Previously not one button on this page did anything.
- **Consent**: log consent (real form), list with real data, revoke, generate-and-copy withdrawal link, CSV export download.
- **Inventory**: real drag-and-drop upload → `parse-headers` → editable classification review table → confirm → element save, plus a real data-source list with delete.
- **Privacy Notice**: generate a draft (calls the real auto-generation endpoint, which pulls in actual business/inventory data), publish/unpublish, restore-as-new-version — all against real data, with the actual generated legal content rendered.
- **Public notice page** (`/public/notice/[businessSlug]`): server-side fetch against the real public endpoint, no auth needed, renders actual published content or a clean "not found" state.
- **Public withdrawal page** (`/public/withdrawal/[token]`): fetches real status, and now actually performs the withdrawal on confirm (this only became possible once the backend design gap above was fixed).

`npx tsc --noEmit` — zero errors across the whole project after all of the above.

`npm run build` — reaches the same wall every round has reached: the `next/font/google` fetch to `fonts.googleapis.com`, blocked by this environment's restricted network egress. Not a code defect — confirmed the same way in every prior review.

Two things flagged in the last review, both confirmed fixed and still fixed in this pass: `@radix-ui/react-label` is in `package.json`, and the locale files have `dsar`/`reports` in all three languages without having overwritten the existing `consent`/`settings` keys.

---

## Still open — genuinely not addressed this round

- DSAR and Reports frontend pages are still "coming soon" placeholders — their backends (action log, audit-pack generation, monthly summary) work and are live-tested, but no UI was built against them this round.
- OTP-based signup, admin impersonation UI, consent widget embed snippet — none started.
- No real Docker build/`docker-compose up` by anyone with a working daemon — still never done, across every round of this project.
- `pip-audit` / `npm audit` findings from many rounds ago — untouched.
- Load/concurrency testing against the spec's 500-user target — never attempted.
- No new automated test coverage was added for anything fixed or wired up this round. Everything above was verified by hand, live, not by a test suite. That gap should be the next priority — hand-verification doesn't survive the next round of changes the way a test does.
