"""Pytest configuration."""
import asyncio
import os

import pytest
import pytest_asyncio
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.database import Base, get_db
from app.main import app

TEST_DATABASE_URL = os.environ.get(
    "TEST_DATABASE_URL",
    "postgresql+asyncpg://postgres:postgres@db:5432/dpdp_shield_test",
)

engine = create_async_engine(TEST_DATABASE_URL, echo=False)
TestingSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def override_get_db():
    async with TestingSessionLocal() as session:
        yield session


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(scope="session", autouse=True)
def flush_redis_before_session():
    """Flush Redis rate-limit keys before the test session starts.

    Prevents 429 failures from stale counters left by previous test runs
    or manual development use.  We unconditionally scan and delete all
    keys matching `ratelimit:*` on the *actual* REDIS_URL the app uses.
    A previous attempt tried redirecting to Redis DB index 15, but that
    failed silently because get_settings() is @lru_cache'd and already
    frozen to the default DB by the time this fixture runs.
    """
    import redis
    from app.config import get_settings
    settings = get_settings()
    client = redis.from_url(settings.REDIS_URL, decode_responses=True)
    for key in client.scan_iter(match="ratelimit:*"):
        client.delete(key)
    yield


@pytest.fixture(scope="session")
def anyio_backend():
    return "asyncio"


# NOTE: This fixture override triggers a pytest-asyncio deprecation warning
# on 0.23.x ("The event_loop fixture override is deprecated...").  It is
# still required for the module-level asyncpg engine to remain bound to one
# loop for the entire session.  When upgrading pytest-asyncio past 0.23,
# migrate to the @pytest.mark.asyncio(loop_scope="session") pattern and
# remove this fixture.
@pytest.fixture(scope="session")
def event_loop():
    """Session-scoped event loop so the module-level asyncpg engine
    remains bound to the same loop for the entire test session.
    Prevents InterfaceError / MissingGreenlet when pytest-asyncio
    otherwise creates a fresh loop per test.
    """
    policy = asyncio.get_event_loop_policy()
    loop = policy.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def async_client():
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client


@pytest_asyncio.fixture(autouse=True)
async def setup_database():
    """Create tables before each test, drop after."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest_asyncio.fixture
async def db_session():
    """Direct DB session for tests that need to set up/inspect data outside the HTTP layer."""
    async with TestingSessionLocal() as session:
        yield session
