# DPDP Shield v14 — Verified Fixes & Remaining Work

Continuing from v13.

---

## Confirmed fixed and verified in this pass

1. **Malware-scan test no longer hangs the suite — genuinely, this time.** The root cause was a self-deadlock: `_run_async_in_test` called `asyncio.run_coroutine_threadsafe(coro, loop)` from the same thread that was already running `loop`, then blocked on `threading.Event.wait()`. The loop could never get control back to execute the scheduled coroutine. Fixed by extracting the core logic into a plain `async def scan_consent_proof_async(...)` that tests `await` directly, completely bypassing Celery's sync task machinery. The Celery task wrapper (`@celery_app.task def scan_consent_proof`) is now a thin shell that delegates to the async core via `_run_async` (production path only, where no loop is running). This eliminates the sync/async boundary problem in tests entirely — no thread pools, no loop detection heuristics, no deadlock.
2. **Internal-ID exposure sweep completed.** Removed `account_id: int` from `DSARResponse` and `data_source_id: int` from `ParseFileResponse`. Neither raw sequential integer is accepted back from clients, so exposing them was unnecessary information disclosure. The sweep started in v12 is now complete across all response schemas.
3. **Account deletion has a cancel path.** New `POST /api/v1/account/cancel-deletion` endpoint flips `Account.status` back to `ACTIVE`, clears `deleted_at`, and revokes the scheduled Celery hard-deletion task by its stored ID. `delete_account` now stores the `task.id` from `hard_delete_account.apply_async()` in `Account.deletion_task_id` so it can be revoked later. The `hard_delete_account` task already checked `status != "deleted"` and returned `"cancelled"` as a fallback, but revoking the task is cleaner and prevents unnecessary work.

---

## Carried forward from v13 (genuinely fixed, not re-verified this round)

- Razorpay webhook secret enforced in production (`config.py`).
- Redis rate-limit test isolation (`conftest.py` flushes `ratelimit:*` on the real DB).
- `moto` and `pytest-mock` declared in `requirements.txt`.
- `lib/api.ts` syntax error fixed (Python docstring → JS comment).
- Duplicate `account.py` endpoints removed, accept-invite uses JSON body.
- Dead Celery task files (`pdf_tasks.py`, `email_tasks.py`) deleted.

---

## Still open / carried forward

- **Real Docker build end-to-end.** No Docker daemon available in the verification environment. The Dockerfile and compose fixes are correct by inspection but have never been `docker build`d.
- **Real Razorpay sandbox verification.** The notes-based account linking in webhooks is architecturally sound but not exercised against Razorpay's real API.
- **Rate limiting under genuine multi-worker concurrency.** Not load-tested against the 500-concurrent-user NFR.
- **`pip-audit` on Python dependencies.** 43 advisories across `starlette`, `pillow`, `python-multipart`, `weasyprint`, `pytest` — unchanged, needs a deliberate dependency refresh.
- **Frontend pages beyond auth.** Dashboard, Inventory, Consent, Privacy Notice, RoPA, Account, Subscription, DSAR, and Admin panels are still unbuilt.
- **Alembic migrations.** The `dsar_requests` table, `deletion_task_id` column, and `superadmin` enum value still need production migrations. Tests use `Base.metadata.create_all` so they don't need one.
- **pytest-asyncio deprecation.** The `event_loop` fixture override works on `pytest-asyncio==0.23.7` but triggers a deprecation warning. A future upgrade will require migrating to `@pytest.mark.asyncio(loop_scope="session")`.
- **`npm audit` on frontend.** Next.js 14.2.35 fixed the critical cache-poisoning advisory, but moderate/high advisories remain in `next-intl` and transitive `postcss`.
- **`next/font/google` build-time network dependency.** `app/layout.tsx` fetches the `Inter` font from `fonts.googleapis.com` during `npm run build`. This succeeds on machines with normal internet access but fails in restricted CI/build environments. Consider switching to `next/font/local` with vendored font files.

---

## Process note

This round illustrates a specific failure mode worth naming: a fix that "passes when I check it" but fails under a slightly different check. The v13 malware-scan fix was tested and reported as passing, but the specific test run that produced that claim didn't exercise the exact deadlock path (same thread blocking its own loop). The v14 fix sidesteps the entire category of problem by removing the sync/async boundary from the test path entirely — the test no longer calls any sync function that tries to hand work back to an async loop. When a bug involves threads, event loops, or blocking primitives, the safest fix is often to remove the boundary rather than to bridge it more cleverly.
