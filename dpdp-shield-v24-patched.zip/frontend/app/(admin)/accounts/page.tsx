"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import Link from "next/link";

interface AccountItem {
  public_id: string;
  business_name: string;
  business_slug: string;
  sector: string;
  status: string;
  trial_ends_at: string | null;
  created_at: string;
  user_count: number;
}

export default function AdminAccountsPage() {
  const t = useTranslations();
  const [accounts, setAccounts] = useState<AccountItem[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    loadAccounts();
  }, []);

  async function loadAccounts() {
    try {
      const data = await apiFetch("/api/v1/admin/accounts");
      setAccounts(data);
    } catch (err: any) {
      if (err.status === 403) {
        window.location.href = "/dashboard";
      } else {
        setError(err.message || "Failed to load accounts");
      }
    }
  }

  async function suspendAccount(id: string) {
    try {
      await apiFetch(`/api/v1/admin/accounts/${id}/suspend`, { method: "POST" });
      loadAccounts();
    } catch (err: any) {
      setError(err.message || "Failed to suspend");
    }
  }

  async function activateAccount(id: string) {
    try {
      await apiFetch(`/api/v1/admin/accounts/${id}/activate`, { method: "POST" });
      loadAccounts();
    } catch (err: any) {
      setError(err.message || "Failed to activate");
    }
  }

  const statusColors: Record<string, string> = {
    trial: "bg-blue-100 text-blue-800",
    active: "bg-green-100 text-green-800",
    suspended: "bg-red-100 text-red-800",
    expired: "bg-gray-100 text-gray-800",
    deleted: "bg-black text-white",
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t("admin.accounts")}</h2>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="space-y-4">
        {accounts.map((account) => (
          <Card key={account.public_id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{account.business_name}</h3>
                  <p className="text-sm text-gray-500">
                    {account.business_slug} · {account.sector} · {account.user_count} users
                  </p>
                  <p className="text-xs text-gray-400">
                    {new Date(account.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={statusColors[account.status] || "bg-gray-100"}>
                    {account.status}
                  </Badge>
                  <Link href={`/admin/accounts/${account.public_id}`}>
                    <Button variant="outline" size="sm">{t("admin.view")}</Button>
                  </Link>
                  {account.status === "suspended" ? (
                    <Button size="sm" onClick={() => activateAccount(account.public_id)}>
                      {t("admin.activate")}
                    </Button>
                  ) : (
                    <Button size="sm" variant="destructive" onClick={() => suspendAccount(account.public_id)}>
                      {t("admin.suspend")}
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        {accounts.length === 0 && (
          <p className="text-gray-500 text-center py-8">No accounts found.</p>
        )}
      </div>
    </div>
  );
}
