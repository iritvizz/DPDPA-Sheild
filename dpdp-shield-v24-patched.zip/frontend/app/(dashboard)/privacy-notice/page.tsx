"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

interface NoticeSection {
  title: string;
  content: string;
}

interface Notice {
  public_id: string;
  template_type: string;
  content: { sections: NoticeSection[] };
  is_published: boolean;
  version: number;
  created_at: string;
}

const TEMPLATE_TYPES = [
  { value: "ecommerce", label: "E-commerce" },
  { value: "service", label: "Service Business" },
  { value: "generic", label: "Generic" },
];

export default function PrivacyNoticePage() {
  const t = useTranslations();
  const [versions, setVersions] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [generating, setGenerating] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [templateType, setTemplateType] = useState("generic");

  const loadVersions = () => {
    setLoading(true);
    apiFetch("/api/v1/privacy-notice/versions")
      .then((data) => setVersions(data))
      .catch((err) => setError(err.message || "Failed to load privacy notices"))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadVersions();
  }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    setError("");
    setSuccess("");
    try {
      await apiFetch("/api/v1/privacy-notice", {
        method: "POST",
        body: JSON.stringify({ template_type: templateType, content: { sections: [] } }),
      });
      setSuccess("Privacy notice draft generated.");
      loadVersions();
    } catch (err: any) {
      setError(err.message || "Failed to generate privacy notice.");
    } finally {
      setGenerating(false);
    }
  };

  const handlePublish = async (id: string) => {
    setError("");
    setSuccess("");
    try {
      await apiFetch(`/api/v1/privacy-notice/${id}/publish`, { method: "POST" });
      setSuccess("Privacy notice published.");
      loadVersions();
    } catch (err: any) {
      setError(err.message || "Failed to publish.");
    }
  };

  const handleUnpublish = async (id: string) => {
    setError("");
    setSuccess("");
    try {
      await apiFetch(`/api/v1/privacy-notice/${id}/unpublish`, { method: "POST" });
      setSuccess("Privacy notice unpublished.");
      loadVersions();
    } catch (err: any) {
      setError(err.message || "Failed to unpublish.");
    }
  };

  const handleRestore = async (id: string) => {
    setError("");
    setSuccess("");
    try {
      const res = await apiFetch(`/api/v1/privacy-notice/versions/${id}/restore`, { method: "POST" });
      setSuccess(res.message);
      loadVersions();
    } catch (err: any) {
      setError(err.message || "Failed to restore version.");
    }
  };

  const handleDownload = async (id: string) => {
    setError("");
    setSuccess("");
    setDownloadingId(id);
    try {
      const token = localStorage.getItem('access_token');
      const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
      const res = await fetch(`${baseUrl}/api/v1/privacy-notice/${id}/download`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ detail: 'Download failed' }));
        throw new Error(err.detail || 'Download failed');
      }
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `privacy-notice-${id}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      setSuccess("PDF downloaded successfully.");
    } catch (err: any) {
      setError(err.message || "Failed to download PDF.");
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t("privacyNotice.title")}</h2>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {success && (
        <Alert>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Generate New Draft</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center gap-3">
          <select
            className="flex h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
            value={templateType}
            onChange={(e) => setTemplateType(e.target.value)}
          >
            {TEMPLATE_TYPES.map((tt) => (
              <option key={tt.value} value={tt.value}>{tt.label}</option>
            ))}
          </select>
          <Button onClick={handleGenerate} disabled={generating}>
            {generating ? "Generating..." : "Generate Draft"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Versions</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : versions.length === 0 ? (
            <p className="text-gray-500">No privacy notices yet. Generate a draft above.</p>
          ) : (
            <div className="space-y-4">
              {versions.map((v) => (
                <div key={v.public_id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">
                      Version {v.version} — {v.template_type}
                    </span>
                    <Badge variant={v.is_published ? "default" : "secondary"}>
                      {v.is_published ? "Published" : "Draft"}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-600 space-y-2 max-h-40 overflow-y-auto mb-3">
                    {v.content?.sections?.map((s, i) => (
                      <div key={i}>
                        <p className="font-medium">{s.title}</p>
                        <p className="text-gray-500 whitespace-pre-line">{s.content}</p>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {!v.is_published ? (
                      <Button size="sm" onClick={() => handlePublish(v.public_id)}>
                        Publish
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" onClick={() => handleUnpublish(v.public_id)}>
                        Unpublish
                      </Button>
                    )}
                    <Button size="sm" variant="outline" onClick={() => handleRestore(v.public_id)}>
                      Restore as New Version
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => handleDownload(v.public_id)}
                      disabled={downloadingId === v.public_id}
                    >
                      {downloadingId === v.public_id ? "Downloading..." : t("privacyNotice.downloadPdf")}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
