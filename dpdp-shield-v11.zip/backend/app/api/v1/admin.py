"""Admin panel routes -- superadmin only."""
import uuid

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Account, AccountStatus, ConsentRecord, DataSource, DSARRequest, Subscription, SubscriptionStatus, User
from app.schemas import AdminAccountListItem, AdminAnalyticsResponse, MessageResponse
from app.utils.auth import require_superadmin
from app.utils.enums import enum_value
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/accounts", response_model=list[AdminAccountListItem])
async def list_all_accounts(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """List all accounts with user counts (superadmin only)."""
    result = await db.execute(
        select(Account).order_by(Account.created_at.desc()).offset(skip).limit(limit)
    )
    accounts = result.scalars().all()

    items = []
    for account in accounts:
        user_count_result = await db.execute(
            select(func.count(User.id)).where(User.account_id == account.id)
        )
        user_count = user_count_result.scalar() or 0

        items.append(AdminAccountListItem(
            public_id=account.public_id,
            business_name=account.business_name,
            business_slug=account.business_slug,
            sector=account.sector,
            status=enum_value(account.status),
            trial_ends_at=account.trial_ends_at,
            created_at=account.created_at,
            user_count=user_count,
        ))

    return items


@router.post("/accounts/{account_id}/suspend", response_model=MessageResponse)
async def suspend_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """Suspend an account (superadmin only)."""
    result = await db.execute(select(Account).where(Account.public_id == account_id))
    account = result.scalar_one_or_none()

    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    account.status = AccountStatus.SUSPENDED
    await db.commit()

    logger.warning(f"Account suspended by superadmin: {account.public_id}")
    return MessageResponse(message=f"Account {account.business_name} suspended.")


@router.post("/accounts/{account_id}/activate", response_model=MessageResponse)
async def activate_account(
    account_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """Activate a suspended account (superadmin only)."""
    result = await db.execute(select(Account).where(Account.public_id == account_id))
    account = result.scalar_one_or_none()

    if not account:
        raise HTTPException(status_code=404, detail="Account not found")

    account.status = AccountStatus.ACTIVE
    await db.commit()

    logger.info(f"Account activated by superadmin: {account.public_id}")
    return MessageResponse(message=f"Account {account.business_name} activated.")


@router.get("/analytics", response_model=AdminAnalyticsResponse)
async def get_analytics(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_superadmin),
):
    """Platform-wide analytics (superadmin only)."""
    total_accounts = (await db.execute(select(func.count(Account.id)))).scalar() or 0
    total_users = (await db.execute(select(func.count(User.id)))).scalar() or 0
    total_consent = (await db.execute(select(func.count(ConsentRecord.id)))).scalar() or 0
    total_sources = (await db.execute(select(func.count(DataSource.id)))).scalar() or 0
    active_subs = (await db.execute(
        select(func.count(Subscription.id)).where(Subscription.status == SubscriptionStatus.ACTIVE)
    )).scalar() or 0
    trial_accs = (await db.execute(
        select(func.count(Account.id)).where(Account.status == AccountStatus.TRIAL)
    )).scalar() or 0
    pending_dsars = (await db.execute(
        select(func.count(DSARRequest.id)).where(DSARRequest.status == "pending")
    )).scalar() or 0

    return AdminAnalyticsResponse(
        total_accounts=total_accounts,
        total_users=total_users,
        total_consent_records=total_consent,
        total_data_sources=total_sources,
        active_subscriptions=active_subs,
        trial_accounts=trial_accs,
        dsar_requests_pending=pending_dsars,
    )
