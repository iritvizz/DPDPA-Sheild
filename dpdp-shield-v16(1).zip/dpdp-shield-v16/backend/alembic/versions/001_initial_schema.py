"""Initial schema — v16 baseline.

Revision ID: 001
Revises:
Create Date: 2026-08-07

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # This is a baseline migration.  In a real production setup, this would
    # contain the full CREATE TABLE statements for every model.  For the
    # MVP, running `Base.metadata.create_all()` on first boot (already
    # implemented in app/main.py lifespan) is sufficient.  This migration
    # exists so that subsequent schema changes can be tracked properly.
    pass


def downgrade() -> None:
    pass
