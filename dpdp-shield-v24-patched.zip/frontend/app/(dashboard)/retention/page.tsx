"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { apiFetch } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface RetentionExpiry {
  data_source_public_id: string;
  data_source_name: string;
  field_name: string;
  data_category: string;
  retention_period: string;
  expiry_date: string;
  days_remaining: number;
}

interface DeletionLog {
  log_id: string;
  action: string;
  performed_at: string;
  performed_by: string;
  data_source_public_id: string;
  field_names: string[];
  deletion_method: string;
}

export default function RetentionPage() {
  const t = useTranslations();
  const [expiries, setExpiries] = useState<RetentionExpiry[]>([]);
  const [logs, setLogs] = useState<DeletionLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showAttest, setShowAttest] = useState(false);
  const [attestSourceId, setAttestSourceId] = useState("");
  const [attestFields, setAttestFields] = useState("");
  const [attestMethod, setAttestMethod] = useState("");
  const [attestNotes, setAttestNotes] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadExpiries();
    loadLogs();
  }, []);

  async function loadExpiries() {
    try {
      const data = await apiFetch("/api/v1/retention/expiries?days_warning=90");
      setExpiries(data);
    } catch (err: any) {
      setError(err.message || "Failed to load expiries");
    } finally {
      setLoading(false);
    }
  }

  async function loadLogs() {
    try {
      const data = await apiFetch("/api/v1/audit-log");
      const deletionLogs = data.filter((log: any) => log.event_type === "deletion_attestation");
      setLogs(deletionLogs.map((log: any) => ({
        log_id: log.public_id,
        action: log.event_type,
        performed_at: log.created_at,
        performed_by: log.event_details?.performed_by || "unknown",
        data_source_public_id: log.event_details?.data_source_public_id || "",
        field_names: log.event_details?.field_names || [],
        deletion_method: log.event_details?.deletion_method || "",
      })));
    } catch (err: any) {
      // Non-critical
    }
  }

  async function submitAttestation(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      await apiFetch("/api/v1/retention/deletion-log", {
        method: "POST",
        body: JSON.stringify({
          data_source_public_id: attestSourceId,
          field_names: attestFields.split(",").map((f) => f.trim()).filter(Boolean),
          deletion_method: attestMethod,
          notes: attestNotes,
        }),
      });
      setShowAttest(false);
      setAttestSourceId("");
      setAttestFields("");
      setAttestMethod("");
      setAttestNotes("");
      loadLogs();
    } catch (err: any) {
      setError(err.message || "Failed to log attestation");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <p className="text-gray-500">Loading retention data...</p>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{t("retention.title")}</h2>
        <Button onClick={() => setShowAttest(!showAttest)}>
          {showAttest ? t("auth.back") : t("retention.recordDeletion")}
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {showAttest && (
        <Card>
          <CardHeader>
            <CardTitle>{t("retention.recordDeletion")}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-amber-600 mb-4">{t("retention.attestationWarning")}</p>
            <form onSubmit={submitAttestation} className="space-y-4">
              <div>
                <Label>{t("retention.dataSourceId")}</Label>
                <Input
                  value={attestSourceId}
                  onChange={(e) => setAttestSourceId(e.target.value)}
                  placeholder="Data source public ID"
                  required
                />
              </div>
              <div>
                <Label>{t("retention.fieldsDeleted")}</Label>
                <Input
                  value={attestFields}
                  onChange={(e) => setAttestFields(e.target.value)}
                  placeholder="email, phone, address (comma-separated)"
                  required
                />
              </div>
              <div>
                <Label>{t("retention.deletionMethod")}</Label>
                <Input
                  value={attestMethod}
                  onChange={(e) => setAttestMethod(e.target.value)}
                  placeholder="e.g. Secure wipe via DB admin panel"
                  required
                />
              </div>
              <div>
                <Label>{t("retention.notes")}</Label>
                <Textarea
                  value={attestNotes}
                  onChange={(e) => setAttestNotes(e.target.value)}
                />
              </div>
              <Button type="submit" disabled={saving}>{t("retention.confirmAttestation")}</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>{t("retention.upcomingExpiries")}</CardTitle>
        </CardHeader>
        <CardContent>
          {expiries.length === 0 ? (
            <p className="text-gray-500">{t("retention.noExpiries")}</p>
          ) : (
            <div className="space-y-3">
              {expiries.map((exp) => (
                <div key={`${exp.data_source_public_id}-${exp.field_name}`} className="flex items-center justify-between p-3 border rounded-md">
                  <div>
                    <p className="font-medium">{exp.data_source_name} — {exp.field_name}</p>
                    <p className="text-sm text-gray-500">{exp.retention_period} · {exp.data_category}</p>
                  </div>
                  <Badge className={exp.days_remaining <= 7 ? "bg-red-100 text-red-800" : "bg-yellow-100 text-yellow-800"}>
                    {exp.days_remaining} days
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("retention.deletionLog")}</CardTitle>
        </CardHeader>
        <CardContent>
          {logs.length === 0 ? (
            <p className="text-gray-500">{t("retention.noLogs")}</p>
          ) : (
            <div className="space-y-3">
              {logs.map((log) => (
                <div key={log.log_id} className="border-l-2 border-green-300 pl-3">
                  <p className="text-sm font-medium">{log.deletion_method}</p>
                  <p className="text-xs text-gray-500">
                    {log.field_names.join(", ")} · {new Date(log.performed_at).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
