"""Privacy Notice Builder routes."""
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Account, DataElement, DataSource, PrivacyNotice, User
from app.schemas import (
    PrivacyNoticeCreateRequest,
    PrivacyNoticeResponse,
    PublicNoticeResponse,
    MessageResponse,
)
from app.utils.auth import get_current_active_user, require_admin, get_account_from_slug
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/privacy-notice", tags=["privacy-notice"])

# Predefined templates
TEMPLATES = {
    "ecommerce": {
        "name": "E-commerce / D2C",
        "sections": [
            {"title": "Introduction", "content": "", "order": 1},
            {"title": "Data We Collect", "content": "", "order": 2},
            {"title": "Purposes of Processing", "content": "", "order": 3},
            {"title": "Legal Basis", "content": "", "order": 4},
            {"title": "Third-Party Sharing", "content": "", "order": 5},
            {"title": "Data Retention", "content": "", "order": 6},
            {"title": "Your Rights Under DPDPA", "content": "", "order": 7},
            {"title": "Grievance Contact", "content": "", "order": 8},
            {"title": "Updates to This Notice", "content": "", "order": 9},
        ]
    },
    "service": {
        "name": "Service Business",
        "sections": [
            {"title": "Introduction", "content": "", "order": 1},
            {"title": "Client Data We Collect", "content": "", "order": 2},
            {"title": "Purposes of Processing", "content": "", "order": 3},
            {"title": "Communications", "content": "", "order": 4},
            {"title": "Billing & Payments", "content": "", "order": 5},
            {"title": "Data Retention", "content": "", "order": 6},
            {"title": "Your Rights Under DPDPA", "content": "", "order": 7},
            {"title": "Grievance Contact", "content": "", "order": 8},
            {"title": "Updates to This Notice", "content": "", "order": 9},
        ]
    },
    "generic": {
        "name": "Generic",
        "sections": [
            {"title": "Introduction", "content": "", "order": 1},
            {"title": "Data We Collect", "content": "", "order": 2},
            {"title": "Purposes of Processing", "content": "", "order": 3},
            {"title": "Legal Basis", "content": "", "order": 4},
            {"title": "Third-Party Sharing", "content": "", "order": 5},
            {"title": "Data Retention", "content": "", "order": 6},
            {"title": "Your Rights Under DPDPA", "content": "", "order": 7},
            {"title": "Grievance Contact", "content": "", "order": 8},
            {"title": "Updates to This Notice", "content": "", "order": 9},
        ]
    },
}


def _prefill_sections(template_type: str, account: Account, inventory_elements: list) -> list:
    """Pre-fill notice sections with account data and inventory."""
    template = TEMPLATES.get(template_type, TEMPLATES["generic"])
    sections = [s.copy() for s in template["sections"]]

    for section in sections:
        if section["title"] == "Introduction":
            section["content"] = (
                f"This Privacy Notice explains how {account.business_name} "
                f'(\"we\", "us", "our\") collects, uses, stores, and protects '
                f"your personal data in accordance with the Digital Personal Data "
                f"Protection Act, 2023 (DPDPA) of India.\n\n"
                f"By using our services, you consent to the practices described in this notice."
            )

        elif section["title"] in ("Data We Collect", "Client Data We Collect"):
            if inventory_elements:
                fields = ", ".join([e.field_name for e in inventory_elements[:10]])
                section["content"] = f"We collect the following categories of personal data: {fields}"
            else:
                section["content"] = "We collect personal data necessary to provide our services to you."

        elif section["title"] == "Grievance Contact":
            contact_parts = []
            if account.grievance_email:
                contact_parts.append(f"Email: {account.grievance_email}")
            if account.grievance_phone:
                contact_parts.append(f"Phone: {account.grievance_phone}")
            if account.grievance_address:
                contact_parts.append(f"Address: {account.grievance_address}")

            if contact_parts:
                section["content"] = (
                    "If you have any concerns about how we handle your personal data, "
                    f"please contact our Grievance Officer:\n\n" + "\n".join(contact_parts)
                )
            else:
                section["content"] = "Grievance contact information will be updated shortly."

        elif section["title"] == "Your Rights Under DPDPA":
            section["content"] = (
                "Under the DPDPA, you have the following rights:\n\n"
                "1. Right to Access: You can request a copy of your personal data we hold.\n"
                "2. Right to Correction: You can request correction of inaccurate or misleading data.\n"
                "3. Right to Erasure: You can request deletion of your personal data.\n"
                "4. Right to Grievance Redressal: You can file a complaint with our Grievance Officer.\n"
                "5. Right to Nominate: You can nominate another individual to exercise your rights.\n\n"
                "To exercise any of these rights, please contact us using the Grievance Contact information below."
            )

    return sections


@router.post("", response_model=PrivacyNoticeResponse, status_code=status.HTTP_201_CREATED)
async def create_notice(
    request: Request,
    data: PrivacyNoticeCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Create a new privacy notice from template."""
    # Get inventory elements for pre-fill
    result = await db.execute(
        select(DataElement)
        .join(DataSource)
        .where(
            DataSource.account_id == current_user.account_id,
            DataSource.status == "confirmed",
        )
    )
    elements = result.scalars().all()

    # Get account for business details
    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    account = result.scalar_one()

    # Pre-fill sections
    sections = _prefill_sections(data.template_type, account, elements)

    # If content provided, merge with pre-filled
    if data.content:
        provided_sections = data.content.get("sections", [])
        for ps in provided_sections:
            for s in sections:
                if s["title"] == ps.get("title"):
                    s["content"] = ps.get("content", s["content"])
                    break

    # Unpublish any existing published notice
    await db.execute(
        update(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == current_user.account_id,
            PrivacyNotice.is_published == True,
        )
        .values(is_published=False)
    )

    # Get next version number
    result = await db.execute(
        select(PrivacyNotice)
        .where(PrivacyNotice.account_id == current_user.account_id)
        .order_by(PrivacyNotice.version.desc())
    )
    latest = result.scalar_one_or_none()
    version = (latest.version + 1) if latest else 1

    notice = PrivacyNotice(
        account_id=current_user.account_id,
        template_type=data.template_type,
        content={"sections": sections, "language": data.language},
        is_published=False,
        version=version,
    )
    db.add(notice)
    await db.commit()
    await db.refresh(notice)

    logger.info(f"Privacy notice created: v{version} for account {current_user.account_id}")
    return notice


@router.get("/current", response_model=PrivacyNoticeResponse)
async def get_current_notice(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get the current published privacy notice."""
    result = await db.execute(
        select(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == current_user.account_id,
            PrivacyNotice.is_published == True,
        )
        .order_by(PrivacyNotice.version.desc())
    )
    notice = result.scalar_one_or_none()

    if not notice:
        raise HTTPException(status_code=404, detail="No published privacy notice found")

    return notice


@router.get("/versions", response_model=list[PrivacyNoticeResponse])
async def list_versions(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List all privacy notice versions."""
    result = await db.execute(
        select(PrivacyNotice)
        .where(PrivacyNotice.account_id == current_user.account_id)
        .order_by(PrivacyNotice.version.desc())
    )
    return result.scalars().all()


@router.post("/{notice_id}/publish", response_model=PrivacyNoticeResponse)
async def publish_notice(
    notice_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Publish a privacy notice."""
    # Unpublish current
    await db.execute(
        update(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == current_user.account_id,
            PrivacyNotice.is_published == True,
        )
        .values(is_published=False)
    )

    # Publish requested
    result = await db.execute(
        select(PrivacyNotice).where(
            PrivacyNotice.id == notice_id,
            PrivacyNotice.account_id == current_user.account_id,
        )
    )
    notice = result.scalar_one_or_none()
    if not notice:
        raise HTTPException(status_code=404, detail="Privacy notice not found")

    notice.is_published = True
    notice.published_at = datetime.now(timezone.utc)
    await db.commit()

    return notice


@router.post("/{notice_id}/unpublish", response_model=PrivacyNoticeResponse)
async def unpublish_notice(
    notice_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Unpublish a privacy notice."""
    result = await db.execute(
        select(PrivacyNotice).where(
            PrivacyNotice.id == notice_id,
            PrivacyNotice.account_id == current_user.account_id,
        )
    )
    notice = result.scalar_one_or_none()
    if not notice:
        raise HTTPException(status_code=404, detail="Privacy notice not found")

    notice.is_published = False
    notice.published_at = None
    await db.commit()

    return notice


# Public endpoints (no auth)
@router.get("/public/{business_slug}", response_model=PublicNoticeResponse)
async def public_notice(
    business_slug: str,
    db: AsyncSession = Depends(get_db),
):
    """Public privacy notice page for embedding."""
    account = await get_account_from_slug(business_slug, db)

    result = await db.execute(
        select(PrivacyNotice)
        .where(
            PrivacyNotice.account_id == account.id,
            PrivacyNotice.is_published == True,
        )
        .order_by(PrivacyNotice.version.desc())
    )
    notice = result.scalar_one_or_none()

    if not notice:
        raise HTTPException(status_code=404, detail="No published notice found")

    return PublicNoticeResponse(
        business_name=account.business_name,
        business_slug=account.business_slug,
        content=notice.content,
        published_at=notice.published_at,
        version=notice.version,
    )
