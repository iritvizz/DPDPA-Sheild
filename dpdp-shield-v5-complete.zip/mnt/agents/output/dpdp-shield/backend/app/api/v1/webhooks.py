"""Webhook handlers."""
import hmac
import hashlib
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.models import Account, AccountStatus, Subscription, SubscriptionStatus
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/webhooks", tags=["webhooks"])


def verify_razorpay_signature(payload: str, signature: str, secret: str) -> bool:
    """Verify Razorpay webhook signature."""
    expected = hmac.new(
        secret.encode(),
        payload.encode(),
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, signature)


@router.post("/razorpay")
async def razorpay_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Handle Razorpay webhook events."""
    settings = get_settings()

    # Get raw body for signature verification
    body = await request.body()
    body_str = body.decode()

    # Verify signature
    signature = request.headers.get("X-Razorpay-Signature", "")
    if not settings.RAZORPAY_WEBHOOK_SECRET:
        logger.warning("Razorpay webhook secret not configured, skipping verification")
    elif not verify_razorpay_signature(body_str, signature, settings.RAZORPAY_WEBHOOK_SECRET):
        logger.error("Razorpay webhook signature verification failed")
        raise HTTPException(status_code=400, detail="Invalid signature")

    # Parse payload
    import json
    try:
        payload = json.loads(body_str)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    event = payload.get("event")
    data = payload.get("payload", {}).get("subscription", {}).get("entity", {})

    razorpay_sub_id = data.get("id")
    razorpay_customer_id = data.get("customer_id")
    status_str = data.get("status")

    logger.info(f"Razorpay webhook received: {event}, sub_id={razorpay_sub_id}")

    # Find subscription by razorpay_subscription_id
    result = await db.execute(
        select(Subscription).where(Subscription.razorpay_subscription_id == razorpay_sub_id)
    )
    sub = result.scalar_one_or_none()

    if event == "subscription.activated":
        if sub:
            sub.status = SubscriptionStatus.ACTIVE
            sub.current_period_start = datetime.now(timezone.utc)
            sub.current_period_end = datetime.now(timezone.utc) + timedelta(days=30)

            # Update account status
            result = await db.execute(
                select(Account).where(Account.id == sub.account_id)
            )
            account = result.scalar_one()
            account.status = AccountStatus.ACTIVE

            await db.commit()
            logger.info(f"Subscription activated: {razorpay_sub_id}")

    elif event == "subscription.charged":
        if sub:
            sub.status = SubscriptionStatus.ACTIVE
            sub.current_period_start = datetime.now(timezone.utc)
            sub.current_period_end = datetime.now(timezone.utc) + timedelta(days=30)
            await db.commit()
            logger.info(f"Subscription charged: {razorpay_sub_id}")

    elif event in ("subscription.cancelled", "subscription.halted"):
        if sub:
            sub.status = SubscriptionStatus.CANCELLED
            await db.commit()

            # Update account to expired if past period end
            result = await db.execute(
                select(Account).where(Account.id == sub.account_id)
            )
            account = result.scalar_one()
            if sub.current_period_end and sub.current_period_end < datetime.now(timezone.utc):
                account.status = AccountStatus.EXPIRED
                await db.commit()

            logger.info(f"Subscription cancelled: {razorpay_sub_id}")

    elif event == "subscription.paused":
        if sub:
            # Handle paused subscription
            pass

    return {"status": "processed"}
