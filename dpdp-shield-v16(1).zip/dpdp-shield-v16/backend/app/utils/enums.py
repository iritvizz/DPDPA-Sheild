"""Safe enum value extraction utilities.

SQLAlchemy String columns annotated as Mapped[SomeEnum] return raw strings
on load, not Enum instances. This helper safely extracts the value regardless
of whether the input is an Enum instance or a plain string.
"""
from enum import Enum


def enum_value(field) -> str:
    """Safely extract the string value from an enum-like field.

    Works whether the field is:
    - A Python Enum instance (e.g. AccountStatus.TRIAL)
    - A plain string loaded from the database (e.g. "trial")
    - None (returns empty string)
    """
    if field is None:
        return ""
    if isinstance(field, Enum):
        return field.value
    return str(field)
