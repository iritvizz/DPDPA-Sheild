# DPDP Shield - Data Handling Audit

## 1. Inventory File Processing (Section 4.1)

### Verification
- Files processed entirely in memory via `io.BytesIO`
- Never written to disk or S3
- Explicit `del df` + `gc.collect()` after extraction
- Structured purge log for every upload

### Test: `tests/test_file_purge.py`
- Verifies no temp files remain after processing
- Verifies no S3 interaction during inventory processing
- Validates purge log structure

## 2. Classification (Section 4.2)

- Content-based with immediate discard
- Sample values never persisted
- Correct Aadhaar regex: `^[2-9]{1}[0-9]{3}\s?[0-9]{4}\s?[0-9]{4}$`

## 3. Consent Proof (Section 6.4)

### Safeguards
- Magic byte validation (not extension)
- Size limit: 10MB
- S3 AES-256 encryption
- Pre-signed URLs: 5-minute expiry
- Actual S3 delete (not flag)

### Known Gap
- Post-upload GuardDuty scan only
- Up to 5-minute exposure window in temp bucket
- 1-hour lifecycle policy mitigates risk

## 4. Database

| Table | Raw PII? |
|-------|----------|
| accounts | No |
| users | No (hashed passwords) |
| data_sources | No (metadata only) |
| data_elements | No |
| consent_records | No (S3 key only) |
| audit_logs | No (PII scrubbed) |

## 5. Security

- No hardcoded SECRET_KEY fallback
- bcrypt password hashing
- JWT: 15-min access, 7-day refresh
- Widget nonce: HMAC-derived, daily rotating

## 6. Widget Nonce Security (Known Design Limitation)

The consent widget uses a daily-rotating HMAC nonce for request integrity:
- Nonce = SHA256(business_slug + server_secret + date)[:32]
- Verified server-side before accepting consent events

**Known Limitation:** The nonce derivation secret is embedded in the 
`<script>` tag on the business's website. Anyone with `view-source` access
can extract it and compute valid nonces. This is an architectural constraint
of a client-side-only embed — the server cannot verify origin without
client-side state.

**Mitigations:**
- Nonce rotates daily (limits exposure window)
- `hmac.compare_digest` prevents timing attacks
- `Origin` header check can be added as best-effort defense
- For higher security, businesses can use server-side consent logging

**Status:** Accepted as MVP limitation. Phase 2 may implement
server-side widget configuration with per-domain registration.


## 7. Malware Scanning (MVP Implementation)

**Current Status:** Post-upload GuardDuty simulation

The consent proof upload flow:
1. File uploaded to temp S3 bucket
2. Celery task `scan_consent_proof` enqueued
3. Task waits briefly, then assumes clean and moves to permanent bucket
4. Status updated from "pending" to "clean"

**Known Gap:** No actual malware detection occurs. The task documents
this as a TODO for Phase 2 integration with:
- AWS GuardDuty Malware Protection API
- Lambda-triggered ClamAV scanning
- Or third-party scanning service

**Mitigations:**
- Content validation (magic bytes) rejects non-image/PDF files
- 10MB size limit
- Temp bucket has 1-hour auto-delete lifecycle
- Files are encrypted at rest (AES-256)

**Status:** Documented as known MVP gap. Production deployment
should implement real scanning before handling untrusted uploads.
