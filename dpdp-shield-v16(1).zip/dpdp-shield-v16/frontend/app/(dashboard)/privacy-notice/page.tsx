"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";

export default function PrivacyNoticePage() {
  const t = useTranslations();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t("privacyNotice.title")}</h2>

      <Card>
        <CardHeader>
          <CardTitle>{t("privacyNotice.builderTitle")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">{t("privacyNotice.noticeTitle")}</label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Privacy Notice v1.0"
            />
          </div>
          <div>
            <label className="text-sm font-medium">{t("privacyNotice.content")}</label>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={12}
              placeholder="Enter your privacy notice content here..."
            />
          </div>
          <div className="flex gap-2">
            <Button>{t("privacyNotice.saveDraft")}</Button>
            <Button variant="outline">{t("privacyNotice.preview")}</Button>
            <Button variant="secondary">{t("privacyNotice.publish")}</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
