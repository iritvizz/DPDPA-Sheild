"""Account cancellation-deletion flow tests."""
import secrets

import pytest
from fastapi import status
from httpx import AsyncClient

from app.models import Account, AccountStatus, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_cancel_deletion_during_cooling_off(async_client: AsyncClient, db_session):
    """An admin can cancel account deletion during the 48h cooling-off period."""
    account = Account(
        business_name="Cancel Test",
        business_slug="cancel-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
        status=AccountStatus.DELETED,
        deletion_task_id="fake-celery-task-id-12345",
    )
    db_session.add(account)
    await db_session.flush()

    admin = User(
        account_id=account.id,
        email="admin@cancel.test",
        password_hash="fakehash",
        role=UserRole.ADMIN,
    )
    db_session.add(admin)
    await db_session.commit()

    token = create_access_token({"sub": str(admin.public_id)})

    # Should succeed even though account status is "deleted"
    response = await async_client.post(
        "/api/v1/account/cancel-deletion",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == status.HTTP_200_OK
    assert "cancelled" in response.json()["message"].lower()

    # Verify account is back to active
    await db_session.refresh(account)
    assert account.status == AccountStatus.ACTIVE
    assert account.deleted_at is None
    assert account.deletion_task_id is None


@pytest.mark.asyncio
async def test_cancel_deletion_rejects_non_deleted_account(async_client: AsyncClient, db_session):
    """Cancel-deletion returns 400 if the account is not scheduled for deletion."""
    account = Account(
        business_name="Active Test",
        business_slug="active-test",
        sector="Services",
        widget_nonce_secret=secrets.token_urlsafe(32),
        status=AccountStatus.ACTIVE,
    )
    db_session.add(account)
    await db_session.flush()

    admin = User(
        account_id=account.id,
        email="admin@active.test",
        password_hash="fakehash",
        role=UserRole.ADMIN,
    )
    db_session.add(admin)
    await db_session.commit()

    token = create_access_token({"sub": str(admin.public_id)})

    response = await async_client.post(
        "/api/v1/account/cancel-deletion",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == status.HTTP_400_BAD_REQUEST
    assert "not scheduled for deletion" in response.json()["detail"]


@pytest.mark.asyncio
async def test_cancel_deletion_rejects_non_admin(async_client: AsyncClient, db_session):
    """Only admins can cancel deletion."""
    account = Account(
        business_name="Staff Test",
        business_slug="staff-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
        status=AccountStatus.DELETED,
    )
    db_session.add(account)
    await db_session.flush()

    staff = User(
        account_id=account.id,
        email="staff@test.com",
        password_hash="fakehash",
        role=UserRole.STAFF,
    )
    db_session.add(staff)
    await db_session.commit()

    token = create_access_token({"sub": str(staff.public_id)})

    response = await async_client.post(
        "/api/v1/account/cancel-deletion",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == status.HTTP_403_FORBIDDEN
