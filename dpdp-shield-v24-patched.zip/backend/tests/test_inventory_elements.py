"""Data Element PATCH/DELETE tests."""
import secrets

import pytest
from fastapi import status
from httpx import AsyncClient

from app.models import Account, DataElement, DataSource, DataSourceStatus, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_patch_element(async_client: AsyncClient, db_session):
    """PATCH updates a data element within a confirmed source."""
    account = Account(
        business_name="Element Test",
        business_slug="element-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="elem@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    source = DataSource(
        account_id=account.id,
        name="Customers",
        source_type="upload",
        status=DataSourceStatus.CONFIRMED,
    )
    db_session.add(source)
    await db_session.flush()

    element = DataElement(
        data_source_id=source.id,
        field_name="email",
        data_category="personal",
        purposes=["marketing"],
        retention_period_value=1,
        retention_period_unit="year",
        third_party_sharing=False,
    )
    db_session.add(element)
    await db_session.commit()
    await db_session.refresh(element)
    await db_session.refresh(source)

    token = create_access_token({"sub": str(user.public_id)})
    response = await async_client.patch(
        f"/api/v1/inventory/sources/{source.public_id}/elements/{element.id}",
        json={
            "field_name": "email_address",
            "data_category": "sensitive_personal",
            "purposes": ["order_fulfilment", "marketing"],
            "legal_basis": "consent",
            "retention_period_value": 3,
            "retention_period_unit": "years",
            "third_party_sharing": True,
            "third_party_details": "AWS SES",
        },
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["message"] == "Data element updated successfully"


@pytest.mark.asyncio
async def test_delete_element(async_client: AsyncClient, db_session):
    """DELETE removes a data element."""
    account = Account(
        business_name="Element Delete Test",
        business_slug="element-delete-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="elemdel@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    source = DataSource(
        account_id=account.id,
        name="Leads",
        source_type="manual",
        status=DataSourceStatus.CONFIRMED,
    )
    db_session.add(source)
    await db_session.flush()

    element = DataElement(
        data_source_id=source.id,
        field_name="phone",
        data_category="personal",
        purposes=["support"],
    )
    db_session.add(element)
    await db_session.commit()
    await db_session.refresh(element)
    await db_session.refresh(source)

    token = create_access_token({"sub": str(user.public_id)})
    response = await async_client.delete(
        f"/api/v1/inventory/sources/{source.public_id}/elements/{element.id}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["message"] == "Data element deleted successfully"

    # Verify it's gone
    response = await async_client.delete(
        f"/api/v1/inventory/sources/{source.public_id}/elements/{element.id}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_patch_element_rejects_other_account_source(async_client: AsyncClient, db_session):
    """PATCH on another account's source_id returns 404."""
    account_a = Account(
        business_name="Account A",
        business_slug="account-a-elem",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account_a)
    await db_session.flush()

    account_b = Account(
        business_name="Account B",
        business_slug="account-b-elem",
        sector="Services",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account_b)
    await db_session.flush()

    user_b = User(
        account_id=account_b.id,
        email="user-b-elem@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user_b)

    source_a = DataSource(
        account_id=account_a.id,
        name="A's Source",
        source_type="upload",
        status=DataSourceStatus.CONFIRMED,
    )
    db_session.add(source_a)
    await db_session.flush()

    element_a = DataElement(
        data_source_id=source_a.id,
        field_name="email",
        data_category="personal",
        purposes=["marketing"],
    )
    db_session.add(element_a)
    await db_session.commit()
    await db_session.refresh(source_a)

    token_b = create_access_token({"sub": str(user_b.public_id)})
    response = await async_client.patch(
        f"/api/v1/inventory/sources/{source_a.public_id}/elements/{element_a.id}",
        json={
            "field_name": "email",
            "data_category": "personal",
            "purposes": ["marketing"],
        },
        headers={"Authorization": f"Bearer {token_b}"},
    )
    assert response.status_code == 404
    assert "not found" in response.json()["detail"].lower()
