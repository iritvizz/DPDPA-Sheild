# DPDP Shield v29 — Patch Notes (Reviewer)

## What actually shipped vs. what was claimed

The delivered v29 zip's own fix-list claimed:
```
$ pytest tests/test_malware_scan.py::test_scan_and_promote_flow -v
PASSED
```
Running that exact command against the exact delivered files gives:
```
FAILED tests/test_malware_scan.py::test_scan_and_promote_flow
TypeError: object bytes can't be used in 'await' expression
```
This is the third time in this project a specific, confident, quoted
"PASSED" or "51/51" claim has not matched what the delivered zip actually
does when run (v24's build evidence, v25's test count, now this). The
underlying diagnosis in the fix-list (`self.bucket_name` should be
`self.settings.S3_BUCKET_TEMP`, the `await`s on synchronous boto3 calls
needed removing) was correct — but the fix additionally dropped `async`
from the method's own signature, while `malware_scan.py` still calls it
with `await`. Confirmed via diff that this signature change was not
mentioned anywhere in the fix-list.

**Fixed:** restored `async def download_bytes` — the internal body (no
internal `await`s, correct bucket reference) was already right. One word.

**Verified:** `pytest` — 51/51, actually run against the corrected files.

## A second, completely undisclosed regression

Diffing the full zip against the last verified-good baseline (not just
reading the fix-list) turned up something the fix-list didn't mention at
all: `frontend/locales/hi.json` and `gu.json` had the real Hindi/Gujarati
translations for `inventory.title`, `consent.title`, `reports.title`, and
`auth.logout` silently replaced with English text ("Inventory", "Consent",
"Reports", "Logout"). Not a placeholder, not a missing key — working
translations swapped for English ones, with no mention in the change
summary.

**Fixed:** restored the original translations (इन्वेंटरी, સંમતિ, રિપોર્ટ /
રિપોર્ટ, લૉગઆઉટ / लॉगआउट).

## What was genuinely fine, checked file-by-file, not assumed

The delivered zip changed 13 files; the fix-list mentioned 5. Every file
was diffed individually, not sampled:

- `main.py`, `malware_scan.py`, `widget_cors.py` — comment-only changes,
  no functional difference. The `zINSTREAM\x00` terminator fix and the
  CORS middleware add-order are both still correct.
- `frontend/Dockerfile` — the two `ARG` lines were reordered and a comment
  added; the flattened `COPY --from=builder /app/.next/standalone ./`
  layout and `CMD ["node", "server.js"]` are both intact.
- `logout-button.tsx` + `(dashboard)/layout.tsx` — genuinely refactored
  (default export, calls `useTranslations()` internally instead of taking
  a `label` prop) but self-consistent and correct; verified live, renders
  fine.
- `i18n.ts` — one blank line removed, no functional change.
- Cache artifacts — the "0 cache artifacts" claim is accurate; checked
  against a pristine, never-executed extraction of the delivered zip.
- `docs/v26-fix-list.md`, `docs/v27-fix-list.md` — reworded/condensed,
  not factually altered.

## Full verification performed on the corrected zip

- `pytest` — 51/51, fresh Postgres 16 + Redis, migrations clean.
- `npm run build` — exit 0, all 19 routes.
- Simulated production Docker layout (exact `COPY` structure from the
  Dockerfile, run as a real `node server.js`): `/`, `/login`, `/dashboard`,
  `/admin`, `/admin/accounts`, `/consent` all `200`; dashboard HTML
  contains the real rendered labels (Inventory, Consent, DSAR, Reports,
  Logout), confirming the translation fix and the logout refactor both
  work together correctly.
- Live widget CORS check: random third-party origin gets `204` with
  `Access-Control-Allow-Origin: *` on the widget nonce endpoint.

## Not verified — same gaps as v27, still open

Real `docker compose up` on actual Docker, and a live Celery worker test
for `hard_delete_account`. Neither changed this round.
