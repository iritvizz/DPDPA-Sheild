"""Data Subject Access Request (DSAR) routes -- DPDPA Section 12."""
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import DSARRequest, User
from app.schemas import DSARCreateRequest, DSARResponse, DSARUpdateRequest, MessageResponse
from app.utils.auth import get_current_active_user, require_admin
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/dsar", tags=["dsar"])


@router.post("", response_model=DSARResponse, status_code=status.HTTP_201_CREATED)
async def create_dsar(
    data: DSARCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Submit a new DSAR ticket. Any authenticated user in the account can file."""
    dsar = DSARRequest(
        account_id=current_user.account_id,
        principal_email=data.principal_email,
        principal_name=data.principal_name,
        principal_phone=data.principal_phone,
        request_type=data.request_type,
        description=data.description,
    )
    db.add(dsar)
    await db.commit()
    await db.refresh(dsar)

    logger.info(f"DSAR created: {dsar.public_id} for account {current_user.account_id}")
    return dsar


@router.get("", response_model=list[DSARResponse])
async def list_dsars(
    status_filter: str = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List DSAR tickets for the current account."""
    query = select(DSARRequest).where(DSARRequest.account_id == current_user.account_id)

    if status_filter:
        query = query.where(DSARRequest.status == status_filter)

    result = await db.execute(query.order_by(DSARRequest.created_at.desc()))
    return result.scalars().all()


@router.get("/{dsar_id}", response_model=DSARResponse)
async def get_dsar(
    dsar_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get a single DSAR ticket."""
    result = await db.execute(
        select(DSARRequest).where(
            DSARRequest.public_id == dsar_id,
            DSARRequest.account_id == current_user.account_id,
        )
    )
    dsar = result.scalar_one_or_none()
    if not dsar:
        raise HTTPException(status_code=404, detail="DSAR not found")
    return dsar


@router.patch("/{dsar_id}", response_model=DSARResponse)
async def update_dsar(
    dsar_id: uuid.UUID,
    data: DSARUpdateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Update DSAR status and response (admin only)."""
    result = await db.execute(
        select(DSARRequest).where(
            DSARRequest.public_id == dsar_id,
            DSARRequest.account_id == current_user.account_id,
        )
    )
    dsar = result.scalar_one_or_none()
    if not dsar:
        raise HTTPException(status_code=404, detail="DSAR not found")

    if data.status:
        dsar.status = data.status
    if data.response_text:
        dsar.response_text = data.response_text
        dsar.responded_at = datetime.now(timezone.utc)
        dsar.responded_by_id = current_user.id

    await db.commit()
    await db.refresh(dsar)

    logger.info(f"DSAR updated: {dsar.public_id} -> {dsar.status}")
    return dsar


@router.delete("/{dsar_id}", response_model=MessageResponse)
async def delete_dsar(
    dsar_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Delete a DSAR ticket (admin only)."""
    result = await db.execute(
        select(DSARRequest).where(
            DSARRequest.public_id == dsar_id,
            DSARRequest.account_id == current_user.account_id,
        )
    )
    dsar = result.scalar_one_or_none()
    if not dsar:
        raise HTTPException(status_code=404, detail="DSAR not found")

    await db.delete(dsar)
    await db.commit()

    return MessageResponse(message="DSAR deleted")
