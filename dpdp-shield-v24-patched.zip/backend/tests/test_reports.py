"""Reports and audit-pack endpoint tests.

These tests protect against the exact regressions found in v19:
1. requested_by_id vs requested_by field name
2. public_id presence on AuditPackGeneration
3. download_url computed from file_s3_key, not a phantom attribute
"""
import secrets
from datetime import datetime, timezone
from unittest.mock import patch

import pytest
from fastapi import status
from httpx import AsyncClient

from app.models import Account, AuditPackGeneration, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_audit_pack_generation_creates_record_with_public_id(async_client: AsyncClient, db_session):
    """POST starts generation and returns a real UUID generation_id."""
    account = Account(
        business_name="Report Test",
        business_slug="report-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="report@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    with patch("app.tasks.pdf.generate_audit_pack") as mock_task:
        mock_task.delay.return_value = None

        response = await async_client.post(
            "/api/v1/reports/audit-pack",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 202
        data = response.json()
        assert data["status"] == "queued"
        assert data["download_url"] is None
        # generation_id must be a valid UUID string
        gen_id = data["generation_id"]
        assert len(gen_id) == 36  # UUID string length

        # Verify the DB record actually exists with that public_id
        from sqlalchemy import select
        result = await db_session.execute(
            select(AuditPackGeneration).where(AuditPackGeneration.public_id == gen_id)
        )
        record = result.scalar_one_or_none()
        assert record is not None
        assert record.requested_by == user.id  # NOT requested_by_id


@pytest.mark.asyncio
async def test_audit_pack_status_returns_download_url_when_completed(async_client: AsyncClient, db_session):
    """GET returns computed pre-signed URL when status is completed and file_s3_key exists."""
    account = Account(
        business_name="Report Status Test",
        business_slug="report-status-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="reportstatus@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.flush()

    # Create a completed generation record
    gen = AuditPackGeneration(
        account_id=account.id,
        requested_by=user.id,
        status="completed",
        file_s3_key="audit-packs/test-account/audit-pack-2024-01-01.pdf",
        expires_at=datetime.now(timezone.utc),
    )
    db_session.add(gen)
    await db_session.commit()
    await db_session.refresh(gen)

    token = create_access_token({"sub": str(user.public_id)})

    with patch("app.services.s3_service.S3Service.generate_presigned_url") as mock_url:
        mock_url.return_value = "https://s3.ap-south-1.amazonaws.com/bucket/key?X-Amz-Signature=abc"

        response = await async_client.get(
            f"/api/v1/reports/audit-pack/{gen.public_id}",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["generation_id"] == str(gen.public_id)
        assert data["status"] == "completed"
        assert data["download_url"] is not None
        assert "X-Amz-Signature" in data["download_url"]
        mock_url.assert_called_once()


@pytest.mark.asyncio
async def test_audit_pack_status_returns_none_when_pending(async_client: AsyncClient, db_session):
    """GET returns download_url=None when status is queued."""
    account = Account(
        business_name="Report Pending Test",
        business_slug="report-pending-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="reportpending@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.flush()

    gen = AuditPackGeneration(
        account_id=account.id,
        requested_by=user.id,
        status="queued",
    )
    db_session.add(gen)
    await db_session.commit()
    await db_session.refresh(gen)

    token = create_access_token({"sub": str(user.public_id)})

    response = await async_client.get(
        f"/api/v1/reports/audit-pack/{gen.public_id}",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "queued"
    assert data["download_url"] is None


@pytest.mark.asyncio
async def test_audit_pack_rejects_other_account(async_client: AsyncClient, db_session):
    """GET returns 404 for a generation_id belonging to another account."""
    account_a = Account(
        business_name="Account A",
        business_slug="account-a-report",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account_a)
    await db_session.flush()

    account_b = Account(
        business_name="Account B",
        business_slug="account-b-report",
        sector="Services",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account_b)
    await db_session.flush()

    user_b = User(
        account_id=account_b.id,
        email="user-b-report@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user_b)
    await db_session.flush()

    gen_a = AuditPackGeneration(
        account_id=account_a.id,
        requested_by=user_b.id,  # wrong user but right account for creation
        status="queued",
    )
    db_session.add(gen_a)
    await db_session.commit()
    await db_session.refresh(gen_a)

    token_b = create_access_token({"sub": str(user_b.public_id)})

    response = await async_client.get(
        f"/api/v1/reports/audit-pack/{gen_a.public_id}",
        headers={"Authorization": f"Bearer {token_b}"},
    )
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_monthly_summary_returns_counts(async_client: AsyncClient, db_session):
    """Monthly summary returns real counts (may be zero for fresh account)."""
    account = Account(
        business_name="Summary Test",
        business_slug="summary-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="sum@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    response = await async_client.get(
        "/api/v1/reports/monthly-summary",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "month" in data
    assert "consent_records_created" in data
    assert "dsar_requests_received" in data
    assert "data_sources_uploaded" in data
    assert "privacy_notices_published" in data
