"""Consent management routes."""
import uuid as uuid_mod
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.models import ConsentMethod, ConsentRecord, User
from app.schemas import (
    ConsentRecordCreateRequest,
    ConsentRecordResponse,
    MessageResponse,
    WidgetCaptureRequest,
    WithdrawalResponse,
)
from app.services.s3_service import S3Service
from app.tasks.malware_scan import scan_consent_proof
from app.utils.auth import (
    get_account_from_slug,
    get_current_active_user,
    require_admin,
    verify_widget_nonce,
)
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/consent", tags=["consent"])


@router.get("/records", response_model=list[ConsentRecordResponse])
async def list_consent(
    customer_reference: str = None,
    purpose: str = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List consent records with optional filtering."""
    query = select(ConsentRecord).where(
        ConsentRecord.account_id == current_user.account_id
    )

    if customer_reference:
        query = query.where(ConsentRecord.customer_reference.ilike(f"%{customer_reference}%"))
    if purpose:
        query = query.where(ConsentRecord.purpose == purpose)

    result = await db.execute(query.order_by(ConsentRecord.created_at.desc()))
    return result.scalars().all()


@router.post("/records", response_model=ConsentRecordResponse, status_code=status.HTTP_201_CREATED)
async def create_consent(
    data: ConsentRecordCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Manually log a consent record."""
    record = ConsentRecord(
        account_id=current_user.account_id,
        customer_reference=data.customer_reference,
        purpose=data.purpose,
        consent_timestamp=data.consent_timestamp or datetime.now(timezone.utc),
        method=data.method,
        proof_text=data.proof_text,
        consent_expiry=data.consent_expiry,
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)

    return record


@router.post("/records/{record_id}/proof-file", response_model=ConsentRecordResponse)
async def upload_proof(
    record_id: uuid_mod.UUID,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Upload consent proof file with content validation."""
    settings = get_settings()

    # Get record
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.public_id == record_id,
            ConsentRecord.account_id == current_user.account_id,
        )
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Consent record not found")

    # Read file content
    content = await file.read()

    # Validate and upload
    s3 = S3Service()
    try:
        temp_key, file_id = await s3.upload_consent_proof(
            content, file.filename, current_user.account_id
        )

        record.proof_file_s3_key = temp_key
        record.proof_file_status = "pending"
        await db.commit()

        # Enqueue malware scan task
        scan_consent_proof.delay(temp_key, record.id, current_user.account_id)

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return record


@router.delete("/records/{record_id}/proof-file", response_model=MessageResponse)
async def delete_proof(
    record_id: uuid_mod.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Delete consent proof file from S3."""
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.public_id == record_id,
            ConsentRecord.account_id == current_user.account_id,
        )
    )
    record = result.scalar_one_or_none()
    if not record or not record.proof_file_s3_key:
        raise HTTPException(status_code=404, detail="Proof file not found")

    s3 = S3Service()
    s3.delete_file(record.proof_file_s3_key)

    record.proof_file_s3_key = None
    record.proof_file_status = "none"
    await db.commit()

    return MessageResponse(message="Proof file deleted")


@router.post("/records/{record_id}/revoke", response_model=ConsentRecordResponse)
async def revoke_consent(
    record_id: uuid_mod.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Revoke a consent record."""
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.public_id == record_id,
            ConsentRecord.account_id == current_user.account_id,
        )
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Consent record not found")

    record.is_revoked = True
    record.revoked_at = datetime.now(timezone.utc)
    await db.commit()

    return record




@router.get("/records/{record_id}", response_model=ConsentRecordResponse)
async def get_consent_record(
    record_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get a single consent record with a pre-signed proof-file URL."""
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.public_id == record_id,
            ConsentRecord.account_id == current_user.account_id,
        )
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Consent record not found")

    # Generate pre-signed URL for proof file if present (5-minute expiry)
    proof_url = None
    if record.proof_file_s3_key:
        from app.services.s3_service import S3Service
        s3 = S3Service()
        proof_url = s3.generate_presigned_url(record.proof_file_s3_key, expiration=300)

    return ConsentRecordResponse(
        public_id=record.public_id,
        customer_reference=record.customer_reference,
        purpose=record.purpose,
        method=record.method,
        is_revoked=record.is_revoked,
        revoked_at=record.revoked_at,
        proof_file_url=proof_url,
        created_at=record.created_at,
    )


@router.post("/records/{record_id}/withdrawal-link", response_model=MessageResponse)
async def generate_withdrawal_link(
    record_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Generate a secure withdrawal token for a consent record and optionally
    send it via email/SMS."""
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.public_id == record_id,
            ConsentRecord.account_id == current_user.account_id,
        )
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Consent record not found")

    if record.is_revoked:
        raise HTTPException(status_code=400, detail="Consent already withdrawn")

    import secrets
    record.withdrawal_token = secrets.token_urlsafe(32)
    await db.commit()

    # Build the public withdrawal URL
    from app.config import get_settings
    settings = get_settings()
    base_url = settings.APP_URL or "http://localhost:3000"
    withdrawal_url = f"{base_url}/public/withdrawal/{record.withdrawal_token}"

    # TODO: Send via email/SMS when those integrations are wired
    # For now, return the URL in the response message
    return MessageResponse(
        message=f"Withdrawal link generated: {withdrawal_url}"
    )


@router.get("/export")
async def export_consent_records(
    format: str = "csv",
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Export consent records as CSV or PDF."""
    from sqlalchemy import select
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.account_id == current_user.account_id,
        ).order_by(ConsentRecord.created_at.desc())
    )
    records = result.scalars().all()

    if format.lower() == "csv":
        import csv
        import io
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            "public_id", "customer_reference", "purpose", "method",
            "is_revoked", "revoked_at", "created_at",
        ])
        for r in records:
            writer.writerow([
                str(r.public_id),
                r.customer_reference,
                r.purpose,
                r.method,
                r.is_revoked,
                r.revoked_at.isoformat() if r.revoked_at else "",
                r.created_at.isoformat() if r.created_at else "",
            ])
        output.seek(0)
        from fastapi.responses import StreamingResponse
        return StreamingResponse(
            io.BytesIO(output.getvalue().encode()),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=consent_records.csv"},
        )

    elif format.lower() == "pdf":
        # TODO: implement PDF export via WeasyPrint
        raise HTTPException(status_code=501, detail="PDF export not yet implemented")

    else:
        raise HTTPException(status_code=400, detail="Format must be 'csv' or 'pdf'")

@router.post("/widget/capture", status_code=status.HTTP_201_CREATED)
async def widget_capture(
    request: Request,
    data: WidgetCaptureRequest,
    db: AsyncSession = Depends(get_db),
):
    """Public endpoint for consent widget - CORS enabled, no auth required."""
    # Get account by slug
    account = await get_account_from_slug(data.business_slug, db)

    # Verify nonce
    if not verify_widget_nonce(data.business_slug, data.nonce, account.widget_nonce_secret):
        raise HTTPException(status_code=403, detail="Invalid widget nonce")

    # Create consent record
    record = ConsentRecord(
        account_id=account.id,
        customer_reference=data.customer_reference,
        purpose=data.purpose,
        consent_timestamp=data.consent_timestamp or datetime.now(timezone.utc),
        method=ConsentMethod.WEBSITE_CHECKBOX,
        ip_address=request.client.host if request.client else None,
    )
    db.add(record)
    await db.commit()

    logger.info(f"Widget consent captured for account {account.id}")

    return {"status": "success", "message": "Consent recorded"}


@router.get("/public/withdrawal/{token}", response_model=WithdrawalResponse)
async def verify_withdrawal(token: str, db: AsyncSession = Depends(get_db)):
    """Public withdrawal confirmation page."""
    result = await db.execute(
        select(ConsentRecord).where(ConsentRecord.withdrawal_token == token)
    )
    record = result.scalar_one_or_none()

    if not record or not record.is_revoked:
        raise HTTPException(status_code=404, detail="Withdrawal token not found")

    return WithdrawalResponse(
        customer_reference=record.customer_reference,
        purpose=record.purpose,
        withdrawn_at=record.revoked_at,
        message=f"Consent for {record.purpose} was withdrawn on {record.revoked_at.strftime('%B %d, %Y')}.",
    )
