"""Account management tasks."""
from app.tasks import celery_app
from app.utils.logging import get_logger

logger = get_logger(__name__)


@celery_app.task
def hard_delete_account(account_id: int):
    """Permanently delete an account and all associated data after cooling-off period.

    This task is scheduled 48 hours after account deletion is requested.
    It performs a cascading hard delete of:
    - Account record
    - All users
    - All data sources and elements
    - All privacy notices
    - All consent records
    - All audit logs
    - All subscriptions
    - All S3 files (consent proofs, audit packs)
    """
    from app.database import AsyncSessionLocal
    from sqlalchemy import select, delete
    from app.models import Account
    from app.services.s3_service import S3Service

    async def _delete():
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(Account).where(Account.id == account_id)
            )
            account = result.scalar_one_or_none()

            if not account:
                logger.warning(f"Account {account_id} already deleted or not found")
                return {"status": "skipped", "reason": "account_not_found"}

            # Check if deletion was cancelled (status changed back)
            if account.status.value != "deleted":
                logger.info(f"Account {account_id} deletion cancelled")
                return {"status": "cancelled"}

            # Check if cooling-off period has passed
            from datetime import datetime, timezone
            if account.deleted_at and account.deleted_at > datetime.now(timezone.utc):
                logger.warning(f"Account {account_id} cooling-off period not yet expired")
                return {"status": "skipped", "reason": "cooling_off_active"}

            # Delete S3 objects first
            try:
                s3 = S3Service()
                # List and delete consent proofs
                import boto3
                from botocore.config import Config as BotoConfig
                from app.config import get_settings
                settings = get_settings()

                s3_client = boto3.client(
                    "s3",
                    region_name=settings.AWS_REGION,
                    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                    config=BotoConfig(signature_version="s3v4"),
                )

                # Delete consent proofs for this account
                prefix = f"consent-proofs/{account_id}/"
                response = s3_client.list_objects_v2(
                    Bucket=settings.S3_BUCKET_CONSENT_PROOFS,
                    Prefix=prefix,
                )
                for obj in response.get("Contents", []):
                    s3_client.delete_object(
                        Bucket=settings.S3_BUCKET_CONSENT_PROOFS,
                        Key=obj["Key"],
                    )
                    logger.info(f"Deleted S3 object: {obj['Key']}")

                # Delete audit packs
                prefix = f"audit-packs/{account_id}/"
                response = s3_client.list_objects_v2(
                    Bucket=settings.S3_BUCKET_CONSENT_PROOFS,
                    Prefix=prefix,
                )
                for obj in response.get("Contents", []):
                    s3_client.delete_object(
                        Bucket=settings.S3_BUCKET_CONSENT_PROOFS,
                        Key=obj["Key"],
                    )

            except Exception as e:
                logger.error(f"Failed to delete S3 objects for account {account_id}: {e}")
                # Continue with database deletion even if S3 fails

            # Hard delete from database (cascade handles related records)
            await db.delete(account)
            await db.commit()

            logger.info(f"Account {account_id} permanently deleted")
            return {"status": "deleted", "account_id": account_id}

    import asyncio
    return asyncio.run(_delete())
