"""Google Drive integration service."""
import json
from datetime import datetime, timezone

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from app.config import get_settings
from app.utils.logging import get_logger

logger = get_logger(__name__)

SCOPES = ["https://www.googleapis.com/auth/drive.readonly"]


class GoogleDriveService:
    """Handle Google Drive OAuth, file listing, and in-memory extraction."""

    @staticmethod
    def get_auth_url(account_id: int) -> str:
        """Generate the OAuth authorization URL for a given account."""
        settings = get_settings()
        flow = Flow.from_client_config(
            {
                "web": {
                    "client_id": settings.GOOGLE_CLIENT_ID,
                    "client_secret": settings.GOOGLE_CLIENT_SECRET,
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": "https://oauth2.googleapis.com/token",
                    "redirect_uris": [settings.GOOGLE_REDIRECT_URI],
                }
            },
            scopes=SCOPES,
            redirect_uri=settings.GOOGLE_REDIRECT_URI,
        )
        auth_url, _ = flow.authorization_url(
            prompt="consent", access_type="offline", state=str(account_id)
        )
        return auth_url

    @staticmethod
    def exchange_code(code: str, account_id: int) -> dict:
        """Exchange an OAuth authorization code for tokens."""
        settings = get_settings()
        flow = Flow.from_client_config(
            {
                "web": {
                    "client_id": settings.GOOGLE_CLIENT_ID,
                    "client_secret": settings.GOOGLE_CLIENT_SECRET,
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": "https://oauth2.googleapis.com/token",
                    "redirect_uris": [settings.GOOGLE_REDIRECT_URI],
                }
            },
            scopes=SCOPES,
            redirect_uri=settings.GOOGLE_REDIRECT_URI,
            state=str(account_id),
        )
        flow.fetch_token(code=code)
        creds = flow.credentials
        return {
            "token": creds.token,
            "refresh_token": creds.refresh_token,
            "token_uri": creds.token_uri,
            "client_id": creds.client_id,
            "client_secret": creds.client_secret,
            "scopes": creds.scopes,
            "expiry": creds.expiry.isoformat() if creds.expiry else None,
        }

    @staticmethod
    def build_service(token_json: str):
        """Build a Drive API service from stored token JSON."""
        info = json.loads(token_json)
        creds = Credentials.from_authorized_user_info(info, SCOPES)
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
        return build("drive", "v3", credentials=creds, cache_discovery=False)

    @staticmethod
    def list_files(token_json: str, page_size: int = 50) -> list[dict]:
        """List spreadsheet/CSV files from the user's Drive."""
        service = GoogleDriveService.build_service(token_json)
        query = "mimeType='application/vnd.google-apps.spreadsheet' or mimeType='text/csv'"
        results = (
            service.files()
            .list(q=query, pageSize=page_size, fields="files(id,name,mimeType,modifiedTime)")
            .execute()
        )
        return results.get("files", [])

    @staticmethod
    def download_file(token_json: str, file_id: str) -> bytes:
        """Download a file's content as bytes."""
        service = GoogleDriveService.build_service(token_json)
        file_meta = service.files().get(fileId=file_id, fields="mimeType,name").execute()
        mime = file_meta.get("mimeType", "")

        if mime == "application/vnd.google-apps.spreadsheet":
            # Export Google Sheet to CSV
            request = service.files().export_media(fileId=file_id, mimeType="text/csv")
        else:
            request = service.files().get_media(fileId=file_id)

        from googleapiclient.http import MediaIoBaseDownload
        import io
        fh = io.BytesIO()
        downloader = MediaIoBaseDownload(fh, request)
        done = False
        while not done:
            status, done = downloader.next_chunk()
        return fh.getvalue()
