# DPDP Shield v12 — Verified Fixes & Remaining Work

Continuing from v11.

---

## Confirmed fixed and verified in this pass

1. **Backend boots from clean install.** `PyJWT==2.13.0` added to `requirements.txt`; unused `python-jose[cryptography]` removed. Confirmed: `pip install -r requirements.txt` in a fresh venv, then `python -c "from app.main import app"` succeeds without `ModuleNotFoundError: No module named 'jwt'`.
2. **docker-compose.yml DATABASE_URL fixed.** Both `backend` and `celery-worker` services now use `postgresql+asyncpg://` dialect. Confirmed: the async engine no longer tries to load the missing `psycopg2` sync driver.
3. **docker-compose.yml S3 env vars aligned.** Renamed `S3_CONSENT_BUCKET`/`S3_TEMP_BUCKET` to `S3_BUCKET_CONSENT_PROOFS`/`S3_BUCKET_TEMP`, matching the exact names `config.py` reads via Pydantic Settings. No more silently ignored compose values.
4. **Razorpay webhook secret required in production.** `config.py` now raises `ValueError` if `RAZORPAY_WEBHOOK_SECRET` is unset in `ENVIRONMENT=production`, alongside the existing `RAZORPAY_KEY_SECRET` check. The webhook endpoint still warns-and-skips in non-production for local development convenience.
5. **Malware-scan test actually tests the test database.** `scan_consent_proof` now accepts an optional `session_factory` parameter (defaults to `AsyncSessionLocal` in production). The test passes `TestingSessionLocal` from `conftest.py`, so the task looks for the `ConsentRecord` in the same test database the fixture created it in. Confirmed: passes on a genuinely fresh Postgres instance where the dev database has no tables at all.
6. **Duplicate staff-invite/list/remove endpoints removed from `account.py`.** The canonical endpoints live under `/api/v1/users/*` (the only path with `accept-invite`). Removed the three duplicates from `/api/v1/account/users/*` that had drifted to different response shapes.
7. **Accept-invite password no longer in query string.** `POST /api/v1/users/accept-invite` now takes a JSON body (`AcceptInviteRequest`) instead of scalar args that FastAPI bound to query parameters. Passwords no longer appear in access logs or browser history.
8. **Internal-ID exposure sweep.** Removed `id: int` from `UserInvitationResponse` and `SubscriptionResponse` schemas. Neither ID is accepted back from clients, so exposing sequential integers was unnecessary information disclosure.
9. **Dead Celery task files deleted.** `app/tasks/pdf_tasks.py` and `app/tasks/email_tasks.py` were not imported anywhere and not in the Celery `include=[...]` list. Removed to prevent future developers editing the wrong file.
10. **Redis rate-limit isolation between test sessions.** `conftest.py` now has a session-scoped autouse fixture that attempts to use Redis DB index 15 for tests (falls back to flushing `ratelimit:*` keys on the default DB). Confirmed: running the full suite twice in quick succession no longer produces spurious 429 failures on the second run.
11. **Backend Dockerfile: `libmagic1` added.** `python-magic` requires the shared `libmagic` library at runtime. The slim Python base image does not include it by default. Added to the apt-get install list.
12. **Frontend `next.config.js` rewrite fallback.** `NEXT_PUBLIC_API_URL` now falls back to `http://localhost:8000` if unset, preventing the `"undefined/api/:path*"` invalid-rewrite error that blocked `npm run build`.
13. **Frontend Dockerfile is now a production multi-stage build.** Build stage (`npm ci` → `npm run build`) plus a production runner stage with non-root user. Replaces the dev-only `npm run dev` Dockerfile.
14. **Next.js bumped to 14.2.35.** Addresses disclosed vulnerabilities including a critical cache-poisoning issue in 14.2.5.

---

## Still open / carried forward

- **Real docker build verification.** The Dockerfile and compose fixes are correct by inspection against the base images, but nobody has run an actual `docker-compose up --build` end-to-end yet.
- **Real Razorpay sandbox verification.** The notes-based account linking in webhooks is architecturally sound but not exercised against Razorpay's real API.
- **Frontend pages.** Only auth layout, i18n scaffolding, and shared UI components exist. Dashboard, Inventory, Consent, Privacy Notice, RoPA, Account, Subscription, DSAR, and Admin panels are all unbuilt.
- **Alembic migrations.** The `dsar_requests` table (added in v10) and any schema changes since v7 still need a production migration. Tests use `Base.metadata.create_all` so they don't need one.
- **Rate limiting under genuine multi-worker concurrency.** The middleware works for single-instance and Redis-backed cases but hasn't been load-tested against the 500-concurrent-user NFR.
- **Python dependency vulnerability scan.** `npm audit` was run; an equivalent `pip-audit` pass on the Python side hasn't been done.
