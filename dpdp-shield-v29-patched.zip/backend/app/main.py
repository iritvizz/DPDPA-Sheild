"""Main FastAPI application entry point."""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.database import engine
from app.models import Base
from app.utils.rate_limiter import RateLimitMiddleware
from app.utils.widget_cors import WidgetCORSMiddleware


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    # Startup
    settings = get_settings()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Seed DSAR response templates if table is empty
    from app.database import AsyncSessionLocal
    from app.models import DSARTemplate
    from app.seed_data.dsar_templates import DSAR_TEMPLATES
    from sqlalchemy import select
    async with AsyncSessionLocal() as seed_db:
        result = await seed_db.execute(select(DSARTemplate))
        if not result.scalars().first():
            for tmpl in DSAR_TEMPLATES:
                seed_db.add(DSARTemplate(**tmpl))
            await seed_db.commit()
            print("[startup] DSAR templates seeded.")
    yield
    # Shutdown
    await engine.dispose()


def _parse_cors_origins(origins_str: str) -> list[str]:
    """Parse comma-separated CORS origins from env string."""
    if not origins_str:
        return ["http://localhost:3000"]
    return [o.strip() for o in origins_str.split(",") if o.strip()]


def create_app() -> FastAPI:
    """Application factory."""
    settings = get_settings()
    app = FastAPI(
        title="DPDP Shield API",
        description="DPDPA compliance tool for Indian SMEs",
        version="1.0.0",
        lifespan=lifespan,
    )

    # CORS - driven by environment (comma-separated list of origins)
    # In production, set CORS_ORIGINS to the real frontend domain(s).
    # Widget endpoints (/consent/widget/*) are handled by WidgetCORSMiddleware
    # above and allow any origin since they are public, nonce-secured, and
    # do not use credentials.
    origins = _parse_cors_origins(settings.CORS_ORIGINS)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Widget CORS — registered AFTER the strict global CORS middleware.
    # Middleware stacks outermost-first; WidgetCORSMiddleware wraps the
    # outermost layer, intercepts /consent/widget/*, and passes everything
    # else through. The global CORS middleware handles all other routes.
    app.add_middleware(WidgetCORSMiddleware)

    # Rate limiting
    app.add_middleware(RateLimitMiddleware)

    # Import and register routers
    from app.api.v1 import admin, auth, account, audit_log, consent, dashboard, dsar, google_drive, inventory, privacy_notice, reports, retention, ropa, subscription, users, webhooks

    app.include_router(auth.router, prefix="/api/v1")
    app.include_router(account.router, prefix="/api/v1")
    app.include_router(inventory.router, prefix="/api/v1")
    app.include_router(privacy_notice.router, prefix="/api/v1")
    app.include_router(consent.router, prefix="/api/v1")
    app.include_router(dashboard.router, prefix="/api/v1")
    app.include_router(reports.router, prefix="/api/v1")
    app.include_router(google_drive.router, prefix="/api/v1")
    app.include_router(retention.router, prefix="/api/v1")
    app.include_router(ropa.router, prefix="/api/v1")
    app.include_router(subscription.router, prefix="/api/v1")
    app.include_router(users.router, prefix="/api/v1")
    app.include_router(webhooks.router, prefix="/api/v1")
    app.include_router(dsar.router, prefix="/api/v1")
    app.include_router(audit_log.router, prefix="/api/v1")
    app.include_router(admin.router, prefix="/api/v1")

    @app.get("/health")
    async def health_check():
        return {"status": "healthy"}

    return app


app = create_app()
