"""Authentication and security utilities."""
import hashlib
import hmac
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.config import get_settings
from app.database import get_db
from app.models import Account, User, UserRole
from app.utils.enums import enum_value
from app.utils.logging import get_logger

logger = get_logger(__name__)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer(auto_error=False)

ALGORITHM = "HS256"


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash."""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Hash a password."""
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token."""
    settings = get_settings()
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire, "type": "access"})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def create_refresh_token(data: dict) -> str:
    """Create a JWT refresh token."""
    settings = get_settings()
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    to_encode.update({"exp": expire, "type": "refresh"})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def generate_password_reset_token(user_id: str) -> str:
    """Create a short-lived JWT for password reset."""
    settings = get_settings()
    expire = datetime.now(timezone.utc) + timedelta(minutes=30)
    to_encode = {"sub": user_id, "exp": expire, "type": "password_reset"}
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def decode_token(token: str) -> dict:
    """Decode and validate a JWT token."""
    settings = get_settings()
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Get the current authenticated user from JWT token.

    Eager-loads the account relationship to avoid MissingGreenlet errors
    when downstream code accesses current_user.account.
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = decode_token(credentials.credentials)

    if payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token type",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        user_uuid = uuid.UUID(user_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid user identifier",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # EAGER-LOAD account relationship — fixes MissingGreenlet crash
    result = await db.execute(
        select(User)
        .options(selectinload(User.account))
        .where(User.public_id == user_uuid)
    )
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return user


async def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    """Ensure the user is active (not suspended/deleted)."""
    # Use enum_value() to safely handle both Enum instances and raw strings
    account_status = enum_value(current_user.account.status)
    if account_status in ("suspended", "deleted"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is not active",
        )
    return current_user


async def require_admin(
    current_user: User = Depends(get_current_active_user),
) -> User:
    """Require admin or superadmin role."""
    if enum_value(current_user.role) not in ("admin", "superadmin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return current_user


async def require_superadmin(
    current_user: User = Depends(get_current_active_user),
) -> User:
    """Require superadmin role."""
    if enum_value(current_user.role) != "superadmin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Superadmin access required",
        )
    return current_user


async def require_admin_any_status(
    current_user: User = Depends(get_current_user),
) -> User:
    """Require admin or superadmin role, but allow any account status.

    Used for endpoints that must work even when the account is not
    "active" — e.g. cancelling a deletion during the cooling-off period,
    when status is "deleted" but the user still needs authenticated access.
    """
    if enum_value(current_user.role) not in ("admin", "superadmin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return current_user


async def get_account_from_slug(
    business_slug: str,
    db: AsyncSession = Depends(get_db),
) -> Account:
    """Get account by business slug for public endpoints."""
    result = await db.execute(
        select(Account).where(Account.business_slug == business_slug.lower().strip())
    )
    account = result.scalar_one_or_none()

    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Business not found",
        )

    return account


def generate_widget_nonce(business_slug: str, secret: str) -> str:
    """Generate a nonce for the consent widget.

    The nonce is derived from the business slug + server secret,
    making it verifiable but not guessable.
    """
    message = f"{business_slug}:{secret}:{datetime.now(timezone.utc).strftime('%Y%m%d')}"
    return hashlib.sha256(message.encode()).hexdigest()[:32]


def verify_widget_nonce(business_slug: str, nonce: str, secret: str) -> bool:
    """Verify a widget nonce."""
    # Check today and yesterday (for timezone edge cases)
    for day_offset in [0, -1]:
        check_date = datetime.now(timezone.utc) + timedelta(days=day_offset)
        expected = hashlib.sha256(
            f"{business_slug}:{secret}:{check_date.strftime('%Y%m%d')}".encode()
        ).hexdigest()[:32]
        if hmac.compare_digest(nonce, expected):
            return True
    return False


def generate_invitation_token() -> str:
    """Generate a secure invitation token."""
    return secrets.token_urlsafe(48)
