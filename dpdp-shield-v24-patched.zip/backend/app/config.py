"""Application configuration."""
import os
from functools import lru_cache
from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings with validation."""

    # Google Drive OAuth (added by reviewer - referenced in google_drive_service.py
    # and google_drive.py but never declared here, so the feature crashed on its
    # very first call with AttributeError regardless of whether these were set.)
    GOOGLE_CLIENT_ID: Optional[str] = None
    GOOGLE_CLIENT_SECRET: Optional[str] = None
    GOOGLE_REDIRECT_URI: Optional[str] = None

    # Security - NO FALLBACK. App refuses to start without these.
    SECRET_KEY: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@db:5432/dpdp_shield"

    # Redis
    REDIS_URL: str = "redis://redis:6379/0"

    # AWS
    AWS_REGION: str = "ap-south-1"
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    S3_BUCKET_CONSENT_PROOFS: str = "dpdp-shield-consent-proofs"
    S3_BUCKET_TEMP: str = "dpdp-shield-temp"

    # Razorpay
    RAZORPAY_KEY_ID: Optional[str] = None
    RAZORPAY_KEY_SECRET: Optional[str] = None
    RAZORPAY_WEBHOOK_SECRET: Optional[str] = None

    # Email (AWS SES)
    SES_FROM_EMAIL: str = "noreply@dpdp-shield.in"

    # SMS
    SMS_PROVIDER: str = "twilio"
    TWILIO_ACCOUNT_SID: Optional[str] = None
    TWILIO_AUTH_TOKEN: Optional[str] = None
    TWILIO_PHONE_NUMBER: Optional[str] = None

    # Application
    ENVIRONMENT: str = "development"
    FRONTEND_URL: str = "http://localhost:3000"
    API_URL: str = "http://localhost:8000"

    # File Processing
    MAX_UPLOAD_SIZE_MB: int = 25
    MAX_CONSENT_PROOF_SIZE_MB: int = 10
    FILE_PURGE_TIMEOUT_SECONDS: int = 60

    # Rate Limiting
    RATE_LIMIT_LOGIN_PER_MINUTE: int = 5
    RATE_LIMIT_API_PER_MINUTE: int = 100
    RATE_LIMIT_WIDGET_PER_MINUTE: int = 30  # public consent widget: real customers can share an IP (office/campus wifi), don't share the strict login bucket

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance.

    Raises:
        ValueError: If SECRET_KEY is not set or is the placeholder value.
    """
    settings = Settings()

    # Validate critical security settings
    placeholder = "your-secret-key-change-in-production"
    if not settings.SECRET_KEY or settings.SECRET_KEY == placeholder:
        raise ValueError(
            "CRITICAL: SECRET_KEY must be set to a secure random value. "
            "Generate one with: python -c 'import secrets; print(secrets.token_urlsafe(32))'"
        )

    if settings.ENVIRONMENT == "production":
        if not settings.RAZORPAY_KEY_SECRET:
            raise ValueError("RAZORPAY_KEY_SECRET is required in production")
        if not settings.RAZORPAY_WEBHOOK_SECRET:
            raise ValueError("RAZORPAY_WEBHOOK_SECRET is required in production")
        if not settings.AWS_ACCESS_KEY_ID or not settings.AWS_SECRET_ACCESS_KEY:
            raise ValueError("AWS credentials are required in production")
        # Redis is required in production for rate limiting to actually be
        # shared across worker processes -- without this check, a missing or
        # unreachable Redis silently falls back to a per-process in-memory
        # store, meaning the effective rate limit becomes (configured limit x
        # number of workers) with no error or warning.
        import redis
        try:
            redis.from_url(settings.REDIS_URL).ping()
        except Exception as exc:
            raise ValueError(
                f"REDIS_URL is required in production and must be reachable. "
                f"Got: {settings.REDIS_URL}. Error: {exc}"
            ) from exc

    return settings
