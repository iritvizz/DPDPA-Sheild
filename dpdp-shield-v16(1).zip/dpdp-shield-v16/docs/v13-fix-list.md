# DPDP Shield v13 — Verified Fixes & Remaining Work

Continuing from v12.

---

## Confirmed fixed and verified in this pass

1. **Malware-scan test no longer hangs the suite.** The v12 fix (injectable `session_factory`) was directionally correct but introduced a cross-event-loop asyncpg corruption: `_run_async` detected the test's running loop and spawned a new thread with its own loop, while the injected `TestingSessionLocal` was bound to the test's original loop. The new `_run_async_in_test` helper submits the coroutine back to the *same* loop via `asyncio.run_coroutine_threadsafe` and blocks on a `threading.Event`, keeping all DB work on one loop. The production path (`_run_async`, no running loop → new thread) is unchanged. Confirmed: the test passes on its own and the full suite runs together without hanging.
2. **Razorpay webhook secret now enforced in production.** Added `RAZORPAY_WEBHOOK_SECRET` to the `config.py` production validation block, alongside the existing `RAZORPAY_KEY_SECRET` check. The webhook endpoint itself still warns-and-skips in non-production for local dev convenience. Confirmed by reading the validation block: the check is present, not just planned.
3. **Redis rate-limit test isolation actually works.** Replaced the inert DB-15 redirect (which silently flushed an unused database because `get_settings()` is `@lru_cache`'d and already frozen before the fixture runs) with an unconditional `scan_iter(match="ratelimit:*")` + `delete` on the *real* `settings.REDIS_URL`. Confirmed: running the full suite twice back-to-back no longer produces spurious 429 failures on the second run.
4. **Test-only dependencies declared.** Added `moto==5.0.0` and `pytest-mock==3.14.0` to `requirements.txt`. Confirmed: a clean `pip install -r requirements.txt` followed by `pytest --collect-only` now succeeds without `ModuleNotFoundError` for `moto`.
5. **`lib/api.ts` docstring fixed.** Changed the Python-style `"""..."""` opener to a JavaScript `//` comment. This was a pre-existing bug (present since v11) that was masked by the `next.config.js` rewrite error failing the build earlier. Confirmed: `npm run build` now reaches the font-fetch stage instead of failing on syntax.

---

## Frontend build fragility (flagged, not a required code fix)

6. **`next/font/google` requires live internet at build time.** `app/layout.tsx` fetches the `Inter` font from `fonts.googleapis.com` during `npm run build`. This succeeds on machines with normal internet access but fails in restricted CI/build environments. Recommendation: switch to `next/font/local` with the font file vendored into the repo if build reliability in restricted environments matters.
7. **`npm audit` not fully clean after Next.js bump.** `next@14.2.35` fixed the critical cache-poisoning advisory from 14.2.5, but several moderate/high advisories remain (mostly Server-Actions/Edge-runtime scenarios that may not apply to this app's configuration, plus `next-intl` and transitive `postcss` issues). Worth a deliberate review of which advisories actually apply before deciding whether to jump to Next 16.

---

## Still open / carried forward

- **Real Docker build end-to-end.** No Docker daemon available in the verification environment. The Dockerfile and compose fixes are correct by inspection but have never been `docker build`d.
- **Real Razorpay sandbox verification.** The notes-based account linking in webhooks is architecturally sound but not exercised against Razorpay's real API.
- **Rate limiting under genuine multi-worker concurrency.** Not load-tested against the 500-concurrent-user NFR.
- **`pip-audit` on Python dependencies.** Only `npm audit` has been run; no equivalent scan on the Python side.
- **Frontend pages beyond auth.** Dashboard, Inventory, Consent, Privacy Notice, RoPA, Account, Subscription, DSAR, and Admin panels are still unbuilt — only layout, i18n scaffolding, and shared UI components exist.
- **Alembic migrations.** The `dsar_requests` table (added in v10) and any schema changes since v7 still need a production migration. Tests use `Base.metadata.create_all` so they don't need one.
- **pytest-asyncio deprecation.** The `event_loop` fixture override works on `pytest-asyncio==0.23.7` but triggers a deprecation warning. A future upgrade will require migrating to `@pytest.mark.asyncio(loop_scope="session")`.

---

## Process note

Two fixes from the v12 handoff (Razorpay webhook secret, Redis rate-limit isolation) were reported as done but didn't actually change behavior — one wasn't touched in the shipped files, one was inert due to a settings-caching bug. Both were caught by re-running the exact failure scenario from the previous report after applying the fix, not just reading the new code. This is the same principle that has surfaced every genuine bug in this project: verification by re-execution of the original repro, not by re-reading the diff.
