"""Reports and audit-pack routes."""
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Account, AuditPackGeneration, User
from app.schemas import AuditPackResponse, MessageResponse
from app.utils.auth import get_current_active_user, require_admin
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/reports", tags=["reports"])


@router.post("/audit-pack", response_model=AuditPackResponse, status_code=status.HTTP_202_ACCEPTED)
async def generate_audit_pack(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Trigger generation of the full audit-pack PDF.

    Queues a Celery task that fetches all account data, renders HTML,
    converts to PDF via WeasyPrint, uploads to S3, and returns a
    pre-signed download link valid for 7 days.
    """
    from app.tasks.pdf import generate_audit_pack

    # Create a generation record to track status
    gen = AuditPackGeneration(
        account_id=current_user.account_id,
        requested_by=current_user.id,
        status="queued",
    )
    db.add(gen)
    await db.commit()
    await db.refresh(gen)

    # Queue the Celery task
    generate_audit_pack.delay(current_user.account_id, current_user.id)

    logger.info(f"Audit pack queued: generation_id={gen.id}, account={current_user.account_id}")

    return AuditPackResponse(
        generation_id=gen.public_id,
        status="queued",
        download_url=None,
        expires_at=None,
    )


@router.get("/audit-pack/{generation_id}", response_model=AuditPackResponse)
async def get_audit_pack_status(
    generation_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Check status of an audit-pack generation and retrieve download link
    if complete."""
    result = await db.execute(
        select(AuditPackGeneration).where(
            AuditPackGeneration.public_id == generation_id,
            AuditPackGeneration.account_id == current_user.account_id,
        )
    )
    gen = result.scalar_one_or_none()
    if not gen:
        raise HTTPException(status_code=404, detail="Audit pack not found")

    # Compute pre-signed download URL from S3 key when completed
    download_url = None
    if gen.status == "completed" and gen.file_s3_key:
        from app.services.s3_service import S3Service
        download_url = S3Service().generate_presigned_url(gen.file_s3_key, expiration=3600 * 24 * 7)

    return AuditPackResponse(
        generation_id=gen.public_id,
        status=gen.status,
        download_url=download_url,
        expires_at=gen.expires_at,
    )


@router.get("/monthly-summary", response_model=dict)
async def get_monthly_summary(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Return a monthly summary of compliance activity for the account.

    Includes counts of new consent records, DSAR requests, data source
    uploads, and privacy notice updates in the current calendar month.
    """
    from sqlalchemy import func
    from app.models import ConsentRecord, DSARRequest, DataSource, PrivacyNotice

    now = datetime.now(timezone.utc)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    consent_count = (
        await db.execute(
            select(func.count(ConsentRecord.id)).where(
                ConsentRecord.account_id == current_user.account_id,
                ConsentRecord.created_at >= month_start,
            )
        )
    ).scalar() or 0

    dsar_count = (
        await db.execute(
            select(func.count(DSARRequest.id)).where(
                DSARRequest.account_id == current_user.account_id,
                DSARRequest.created_at >= month_start,
            )
        )
    ).scalar() or 0

    source_count = (
        await db.execute(
            select(func.count(DataSource.id)).where(
                DataSource.account_id == current_user.account_id,
                DataSource.created_at >= month_start,
            )
        )
    ).scalar() or 0

    notice_count = (
        await db.execute(
            select(func.count(PrivacyNotice.id)).where(
                PrivacyNotice.account_id == current_user.account_id,
                PrivacyNotice.created_at >= month_start,
            )
        )
    ).scalar() or 0

    return {
        "month": now.strftime("%Y-%m"),
        "consent_records_created": consent_count,
        "dsar_requests_received": dsar_count,
        "data_sources_uploaded": source_count,
        "privacy_notices_published": notice_count,
    }
