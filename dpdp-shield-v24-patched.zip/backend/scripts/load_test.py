"""Simple load test script for DPDP Shield.

Usage:
    # Install dependencies first:
    pip install locust

    # Run against local instance:
    locust -f scripts/load_test.py --host http://localhost:8000

    # Or run headless:
    locust -f scripts/load_test.py --host http://localhost:8000 \
        --headless -u 500 -r 50 --run-time 60s --csv=load_test_results

Target: 500 concurrent users, < 500ms avg response time for CRUD ops.
"""
from locust import HttpUser, between, task


class DPDPShieldUser(HttpUser):
    wait_time = between(1, 5)

    def on_start(self):
        """Login and store token."""
        response = self.client.post(
            "/api/v1/auth/login",
            json={"email": "test@example.com", "password": "password123"},
        )
        if response.status_code == 200:
            self.token = response.json()["access_token"]
        else:
            self.token = None

    @task(3)
    def get_dashboard(self):
        """Dashboard summary — most frequent operation."""
        if self.token:
            self.client.get(
                "/api/v1/dashboard/summary",
                headers={"Authorization": f"Bearer {self.token}"},
                name="/dashboard/summary",
            )

    @task(2)
    def get_inventory(self):
        """Inventory list."""
        if self.token:
            self.client.get(
                "/api/v1/inventory/sources",
                headers={"Authorization": f"Bearer {self.token}"},
                name="/inventory/sources",
            )

    @task(2)
    def get_consent_records(self):
        """Consent records list."""
        if self.token:
            self.client.get(
                "/api/v1/consent/records",
                headers={"Authorization": f"Bearer {self.token}"},
                name="/consent/records",
            )

    @task(1)
    def get_monthly_summary(self):
        """Reports monthly summary."""
        if self.token:
            self.client.get(
                "/api/v1/reports/monthly-summary",
                headers={"Authorization": f"Bearer {self.token}"},
                name="/reports/monthly-summary",
            )

    @task(1)
    def get_audit_log(self):
        """Audit log — heavier query."""
        if self.token:
            self.client.get(
                "/api/v1/audit-log",
                headers={"Authorization": f"Bearer {self.token}"},
                name="/audit-log",
            )
