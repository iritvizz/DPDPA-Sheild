"""Account management routes."""
import json
import uuid
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.utils.enums import enum_value
from app.services.user_service import remove_user_from_account
from app.models import (
    Account,
    AuditLog,
    ConsentRecord,
    DataSource,
    PrivacyNotice,
    User,
    UserInvitation,
    UserRole,
)
from app.schemas import (
    AccountResponse,
    AccountUpdateRequest,
    MessageResponse,
    UserInviteRequest,
    UserInvitationResponse,
    UserResponse,
)
from app.utils.auth import (
    generate_invitation_token,
    get_current_active_user,
    get_password_hash,
    require_admin,
)
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/account", tags=["account"])


@router.get("", response_model=AccountResponse)
async def get_account(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Get current account details."""
    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    return result.scalar_one()


@router.patch("", response_model=AccountResponse)
async def update_account(
    data: AccountUpdateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Update account details."""
    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    account = result.scalar_one()

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(account, field, value)

    await db.commit()
    await db.refresh(account)

    return account


@router.delete("", response_model=MessageResponse)
async def delete_account(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Request account deletion (48h cooling off)."""
    from app.tasks.email import send_account_deletion_warning
    from app.tasks.account import hard_delete_account

    result = await db.execute(
        select(Account).where(Account.id == current_user.account_id)
    )
    account = result.scalar_one()

    account.status = "deleted"
    account.deleted_at = datetime.now(timezone.utc) + timedelta(hours=48)
    await db.commit()

    # Send cooling-off email immediately
    send_account_deletion_warning.delay(account.id)

    # Schedule hard deletion after 48 hours
    hard_delete_account.apply_async(
        args=[account.id],
        countdown=48 * 3600,  # 48 hours in seconds
    )

    return MessageResponse(message="Account scheduled for deletion in 48 hours. A confirmation email has been sent.")


@router.get("/export")
async def export_account_data(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Export all account data as machine-readable JSON."""
    account_id = current_user.account_id

    # Get account
    result = await db.execute(select(Account).where(Account.id == account_id))
    account = result.scalar_one()

    # Get data sources
    result = await db.execute(
        select(DataSource)
        .options(selectinload(DataSource.elements))
        .where(DataSource.account_id == account_id)
    )
    data_sources = result.scalars().all()

    # Get privacy notices
    result = await db.execute(select(PrivacyNotice).where(PrivacyNotice.account_id == account_id))
    notices = result.scalars().all()

    # Get consent records (metadata only, no PII)
    result = await db.execute(select(ConsentRecord).where(ConsentRecord.account_id == account_id))
    consent = result.scalars().all()

    # Get audit logs
    result = await db.execute(select(AuditLog).where(AuditLog.account_id == account_id))
    logs = result.scalars().all()

    export_data = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "account": {
            "public_id": str(account.public_id),
            "business_name": account.business_name,
            "business_slug": account.business_slug,
            "sector": account.sector,
            "status": enum_value(account.status),
            "created_at": account.created_at.isoformat() if account.created_at else None,
        },
        "data_sources": [
            {
                "id": ds.id,
                "name": ds.name,
                "source_type": enum_value(ds.source_type),
                "status": enum_value(ds.status),
                "row_count": ds.row_count,
                "column_count": ds.column_count,
                "elements": [
                    {
                        "field_name": e.field_name,
                        "data_category": enum_value(e.data_category),
                        "purposes": e.purposes,
                        "retention": f"{e.retention_period_value} {e.retention_period_unit}" if e.retention_period_value else None,
                    }
                    for e in ds.elements
                ],
            }
            for ds in data_sources
        ],
        "privacy_notices": [
            {
                "version": n.version,
                "template_type": n.template_type,
                "is_published": n.is_published,
                "published_at": n.published_at.isoformat() if n.published_at else None,
            }
            for n in notices
        ],
        "consent_records": [
            {
                "public_id": str(c.public_id),
                "purpose": c.purpose,
                "method": enum_value(c.method),
                "is_revoked": c.is_revoked,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
            for c in consent
        ],
        "audit_logs": [
            {
                "event_type": l.event_type,
                "event_details": l.event_details,
                "created_at": l.created_at.isoformat() if l.created_at else None,
            }
            for l in logs
        ],
    }

    return export_data


# User management (staff invites)
@router.post("/users/invite", response_model=UserInvitationResponse, status_code=status.HTTP_201_CREATED)
async def invite_user(
    data: UserInviteRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Invite a staff user by email."""
    # Check if email already exists in account
    result = await db.execute(
        select(User).where(
            User.account_id == current_user.account_id,
            User.email == data.email,
        )
    )
    if result.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="User already exists in this account")

    # Check existing invitation
    result = await db.execute(
        select(UserInvitation).where(
            UserInvitation.account_id == current_user.account_id,
            UserInvitation.email == data.email,
            UserInvitation.used_at.is_(None),
        )
    )
    existing = result.scalar_one_or_none()
    if existing and existing.expires_at > datetime.now(timezone.utc):
        raise HTTPException(status_code=409, detail="Invitation already pending for this email")

    token = generate_invitation_token()
    invitation = UserInvitation(
        account_id=current_user.account_id,
        email=data.email,
        token=token,
        role=data.role,
        expires_at=datetime.now(timezone.utc) + timedelta(hours=48),
    )
    db.add(invitation)
    await db.commit()
    await db.refresh(invitation)

    # Send invitation email
    from app.tasks.email import send_staff_invitation
    send_staff_invitation.delay(invitation.id)

    return invitation


@router.get("/users", response_model=list[UserResponse])
async def list_users(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List all users in the account."""
    result = await db.execute(
        select(User).where(User.account_id == current_user.account_id)
    )
    return result.scalars().all()


@router.delete("/users/{user_id}", response_model=MessageResponse)
async def remove_user(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Remove a staff user from the account."""
    message = await remove_user_from_account(
        user_id=user_id,
        account_id=current_user.account_id,
        db=db,
    )
    return MessageResponse(message=message)
