"""Consent proof upload security tests."""
import pytest
from fastapi import UploadFile
from io import BytesIO

from app.services.s3_service import S3Service, ALLOWED_MIME_TYPES, MAX_FILE_SIZE


class TestConsentProofSecurity:
    """Test consent proof upload safeguards per Section 6.4."""

    def test_mime_validation_rejects_renamed_executable(self):
        """Verify that a file renamed from .exe to .png is rejected."""
        s3 = S3Service()

        # EXE file content (MZ header) renamed as PNG
        exe_content = b"MZ\x90\x00\x03\x00\x00\x00\x04\x00\x00\x00\xFF\xFF" + b"\x00" * 100

        is_valid, error = s3.validate_file_content(exe_content, "fake.png")

        # MUST be rejected - exe content with png extension
        assert is_valid is False, f"Renamed executable was accepted: {error}"
        assert "Invalid file type" in error or "does not match" in error

    def test_mime_validation_accepts_valid_png(self):
        """Verify that a real PNG file is accepted."""
        s3 = S3Service()

        # Minimal valid PNG file
        import struct
        png_header = b"\x89PNG\r\n\x1a\n"
        ihdr_len = struct.pack(">I", 13)
        ihdr_type = b"IHDR"
        ihdr_data = b"\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00"
        ihdr_crc = struct.pack(">I", 0x907753DE)
        iend = struct.pack(">I", 0) + b"IEND" + struct.pack(">I", 0xAE426082)

        valid_png = png_header + ihdr_len + ihdr_type + ihdr_data + ihdr_crc + iend

        is_valid, error = s3.validate_file_content(valid_png, "test.png")

        # Should be accepted
        assert is_valid is True, f"Valid PNG rejected: {error}"

    def test_mime_validation_rejects_mismatched_extension(self):
        """Verify extension must match detected MIME type."""
        s3 = S3Service()

        # Valid PNG content but wrong extension
        import struct
        png_header = b"\x89PNG\r\n\x1a\n"
        ihdr = struct.pack(">I", 13) + b"IHDR" + b"\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00"
        ihdr_crc = struct.pack(">I", 0x907753DE)
        iend = struct.pack(">I", 0) + b"IEND" + struct.pack(">I", 0xAE426082)
        valid_png = png_header + ihdr + ihdr_crc + iend

        is_valid, error = s3.validate_file_content(valid_png, "test.jpg")

        # MUST be rejected - PNG content with JPG extension
        assert is_valid is False, f"Mismatched extension accepted: {error}"
        assert "does not match" in error

    def test_oversized_file_rejected(self):
        """Verify files over 10MB are rejected."""
        s3 = S3Service()

        large_content = b"x" * (11 * 1024 * 1024)  # 11MB

        is_valid, error = s3.validate_file_content(large_content, "large.png")

        assert is_valid is False, "Oversized file was accepted"
        assert "too large" in error.lower()
        assert "10MB" in error

    def test_allowed_mime_types_defined(self):
        """Verify allowed MIME types are correctly defined."""
        assert "image/png" in ALLOWED_MIME_TYPES
        assert "image/jpeg" in ALLOWED_MIME_TYPES
        assert "application/pdf" in ALLOWED_MIME_TYPES
        assert len(ALLOWED_MIME_TYPES) == 3

    def test_max_file_size_constant(self):
        """Verify max file size is 10MB."""
        assert MAX_FILE_SIZE == 10 * 1024 * 1024
