"""DSAR response template seed data (EN / GU / HI).

Loaded at application startup if the dsar_templates table is empty.
"""
from datetime import datetime, timezone

DSAR_TEMPLATES = [
    # English
    {
        "request_type": "access",
        "language": "en",
        "subject_template": "Re: Your Data Access Request",
        "body_template": "Dear Principal,\n\nWe acknowledge receipt of your data access request dated {date}. We are compiling the information you have requested and will provide it within the statutory timeframe of 30 days.\n\nRegards,\nData Protection Officer",
    },
    {
        "request_type": "correction",
        "language": "en",
        "subject_template": "Re: Your Data Correction Request",
        "body_template": "Dear Principal,\n\nWe acknowledge receipt of your data correction request dated {date}. We are reviewing the changes you have proposed and will confirm once the corrections have been applied.\n\nRegards,\nData Protection Officer",
    },
    {
        "request_type": "deletion",
        "language": "en",
        "subject_template": "Re: Your Data Deletion Request",
        "body_template": "Dear Principal,\n\nWe acknowledge receipt of your data deletion request dated {date}. We are reviewing your request against our legal retention obligations and will confirm the outcome shortly.\n\nRegards,\nData Protection Officer",
    },
    {
        "request_type": "portability",
        "language": "en",
        "subject_template": "Re: Your Data Portability Request",
        "body_template": "Dear Principal,\n\nWe acknowledge receipt of your data portability request dated {date}. We are preparing your data in a machine-readable format and will provide the download link shortly.\n\nRegards,\nData Protection Officer",
    },
    # Gujarati
    {
        "request_type": "access",
        "language": "gu",
        "subject_template": "Re: તમારી ડેટા ઍક્સેસ વિનંતી",
        "body_template": "પ્રિય વ્યક્તિ,\n\nતારીખ {date} ની તમારી ડેટા ઍક્સેસ વિનંતી મળી. અમે તમારી માંગણી અનુસાર માહિતી એકત્રિત કરી રહ્યા છીએ અને 30 દિવસની કાયદાકીય મર્યાદામાં પૂરી પાડીશું.\n\nઆભાર,\nડેટા પ્રોટેક્શન ઓફિસર",
    },
    {
        "request_type": "correction",
        "language": "gu",
        "subject_template": "Re: તમારી ડેટા સુધારા વિનંતી",
        "body_template": "પ્રિય વ્યક્તિ,\n\nતારીખ {date} ની તમારી ડેટા સુધારા વિનંતી મળી. અમે તમારા સૂચવેલા ફેરફારોની ઝીપી રહ્યા છીએ અને એકવાર સુધારા લાગુ થયા પછી ખાતરી કરીશું.\n\nઆભાર,\nડેટા પ્રોટેક્શન ઓફિસર",
    },
    {
        "request_type": "deletion",
        "language": "gu",
        "subject_template": "Re: તમારી ડેટા કાઢી નાખવાની વિનંતી",
        "body_template": "પ્રિય વ્યક્તિ,\n\nતારીખ {date} ની તમારી ડેટા કાઢી નાખવાની વિનંતી મળી. અમે તમારી વિનંતીને અમારા કાયદાકીય રાખવાના બંધનો સામે ઝીપી રહ્યા છીએ અને ટૂંક સમયમાં પરિણામની ખાતરી કરીશું.\n\nઆભાર,\nડેટા પ્રોટેક્શન ઓફિસર",
    },
    {
        "request_type": "portability",
        "language": "gu",
        "subject_template": "Re: તમારી ડેટા પોર્ટેબિલિટી વિનંતી",
        "body_template": "પ્રિય વ્યક્તિ,\n\nતારીખ {date} ની તમારી ડેટા પોર્ટેબિલિટી વિનંતી મળી. અમે તમારો ડેટા મશીન-રીડેબલ ફોર્મેટમાં તૈયાર કરી રહ્યા છીએ અને ટૂંક સમયમાં ડાઉનલોડ લિંક પૂરી પાડીશું.\n\nઆભાર,\nડેટા પ્રોટેક્શન ઓફિસર",
    },
    # Hindi
    {
        "request_type": "access",
        "language": "hi",
        "subject_template": "Re: आपका डेटा एक्सेस अनुरोध",
        "body_template": "प्रिय व्यक्ति,\n\nदिनांक {date} को आपका डेटा एक्सेस अनुरोध प्राप्त हुआ। हम आपके अनुरोध के अनुसार जानकारी एकत्र कर रहे हैं और 30 दिनों की कानूनी सीमा के भीतर प्रदान करेंगे।\n\nधन्यवाद,\nडेटा प्रोटेक्शन ऑफिसर",
    },
    {
        "request_type": "correction",
        "language": "hi",
        "subject_template": "Re: आपका डेटा सुधार अनुरोध",
        "body_template": "प्रिय व्यक्ति,\n\nदिनांक {date} को आपका डेटा सुधार अनुरोध प्राप्त हुआ। हम आपके सुझाए गए परिवर्तनों की समीक्षा कर रहे हैं और सुधार लागू होने पर पुष्टि करेंगे।\n\nधन्यवाद,\nडेटा प्रोटेक्शन ऑफिसर",
    },
    {
        "request_type": "deletion",
        "language": "hi",
        "subject_template": "Re: आपका डेटा विलोपन अनुरोध",
        "body_template": "प्रिय व्यक्ति,\n\nदिनांक {date} को आपका डेटा विलोपन अनुरोध प्राप्त हुआ। हम आपके अनुरोध की समीक्षा अपने कानूनी संरक्षण दायित्वों के विरुद्ध कर रहे हैं और शीघ्र ही परिणाम की पुष्टि करेंगे।\n\nधन्यवाद,\nडेटा प्रोटेक्शन ऑफिसर",
    },
    {
        "request_type": "portability",
        "language": "hi",
        "subject_template": "Re: आपका डेटा पोर्टेबिलिटी अनुरोध",
        "body_template": "प्रिय व्यक्ति,\n\nदिनांक {date} को आपका डेटा पोर्टेबिलिटी अनुरोध प्राप्त हुआ। हम आपका डेटा मशीन-रीडेबल प्रारूप में तैयार कर रहे हैं और शीघ्र ही डाउनलोड लिंक प्रदान करेंगे।\n\nधन्यवाद,\nडेटा प्रोटेक्शन ऑफिसर",
    },
]
