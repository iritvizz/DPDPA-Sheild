"""Consent management routes."""
import uuid as uuid_mod
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.models import ConsentMethod, ConsentRecord, User
from app.schemas import (
    ConsentRecordCreateRequest,
    ConsentRecordResponse,
    MessageResponse,
    WidgetCaptureRequest,
    WithdrawalResponse,
)
from app.services.s3_service import S3Service
from app.tasks.malware_scan import scan_consent_proof
from app.utils.auth import (
    get_account_from_slug,
    get_current_active_user,
    require_admin,
    verify_widget_nonce,
)
from app.utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/consent", tags=["consent"])


@router.get("/records", response_model=list[ConsentRecordResponse])
async def list_consent(
    customer_reference: str = None,
    purpose: str = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """List consent records with optional filtering."""
    query = select(ConsentRecord).where(
        ConsentRecord.account_id == current_user.account_id
    )

    if customer_reference:
        query = query.where(ConsentRecord.customer_reference.ilike(f"%{customer_reference}%"))
    if purpose:
        query = query.where(ConsentRecord.purpose == purpose)

    result = await db.execute(query.order_by(ConsentRecord.created_at.desc()))
    return result.scalars().all()


@router.post("/records", response_model=ConsentRecordResponse, status_code=status.HTTP_201_CREATED)
async def create_consent(
    data: ConsentRecordCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Manually log a consent record."""
    record = ConsentRecord(
        account_id=current_user.account_id,
        customer_reference=data.customer_reference,
        purpose=data.purpose,
        consent_timestamp=data.consent_timestamp or datetime.now(timezone.utc),
        method=data.method,
        proof_text=data.proof_text,
        consent_expiry=data.consent_expiry,
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)

    return record


@router.post("/records/{record_id}/proof-file", response_model=ConsentRecordResponse)
async def upload_proof(
    record_id: int,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Upload consent proof file with content validation."""
    settings = get_settings()

    # Get record
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.id == record_id,
            ConsentRecord.account_id == current_user.account_id,
        )
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Consent record not found")

    # Read file content
    content = await file.read()

    # Validate and upload
    s3 = S3Service()
    try:
        temp_key, file_id = await s3.upload_consent_proof(
            content, file.filename, current_user.account_id
        )

        record.proof_file_s3_key = temp_key
        record.proof_file_status = "pending"
        await db.commit()

        # Enqueue malware scan task
        scan_consent_proof.delay(temp_key, record.id, current_user.account_id)

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return record


@router.delete("/records/{record_id}/proof-file", response_model=MessageResponse)
async def delete_proof(
    record_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Delete consent proof file from S3."""
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.id == record_id,
            ConsentRecord.account_id == current_user.account_id,
        )
    )
    record = result.scalar_one_or_none()
    if not record or not record.proof_file_s3_key:
        raise HTTPException(status_code=404, detail="Proof file not found")

    s3 = S3Service()
    s3.delete_file(record.proof_file_s3_key)

    record.proof_file_s3_key = None
    record.proof_file_status = "none"
    await db.commit()

    return MessageResponse(message="Proof file deleted")


@router.post("/records/{record_id}/revoke", response_model=ConsentRecordResponse)
async def revoke_consent(
    record_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """Revoke a consent record."""
    result = await db.execute(
        select(ConsentRecord).where(
            ConsentRecord.id == record_id,
            ConsentRecord.account_id == current_user.account_id,
        )
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(status_code=404, detail="Consent record not found")

    record.is_revoked = True
    record.revoked_at = datetime.now(timezone.utc)
    await db.commit()

    return record


@router.post("/widget/capture", status_code=status.HTTP_201_CREATED)
async def widget_capture(
    request: Request,
    data: WidgetCaptureRequest,
    db: AsyncSession = Depends(get_db),
):
    """Public endpoint for consent widget - CORS enabled, no auth required."""
    # Get account by slug
    account = await get_account_from_slug(data.business_slug, db)

    # Verify nonce
    if not verify_widget_nonce(data.business_slug, data.nonce, account.widget_nonce_secret):
        raise HTTPException(status_code=403, detail="Invalid widget nonce")

    # Create consent record
    record = ConsentRecord(
        account_id=account.id,
        customer_reference=data.customer_reference,
        purpose=data.purpose,
        consent_timestamp=data.consent_timestamp or datetime.now(timezone.utc),
        method=ConsentMethod.WEBSITE_CHECKBOX,
        ip_address=request.client.host if request.client else None,
    )
    db.add(record)
    await db.commit()

    logger.info(f"Widget consent captured for account {account.id}")

    return {"status": "success", "message": "Consent recorded"}


@router.get("/public/withdrawal/{token}", response_model=WithdrawalResponse)
async def verify_withdrawal(token: str, db: AsyncSession = Depends(get_db)):
    """Public withdrawal confirmation page."""
    result = await db.execute(
        select(ConsentRecord).where(ConsentRecord.withdrawal_token == token)
    )
    record = result.scalar_one_or_none()

    if not record or not record.is_revoked:
        raise HTTPException(status_code=404, detail="Withdrawal token not found")

    return WithdrawalResponse(
        customer_reference=record.customer_reference,
        purpose=record.purpose,
        withdrawn_at=record.revoked_at,
        message=f"Consent for {record.purpose} was withdrawn on {record.revoked_at.strftime('%B %d, %Y')}.",
    )
