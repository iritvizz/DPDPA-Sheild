"""DSAR ticketing tests."""
import secrets

import pytest
from httpx import AsyncClient

from app.models import Account, DSARRequest, DSARType, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_create_dsar(async_client: AsyncClient, db_session):
    """Any authenticated user can create a DSAR for their account."""
    account = Account(
        business_name="DSAR Test", business_slug="dsar-test",
        sector="E-commerce", widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id, email="dsar@example.com",
        password_hash="fakehash", role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    response = await async_client.post(
        "/api/v1/dsar",
        json={
            "principal_email": "data.subject@example.com",
            "principal_name": "Data Subject",
            "request_type": "access",
            "description": "I want to know what data you hold about me.",
        },
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 201, response.text
    data = response.json()
    assert data["principal_email"] == "data.subject@example.com"
    assert data["request_type"] == "access"
    assert data["status"] == "pending"


@pytest.mark.asyncio
async def test_list_dsars(async_client: AsyncClient, db_session):
    """Users can list DSARs for their account only."""
    account = Account(
        business_name="DSAR List", business_slug="dsar-list",
        sector="Services", widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id, email="list@example.com",
        password_hash="fakehash", role=UserRole.STAFF,
    )
    db_session.add(user)

    dsar = DSARRequest(
        account_id=account.id, principal_email="subj@example.com",
        request_type=DSARType.DELETION,
    )
    db_session.add(dsar)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    response = await async_client.get("/api/v1/dsar", headers={"Authorization": f"Bearer {token}"})

    assert response.status_code == 200
    items = response.json()
    assert len(items) == 1
    assert items[0]["request_type"] == "deletion"


@pytest.mark.asyncio
async def test_update_dsar_admin_only(async_client: AsyncClient, db_session):
    """Only admins can update DSAR status."""
    account = Account(
        business_name="DSAR Update", business_slug="dsar-update",
        sector="E-commerce", widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    admin = User(
        account_id=account.id, email="admin@example.com",
        password_hash="fakehash", role=UserRole.ADMIN,
    )
    db_session.add(admin)

    staff = User(
        account_id=account.id, email="staff@example.com",
        password_hash="fakehash", role=UserRole.STAFF,
    )
    db_session.add(staff)

    dsar = DSARRequest(
        account_id=account.id, principal_email="subj@example.com",
        request_type=DSARType.CORRECTION,
    )
    db_session.add(dsar)
    await db_session.commit()
    await db_session.refresh(dsar)

    admin_token = create_access_token({"sub": str(admin.public_id)})
    staff_token = create_access_token({"sub": str(staff.public_id)})

    # Staff cannot update
    response = await async_client.patch(
        f"/api/v1/dsar/{dsar.public_id}",
        json={"status": "in_progress"},
        headers={"Authorization": f"Bearer {staff_token}"},
    )
    assert response.status_code == 403, response.text

    # Admin can update
    response = await async_client.patch(
        f"/api/v1/dsar/{dsar.public_id}",
        json={"status": "in_progress", "response_text": "We're looking into this."},
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["status"] == "in_progress"
    assert data["response_text"] == "We're looking into this."
