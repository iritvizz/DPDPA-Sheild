"""Widget CORS middleware.

The consent widget runs on arbitrary third-party business websites.
Its two endpoints (/consent/widget/nonce, /consent/widget/capture) are
public, nonce-secured, and do NOT use cookies or bearer auth. They must
allow any origin. All other API endpoints use the strict CORS allowlist
from settings.
"""
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response


class WidgetCORSMiddleware(BaseHTTPMiddleware):
    """Allow any origin for widget endpoints; pass through for all others."""

    WIDGET_PATHS = ("/api/v1/consent/widget/nonce", "/api/v1/consent/widget/capture")

    async def dispatch(self, request: Request, call_next):
        # For widget endpoints: allow any origin, no credentials
        if request.url.path.startswith(self.WIDGET_PATHS):
            if request.method == "OPTIONS":
                return Response(
                    status_code=204,
                    headers={
                        "Access-Control-Allow-Origin": "*",
                        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                        "Access-Control-Allow-Headers": "*",
                    },
                )
            response = await call_next(request)
            response.headers["Access-Control-Allow-Origin"] = "*"
            return response

        # All other routes: pass through to the next middleware
        return await call_next(request)
