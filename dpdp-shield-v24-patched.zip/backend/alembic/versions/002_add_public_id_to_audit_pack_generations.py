"""Add public_id to audit_pack_generations.

Revision ID: 002
Revises: ff66776d7fa6
Create Date: 2024-01-15 00:00:00.000000+00:00

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

# revision identifiers, used by Alembic.
revision: str = "002"
down_revision: Union[str, None] = "ff66776d7fa6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Add nullable public_id first
    op.add_column(
        "audit_pack_generations",
        sa.Column("public_id", UUID(as_uuid=True), nullable=True),
    )
    op.create_index(
        "ix_audit_pack_generations_public_id",
        "audit_pack_generations",
        ["public_id"],
        unique=True,
    )

    # Backfill existing rows with UUIDv4
    op.execute(
        """
        UPDATE audit_pack_generations
        SET public_id = gen_random_uuid()
        WHERE public_id IS NULL
        """
    )

    # Make NOT NULL
    op.alter_column("audit_pack_generations", "public_id", nullable=False)


def downgrade() -> None:
    op.drop_index("ix_audit_pack_generations_public_id", table_name="audit_pack_generations")
    op.drop_column("audit_pack_generations", "public_id")
