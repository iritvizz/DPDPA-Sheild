"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import { apiFetch, clearTokens } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Account {
  business_name: string;
  sector: string;
  grievance_email: string | null;
  grievance_phone: string | null;
  grievance_address: string | null;
  status: string;
}

interface StaffUser {
  public_id: string;
  email: string;
  role: string;
  is_verified: boolean;
}

interface Subscription {
  plan_id: string;
  status: string;
  current_period_end: string | null;
}

export default function SettingsPage() {
  const t = useTranslations();
  const router = useRouter();

  const [account, setAccount] = useState<Account | null>(null);
  const [users, setUsers] = useState<StaffUser[]>([]);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [saving, setSaving] = useState(false);

  const [businessName, setBusinessName] = useState("");
  const [grievanceEmail, setGrievanceEmail] = useState("");
  const [grievancePhone, setGrievancePhone] = useState("");
  const [grievanceAddress, setGrievanceAddress] = useState("");

  const [inviteEmail, setInviteEmail] = useState("");
  const [inviting, setInviting] = useState(false);

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [pendingDeletion, setPendingDeletion] = useState(false);

  const loadAll = () => {
    setLoading(true);
    Promise.all([
      apiFetch("/api/v1/account"),
      apiFetch("/api/v1/users"),
      apiFetch("/api/v1/subscription"),
    ])
      .then(([acc, usersList, sub]) => {
        setAccount(acc);
        setBusinessName(acc.business_name || "");
        setGrievanceEmail(acc.grievance_email || "");
        setGrievancePhone(acc.grievance_phone || "");
        setGrievanceAddress(acc.grievance_address || "");
        setUsers(usersList);
        setSubscription(sub);
        setPendingDeletion(acc.status === "deleted");
      })
      .catch((err) => setError(err.message || "Failed to load settings"))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleSaveBusinessDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    setSuccess("");
    try {
      await apiFetch("/api/v1/account", {
        method: "PATCH",
        body: JSON.stringify({
          business_name: businessName,
          grievance_email: grievanceEmail || null,
          grievance_phone: grievancePhone || null,
          grievance_address: grievanceAddress || null,
        }),
      });
      setSuccess("Business details saved.");
      loadAll();
    } catch (err: any) {
      setError(err.message || "Failed to save changes.");
    } finally {
      setSaving(false);
    }
  };

  const handleInviteStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail) return;
    setInviting(true);
    setError("");
    setSuccess("");
    try {
      await apiFetch("/api/v1/users/invite", {
        method: "POST",
        body: JSON.stringify({ email: inviteEmail, role: "staff" }),
      });
      setSuccess(`Invitation sent to ${inviteEmail}.`);
      setInviteEmail("");
      loadAll();
    } catch (err: any) {
      setError(err.message || "Failed to send invitation.");
    } finally {
      setInviting(false);
    }
  };

  const handleRemoveStaff = async (userId: string) => {
    setError("");
    setSuccess("");
    try {
      await apiFetch(`/api/v1/users/${userId}`, { method: "DELETE" });
      setSuccess("Staff member removed.");
      loadAll();
    } catch (err: any) {
      setError(err.message || "Failed to remove staff member.");
    }
  };

  const handleCancelSubscription = async () => {
    setError("");
    setSuccess("");
    try {
      await apiFetch("/api/v1/subscription/cancel", { method: "POST" });
      setSuccess("Subscription cancelled. Access continues until the end of the current period.");
      loadAll();
    } catch (err: any) {
      setError(err.message || "Failed to cancel subscription.");
    }
  };

  const handleDeleteAccount = async () => {
    setDeleting(true);
    setError("");
    try {
      await apiFetch("/api/v1/account", { method: "DELETE" });
      setDeleteConfirmOpen(false);
      setPendingDeletion(true);
      setSuccess("Account scheduled for deletion in 48 hours. You can cancel this below at any time before then.");
    } catch (err: any) {
      setError(err.message || "Failed to schedule account deletion.");
    } finally {
      setDeleting(false);
    }
  };

  const handleCancelDeletion = async () => {
    setError("");
    setSuccess("");
    try {
      await apiFetch("/api/v1/account/cancel-deletion", { method: "POST" });
      setPendingDeletion(false);
      setSuccess("Account deletion cancelled. Your account is active again.");
      loadAll();
    } catch (err: any) {
      setError(err.message || "Failed to cancel deletion.");
    }
  };

  if (loading) {
    return <p className="text-gray-500">Loading settings...</p>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">{t("settings.title")}</h2>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {success && (
        <Alert>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {pendingDeletion && (
        <Alert variant="destructive">
          <AlertDescription className="flex items-center justify-between">
            <span>Your account is scheduled for deletion. You have 48 hours to cancel this.</span>
            <Button size="sm" variant="outline" onClick={handleCancelDeletion}>
              Cancel Deletion
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>{t("settings.businessDetails")}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSaveBusinessDetails} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="businessName">Business Name</Label>
              <Input
                id="businessName"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>{t("settings.grievanceContact")}</Label>
              <Input
                placeholder={t("settings.email")}
                type="email"
                value={grievanceEmail}
                onChange={(e) => setGrievanceEmail(e.target.value)}
              />
              <Input
                placeholder={t("settings.phone")}
                value={grievancePhone}
                onChange={(e) => setGrievancePhone(e.target.value)}
              />
              <Input
                placeholder={t("settings.address")}
                value={grievanceAddress}
                onChange={(e) => setGrievanceAddress(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("settings.staffManagement")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <ul className="space-y-2">
            {users.map((u) => (
              <li key={u.public_id} className="flex items-center justify-between border-b pb-2">
                <span>
                  {u.email} <span className="text-gray-400 text-sm">({u.role})</span>
                </span>
                {u.role !== "admin" && (
                  <Button size="sm" variant="outline" onClick={() => handleRemoveStaff(u.public_id)}>
                    Remove
                  </Button>
                )}
              </li>
            ))}
          </ul>
          <form onSubmit={handleInviteStaff} className="flex gap-2">
            <Input
              type="email"
              placeholder="colleague@company.com"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
            />
            <Button type="submit" disabled={inviting}>
              {inviting ? "Sending..." : t("settings.inviteStaff")}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("settings.billing")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {subscription && (
            <>
              <p>
                {t("settings.plan")}: <strong>{subscription.plan_id}</strong> ({subscription.status})
              </p>
              {subscription.status === "active" && (
                <Button variant="outline" onClick={handleCancelSubscription}>
                  {t("settings.cancelSubscription")}
                </Button>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <Card className="border-red-200">
        <CardHeader>
          <CardTitle className="text-red-600">Danger Zone</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {!deleteConfirmOpen ? (
            <Button
              variant="outline"
              className="border-red-300 text-red-600 hover:bg-red-50"
              onClick={() => setDeleteConfirmOpen(true)}
              disabled={pendingDeletion}
            >
              {t("settings.deleteAccount")}
            </Button>
          ) : (
            <div className="space-y-3">
              <p className="text-sm text-red-600">{t("settings.deleteConfirm")}</p>
              <div className="flex gap-2">
                <Button variant="destructive" onClick={handleDeleteAccount} disabled={deleting}>
                  {deleting ? "Scheduling..." : "Yes, delete my account"}
                </Button>
                <Button variant="outline" onClick={() => setDeleteConfirmOpen(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
