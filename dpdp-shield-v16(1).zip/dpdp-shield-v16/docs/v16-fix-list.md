# DPDP Shield v16 — Verified Fixes & Remaining Work

Continuing from v15.

---

## Confirmed fixed and verified in this pass

1. **Cancel-deletion import bugs fixed.** Three separate errors in ~15 lines: `require_admin_any_status` not imported, `AccountStatus` not imported, `from app.tasks.celery_app import control` (wrong path — `celery_app` is a variable, not a submodule). All three fixed. The test now sets `deletion_task_id` in its fixture so the revoke path is actually exercised.
2. **Audit-pack generation endpoint wired.** New `POST /api/v1/reports/audit-pack` queues the existing `generate_audit_pack` Celery task. New `GET /api/v1/reports/audit-pack/{generation_id}` checks status and returns download link. New `GET /api/v1/reports/monthly-summary` returns current-month counts. The generation logic already existed; it just had no route.
3. **Consent record detail + withdrawal link + export.** New `GET /api/v1/consent/records/{record_id}` with pre-signed proof-file URL (5-minute expiry). New `POST /api/v1/consent/records/{record_id}/withdrawal-link` generates a secure token and returns the public URL. New `GET /api/v1/consent/export?format=csv|pdf` exports records.
4. **DSAR action log endpoints.** New `POST /api/v1/dsar/{dsar_id}/actions` and `GET /api/v1/dsar/{dsar_id}/actions`. New `DSARActionLog` model with timestamped entries per ticket.
5. **Forgot-password / reset-password endpoints.** New `POST /api/v1/auth/forgot-password` (always returns success to prevent enumeration) and `POST /api/v1/auth/reset-password` (validates token, updates password). New `generate_password_reset_token` utility (30-minute expiry).
6. **Purge confirmation goes to AuditLog table.** `file_processing.py` now writes a persistent `AuditLog` row with `action="file_purge_confirmed"` and structured details, not just the application logger.
7. **Frontend i18n wired properly.** `next.config.js` now wraps with `next-intl` plugin. Dashboard layout and pages use real `getTranslations` from `next-intl/server` instead of a fake stub. `@radix-ui/react-label` added to `package.json`.
8. **Dashboard shell + placeholder pages.** New `(dashboard)/` route group with sidebar navigation, compliance checklist, quick-action buttons, and placeholder pages for Inventory, Privacy Notice, Consent, DSAR, Reports, and Settings.

---

## Still open / carried forward

- **Real Docker build end-to-end.** No Docker daemon available in the verification environment.
- **Real Razorpay sandbox verification.** Notes-based account linking not exercised against real API.
- **Rate limiting under genuine multi-worker concurrency.** Not load-tested against 500-concurrent-user NFR.
- **`pip-audit` on Python dependencies.** 43+ advisories, unchanged.
- **`npm audit` on frontend.** Moderate/high advisories remain.
- **`next/font/google` build-time network dependency.** Consider `next/font/local` for restricted CI.
- **Alembic migrations.** `dsar_requests`, `dsar_action_logs`, `deletion_task_id`, `superadmin` enum still need migrations.
- **pytest-asyncio deprecation.** `event_loop` fixture override works on 0.23.7 but triggers deprecation warning.
- **OTP verification.** Spec calls for email/phone OTP as primary signup mechanism; currently password-only.
- **Google Drive integration.** Tier 1 spec item, still untouched.
- **Retention & Deletion Logging module.** Entire module absent.
- **Admin impersonation + account detail view.**
- **Inventory element-level PATCH/DELETE and PDF export.**
- **Privacy Notice version detail + restore.**
- **Frontend pages are shells.** Dashboard scaffold exists with navigation and checklist, but real data integration and forms not yet built.
