import os
"""In-memory file processing for data inventory.

This module handles Excel/CSV file parsing entirely in memory.
NO file content is ever written to disk or S3.
"""
import io
import re
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

import pandas as pd
from fastapi import UploadFile

from app.models import DataCategory
from app.utils.logging import get_logger
from app.utils.enums import enum_value

logger = get_logger(__name__)

# File type validation
ALLOWED_EXTENSIONS = {".csv", ".xlsx", ".xls"}
MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024  # 25MB

# Classification patterns
PAN_PATTERN = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
AADHAAR_PATTERN = re.compile(r"^[2-9]{1}[0-9]{3}\s?[0-9]{4}\s?[0-9]{4}$")
PHONE_PATTERN = re.compile(r"^[6-9]\d{9}$")
EMAIL_PATTERN = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$")
PINCODE_PATTERN = re.compile(r"^\d{6}$")
DOB_PATTERN = re.compile(r"^(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})|(\d{4}[/-]\d{1,2}[/-]\d{1,2})$")

# Header keyword mapping
HEADER_KEYWORDS = {
    DataCategory.SENSITIVE_PERSONAL: {
        "pan", "aadhaar", "aadhar", "uid", "ssn", "passport", "driving_license",
        "health", "medical", "biometric", "religion", "caste", "political",
        "bank_account", "ifsc", "card_number", "cvv", "password", "salary",
    },
    DataCategory.PERSONAL: {
        "name", "first_name", "last_name", "full_name", "customer_name",
        "email", "phone", "mobile", "contact", "address", "city", "state",
        "country", "pincode", "pin_code", "zip", "postal",
        "dob", "date_of_birth", "birth_date", "age", "gender",
        "ip_address", "device_id", "location",
    },
}

PURPOSE_KEYWORDS = {
    "Order Fulfilment": {"address", "phone", "name", "order", "shipping", "delivery"},
    "Customer Support": {"name", "email", "phone", "ticket", "issue", "complaint"},
    "Marketing & Promotions": {"email", "phone", "marketing", "promo", "campaign"},
    "Payment Processing": {"card", "bank", "payment", "transaction", "upi"},
    "Tax & Accounting Compliance": {"pan", "gst", "tax", "invoice", "billing"},
    "Legal Obligation": {"contract", "agreement", "legal", "compliance"},
    "HR & Payroll": {"salary", "employee", "staff", "payroll", "designation"},
    "Analytics & Service Improvement": {"analytics", "usage", "behavior", "metrics"},
}


def validate_file(file: UploadFile) -> Tuple[bool, str]:
    """Validate file type and size without reading content.

    Returns (is_valid, error_message).
    """
    # Check extension
    filename = file.filename or ""
    ext = filename.lower()[filename.rfind("."):]
    if ext not in ALLOWED_EXTENSIONS:
        return False, f"Invalid file format. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"

    # Check size (approximate from headers)
    content_length = file.size if hasattr(file, "size") and file.size else None
    if content_length and content_length > MAX_FILE_SIZE_BYTES:
        return False, f"File too large. Maximum size: {MAX_FILE_SIZE_BYTES // (1024*1024)}MB"

    return True, ""


def _classify_by_sample(values: List[str]) -> Tuple[DataCategory, str]:
    """Classify a column based on sample values.

    Returns (category, confidence).
    """
    if not values:
        return DataCategory.NOT_PERSONAL, "low"

    # Filter out empty values
    non_empty = [v.strip() for v in values if v and str(v).strip()]
    if not non_empty:
        return DataCategory.NOT_PERSONAL, "low"

    sample_size = min(len(non_empty), 20)
    samples = non_empty[:sample_size]

    sensitive_count = 0
    personal_count = 0

    for val in samples:
        val_str = str(val).strip()

        if PAN_PATTERN.match(val_str):
            sensitive_count += 3  # Strong signal
        elif AADHAAR_PATTERN.match(val_str):
            sensitive_count += 3
        elif EMAIL_PATTERN.match(val_str):
            personal_count += 2
        elif PHONE_PATTERN.match(val_str):
            personal_count += 2
        elif PINCODE_PATTERN.match(val_str):
            personal_count += 1
        elif DOB_PATTERN.match(val_str):
            personal_count += 2

    # Determine category
    if sensitive_count >= 1:
        return DataCategory.SENSITIVE_PERSONAL, "high" if sensitive_count >= 2 else "medium"
    elif personal_count >= 1:
        return DataCategory.PERSONAL, "high" if personal_count >= 2 else "medium"

    return DataCategory.NOT_PERSONAL, "low"


def _classify_by_header(header: str) -> Optional[DataCategory]:
    """Classify based on column header text."""
    header_lower = header.lower().strip().replace(" ", "_")

    for category, keywords in HEADER_KEYWORDS.items():
        if any(kw in header_lower for kw in keywords):
            return category

    return None


def _suggest_purposes(header: str, category: DataCategory) -> List[str]:
    """Suggest purposes based on header and category."""
    header_lower = header.lower()
    suggestions = []

    for purpose, keywords in PURPOSE_KEYWORDS.items():
        if any(kw in header_lower for kw in keywords):
            suggestions.append(purpose)

    # Default suggestions based on category
    if not suggestions:
        if category == DataCategory.SENSITIVE_PERSONAL:
            suggestions = ["Legal Obligation", "Tax & Accounting Compliance"]
        elif category == DataCategory.PERSONAL:
            suggestions = ["Order Fulfilment", "Customer Support"]

    return suggestions[:3]  # Max 3 suggestions


def _read_file_in_memory(file: UploadFile) -> pd.DataFrame:
    """Read file into a pandas DataFrame entirely in memory."""
    filename = file.filename or ""
    ext = filename.lower()[filename.rfind("."):]

    # Read into memory buffer
    content = file.file.read()
    buffer = io.BytesIO(content)

    if ext == ".csv":
        df = pd.read_csv(buffer, nrows=1000)  # Limit rows for preview
    else:
        df = pd.read_excel(buffer, nrows=1000)

    return df


async def process_inventory_file(file: UploadFile) -> Tuple[List[Dict], int, int, Dict]:
    """Process an uploaded file for data inventory.

    This function:
    1. Validates the file
    2. Reads it entirely in memory (never touches disk/S3)
    3. Extracts headers and sample values
    4. Generates classification suggestions
    5. Immediately discards the file content
    6. Returns only metadata and suggestions

    Returns: (suggestions, row_count, column_count, purge_log)
    """
    start_time = datetime.now(timezone.utc)

    # Validate
    is_valid, error = validate_file(file)
    if not is_valid:
        raise ValueError(error)

    # Read in memory
    df = _read_file_in_memory(file)

    row_count = len(df)
    column_count = len(df.columns)

    if row_count == 0 or column_count == 0:
        raise ValueError("File appears to be empty or has no headers")

    # Generate suggestions
    suggestions = []
    for col in df.columns:
        header = str(col).strip()

        # Get sample values (max 20)
        sample_values = df[col].astype(str).head(20).tolist()

        # Try content-based classification first
        category, confidence = _classify_by_sample(sample_values)

        # Fall back to header-based if content-based is uncertain
        if confidence == "low":
            header_category = _classify_by_header(header)
            if header_category:
                category = header_category
                confidence = "medium"

        purposes = _suggest_purposes(header, category)

        suggestions.append({
            "field_name": header,
            "suggested_category": enum_value(category),
            "suggested_purposes": purposes,
            "confidence": confidence,
        })

    # IMMEDIATELY discard everything
    # Clear DataFrame and buffer. del is sufficient here: a non-cyclic
    # pandas DataFrame is freed the instant its last reference is dropped
    # under CPython's reference counting -- a forced gc.collect() adds real
    # cost on every upload without adding any additional purge guarantee.
    del df

    end_time = datetime.now(timezone.utc)
    duration_ms = (end_time - start_time).total_seconds() * 1000

    purge_log = {
        "file_received": start_time.isoformat(),
        "bytes_processed": file.size if hasattr(file, "size") and file.size else None,
        "rows_processed": row_count,
        "columns_processed": column_count,
        "in_memory_object_dereferenced": True,
        "temp_buffer_cleared": True,
        "purge_completed": end_time.isoformat(),
        "duration_ms": duration_ms,
    }

    logger.info(
        "File processed and purged",
        extra={"purge_log": purge_log, "filename": file.filename},
    )

    return suggestions, row_count, column_count, purge_log


async def process_inventory_file_from_bytes(
    file_bytes: bytes, filename: str
) -> Tuple[List[Dict], int, int, Dict]:
    """Process inventory file from in-memory bytes (never touches disk).

    Same pipeline as process_inventory_file but for Google Drive downloads.
    """
    import io

    # Validate extension
    ext = os.path.splitext(filename.lower())[1]
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {ext}. Use .csv, .xlsx, or .xls")

    # Validate size
    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        raise ValueError(f"File too large. Max size: {MAX_FILE_SIZE_MB}MB")

    # Parse into DataFrame
    buffer = io.BytesIO(file_bytes)
    try:
        if ext == ".csv":
            df = pd.read_csv(buffer, nrows=1000)
        else:
            df = pd.read_excel(buffer, nrows=1000)
    except Exception as exc:
        logger.error(f"Failed to parse file: {exc}")
        raise ValueError("Could not parse file. Ensure it is a valid Excel or CSV file.")

    row_count = len(df)
    col_count = len(df.columns)

    if row_count == 0 or col_count == 0:
        raise ValueError("File appears to be empty or has no headers.")

    # Generate suggestions
    suggestions = []
    for col in df.columns:
        col_str = str(col).strip()
        sample_values = df[col].dropna().astype(str).head(20).tolist()
        category, purposes, confidence = classify_column(col_str, sample_values)
        suggestions.append({
            "field_name": col_str,
            "suggested_category": category,
            "suggested_purposes": purposes,
            "confidence": confidence,
        })

    # Purge verification
    buffer.close()
    del buffer
    del df
    import gc
    gc.collect()

    purge_log = {
        "filename": filename,
        "bytes_processed": len(file_bytes),
        "buffer_dereferenced": True,
        "dataframe_deleted": True,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    return suggestions, row_count, col_count, purge_log
