"""Tests for the privacy notice PDF download endpoint."""
import os

import pytest
from fastapi import status
from httpx import AsyncClient
from sqlalchemy import select

from app.models import Account, AuditLog, PrivacyNotice, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_download_privacy_notice_pdf_success(async_client: AsyncClient, db_session):
    """A valid notice returns a PDF with correct headers and creates an audit log."""
    account = Account(
        business_name="Download Test Co",
        business_slug="download-test",
        sector="E-commerce",
        widget_nonce_secret=os.urandom(32).hex(),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="dl@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    notice = PrivacyNotice(
        account_id=account.id,
        template_type="generic",
        content={
            "title": "Privacy Notice",
            "language": "en",
            "sections": [
                {"title": "Introduction", "body": "We value your privacy."},
            ],
        },
        version=1,
        is_published=True,
    )
    db_session.add(notice)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    response = await async_client.get(
        f"/api/v1/privacy-notice/{notice.public_id}/download",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == status.HTTP_200_OK
    assert response.headers["content-type"] == "application/pdf"
    assert "attachment" in response.headers.get("content-disposition", "")
    assert b"%PDF" == response.content[:4]
    assert len(response.content) > 1000

    # Verify audit log was created with correct field names
    result = await db_session.execute(
        select(AuditLog).where(
            AuditLog.account_id == account.id,
            AuditLog.event_type == "privacy_notice_downloaded",
        )
    )
    log = result.scalar_one_or_none()
    assert log is not None
    assert log.event_details.get("notice_public_id") == str(notice.public_id)
    assert log.event_details.get("version") == 1


@pytest.mark.asyncio
async def test_download_privacy_notice_not_found(async_client: AsyncClient, db_session):
    """Requesting a non-existent notice returns 404."""
    account = Account(
        business_name="Not Found Co",
        business_slug="not-found",
        sector="E-commerce",
        widget_nonce_secret=os.urandom(32).hex(),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="nf@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    fake_id = __import__("uuid").uuid4()
    response = await async_client.get(
        f"/api/v1/privacy-notice/{fake_id}/download",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == status.HTTP_404_NOT_FOUND
