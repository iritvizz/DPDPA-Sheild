"use client";

import { useEffect, useState } from "react";
import { useTranslations } from "next-intl";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface WithdrawalStatus {
  customer_reference: string;
  purpose: string;
  is_revoked: boolean;
  withdrawn_at: string | null;
  message: string;
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export default function WithdrawalPage({
  params,
}: {
  params: { token: string };
}) {
  const t = useTranslations();
  const [status, setStatus] = useState<WithdrawalStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [confirming, setConfirming] = useState(false);

  const load = () => {
    setLoading(true);
    fetch(`${API_BASE}/api/v1/consent/public/withdrawal/${params.token}`)
      .then((res) => {
        if (!res.ok) throw new Error("This withdrawal link is invalid or has expired.");
        return res.json();
      })
      .then(setStatus)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, [params.token]);

  const handleConfirm = async () => {
    setConfirming(true);
    setError("");
    try {
      const res = await fetch(`${API_BASE}/api/v1/consent/public/withdrawal/${params.token}`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Failed to process your withdrawal request.");
      const data = await res.json();
      setStatus(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setConfirming(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <Card className="max-w-md w-full">
        <CardHeader>
          <CardTitle>{t("consent.withdrawalLink")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : error ? (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : status ? (
            <>
              <p className="text-gray-700">{status.message}</p>
              {!status.is_revoked && (
                <Button onClick={handleConfirm} disabled={confirming} className="w-full">
                  {confirming ? "Processing..." : "Confirm Withdrawal"}
                </Button>
              )}
            </>
          ) : null}
        </CardContent>
      </Card>
    </div>
  );
}
