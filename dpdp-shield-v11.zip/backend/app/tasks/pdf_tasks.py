"""Celery tasks for PDF generation."""
from app.tasks import celery_app
from app.services.pdf_service import PDFService
from app.utils.logging import get_logger

logger = get_logger(__name__)


@celery_app.task(bind=True, max_retries=3)
def generate_audit_pack_pdf(self, notice_content: dict, business_name: str, output_path: str):
    """Generate audit pack PDF asynchronously."""
    try:
        service = PDFService()
        result_path = service.generate_privacy_notice_pdf(notice_content, business_name)
        logger.info(f"Audit pack PDF generated: {result_path}")
        return {"status": "success", "path": result_path}
    except Exception as exc:
        logger.error(f"PDF generation failed: {exc}")
        raise self.retry(exc=exc, countdown=60)
