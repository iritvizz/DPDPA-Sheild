"""PDF generation tasks."""
import tempfile
from datetime import datetime, timezone

from app.tasks import celery_app
from app.services.pdf_service import PDFService
from app.utils.logging import get_logger
from app.utils.enums import enum_value

logger = get_logger(__name__)


@celery_app.task(bind=True, max_retries=2)
def generate_audit_pack(self, account_id: int, user_id: int):
    """Generate full audit pack PDF.

    Fetches all account data, generates HTML, converts to PDF,
    uploads to S3, and updates the AuditPackGeneration record.
    """
    from app.database import AsyncSessionLocal
    from sqlalchemy import select
    from app.models import (
        Account, AuditPackGeneration, ConsentRecord, DataElement,
        DataSource, PrivacyNotice, User,
    )
    from app.services.s3_service import S3Service

    logger.info(f"Generating audit pack for account={account_id}")

    async def _generate():
        async with AsyncSessionLocal() as db:
            # Get account
            result = await db.execute(select(Account).where(Account.id == account_id))
            account = result.scalar_one_or_none()
            if not account:
                raise ValueError(f"Account {account_id} not found")

            # Get data sources with elements
            result = await db.execute(
                select(DataSource).where(DataSource.account_id == account_id)
            )
            data_sources_raw = result.scalars().all()
            data_sources = []
            for ds in data_sources_raw:
                elements = []
                for elem in ds.elements:
                    elements.append({
                        "field_name": elem.field_name,
                        "data_category": enum_value(elem.data_category),
                        "purposes": elem.purposes,
                        "legal_basis": elem.legal_basis,
                        "retention": f"{elem.retention_period_value} {elem.retention_period_unit}" if elem.retention_period_value else None,
                        "third_party_sharing": elem.third_party_sharing,
                    })
                data_sources.append({
                    "name": ds.name,
                    "source_type": enum_value(ds.source_type),
                    "status": enum_value(ds.status),
                    "column_count": ds.column_count,
                    "row_count": ds.row_count,
                    "elements": elements,
                })

            # Get privacy notices
            result = await db.execute(
                select(PrivacyNotice).where(PrivacyNotice.account_id == account_id)
            )
            notices_raw = result.scalars().all()
            privacy_notices = []
            for n in notices_raw:
                privacy_notices.append({
                    "version": n.version,
                    "template_type": n.template_type,
                    "is_published": n.is_published,
                    "published_at": n.published_at.isoformat() if n.published_at else None,
                })

            # Get consent records (metadata only)
            result = await db.execute(
                select(ConsentRecord).where(ConsentRecord.account_id == account_id)
            )
            consent_raw = result.scalars().all()
            consent_records = []
            for c in consent_raw:
                consent_records.append({
                    "public_id": str(c.public_id),
                    "customer_reference": c.customer_reference,
                    "purpose": c.purpose,
                    "method": enum_value(c.method),
                    "is_revoked": c.is_revoked,
                    "created_at": c.created_at.isoformat() if c.created_at else None,
                })

            # Get audit logs
            result = await db.execute(
                select(AuditLog).where(AuditLog.account_id == account_id)
            )
            logs_raw = result.scalars().all()
            audit_logs = []
            for l in logs_raw:
                audit_logs.append({
                    "event_type": l.event_type,
                    "event_details": l.event_details,
                    "created_at": l.created_at.isoformat() if l.created_at else None,
                })

            # Generate PDF
            pdf_service = PDFService()
            account_dict = {
                "public_id": str(account.public_id),
                "business_name": account.business_name,
                "business_slug": account.business_slug,
                "sector": account.sector,
                "grievance_email": account.grievance_email,
                "grievance_phone": account.grievance_phone,
                "grievance_address": account.grievance_address,
            }

            html_content = pdf_service.generate_audit_pack_html(
                account=account_dict,
                data_sources=data_sources,
                privacy_notices=privacy_notices,
                consent_records=consent_records,
                audit_logs=audit_logs,
            )

            # Generate PDF file
            import uuid
            file_id = str(uuid.uuid4())
            pdf_path = f"/tmp/audit_pack_{file_id}.pdf"
            output_path = pdf_service.generate_pdf(html_content, pdf_path)

            # Upload to S3
            s3 = S3Service()
            s3_key = f"audit-packs/{account_id}/{file_id}.pdf"

            with open(output_path, "rb") as f:
                pdf_bytes = f.read()

            # Use boto3 directly for upload
            import boto3
            from botocore.config import Config as BotoConfig
            from app.config import get_settings
            settings = get_settings()

            s3_client = boto3.client(
                "s3",
                region_name=settings.AWS_REGION,
                aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                config=BotoConfig(signature_version="s3v4"),
            )
            s3_client.put_object(
                Bucket=settings.S3_BUCKET_CONSENT_PROOFS,
                Key=s3_key,
                Body=pdf_bytes,
                ContentType="application/pdf",
                ServerSideEncryption="AES256",
            )

            # Update record
            result = await db.execute(
                select(AuditPackGeneration).where(
                    AuditPackGeneration.account_id == account_id,
                    AuditPackGeneration.status == "pending",
                )
            )
            pack_record = result.scalar_one_or_none()
            if pack_record:
                pack_record.status = "completed"
                pack_record.file_s3_key = s3_key
                pack_record.completed_at = datetime.now(timezone.utc)
                pack_record.expires_at = datetime.now(timezone.utc) + timedelta(days=7)
                await db.commit()

            # Clean up temp file
            if os.path.exists(output_path):
                os.remove(output_path)

            logger.info(f"Audit pack generated: {s3_key}")
            return {
                "status": "completed",
                "file_s3_key": s3_key,
                "download_url": s3.generate_presigned_url(s3_key, expiration=604800),  # 7 days
            }

    import asyncio
    return asyncio.run(_generate())


@celery_app.task
def generate_privacy_notice_pdf(notice_id: int):
    """Generate privacy notice PDF."""
    logger.info(f"Generating privacy notice PDF: notice={notice_id}")
    # TODO: Implement when privacy notice editor is complete
    return {"status": "completed"}
