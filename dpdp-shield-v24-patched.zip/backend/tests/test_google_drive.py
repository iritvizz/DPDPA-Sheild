"""Google Drive integration endpoint tests."""
import secrets

import pytest
from fastapi import status
from httpx import AsyncClient

from app.models import Account, GoogleDriveConnection, User, UserRole
from app.utils.auth import create_access_token


@pytest.mark.asyncio
async def test_connect_returns_valid_oauth_url_when_configured(async_client: AsyncClient, db_session, monkeypatch):
    """Connect returns a valid-looking OAuth URL when Google credentials are configured."""
    from app.config import get_settings
    settings = get_settings()
    monkeypatch.setattr(settings, "GOOGLE_CLIENT_ID", "test-client-id")
    monkeypatch.setattr(settings, "GOOGLE_CLIENT_SECRET", "test-client-secret")

    account = Account(
        business_name="GD Test",
        business_slug="gd-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="gd@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    response = await async_client.post(
        "/api/v1/inventory/google-drive/connect",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    data = response.json()
    assert "accounts.google.com" in data["message"] or "googleapis.com" in data["message"]


@pytest.mark.asyncio
async def test_disconnect_clears_connection(async_client: AsyncClient, db_session):
    """Disconnect removes the stored Google Drive connection."""
    account = Account(
        business_name="GD Disconnect Test",
        business_slug="gd-disconnect-test",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="gdd@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)

    conn = GoogleDriveConnection(
        account_id=account.id,
        encrypted_token_json="fake-encrypted-token",
    )
    db_session.add(conn)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    response = await async_client.post(
        "/api/v1/inventory/google-drive/disconnect",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    assert "disconnected" in response.json()["message"].lower()

    # Verify it's gone
    response = await async_client.post(
        "/api/v1/inventory/google-drive/disconnect",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_connect_rejects_when_not_configured(async_client: AsyncClient, db_session, monkeypatch):
    """Connect returns 503 when Google Drive is not configured."""
    from app.config import get_settings
    settings = get_settings()
    monkeypatch.setattr(settings, "GOOGLE_CLIENT_ID", None)
    monkeypatch.setattr(settings, "GOOGLE_CLIENT_SECRET", None)

    account = Account(
        business_name="GD Unconfigured",
        business_slug="gd-unconfigured",
        sector="E-commerce",
        widget_nonce_secret=secrets.token_urlsafe(32),
    )
    db_session.add(account)
    await db_session.flush()

    user = User(
        account_id=account.id,
        email="gdu@example.com",
        password_hash="h",
        role=UserRole.ADMIN,
    )
    db_session.add(user)
    await db_session.commit()

    token = create_access_token({"sub": str(user.public_id)})

    response = await async_client.post(
        "/api/v1/inventory/google-drive/connect",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 503
    assert "not configured" in response.json()["detail"].lower()
