"""S3 operations for consent proof files."""
import io
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

import boto3
import magic
from botocore.config import Config as BotoConfig
from botocore.exceptions import ClientError

from app.config import get_settings
from app.utils.logging import get_logger

logger = get_logger(__name__)

ALLOWED_MIME_TYPES = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "application/pdf": ".pdf",
}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB


class S3Service:
    def __init__(self):
        self.settings = get_settings()
        self.s3_client = boto3.client(
            "s3",
            region_name=self.settings.AWS_REGION,
            aws_access_key_id=self.settings.AWS_ACCESS_KEY_ID,
            aws_secret_access_key=self.settings.AWS_SECRET_ACCESS_KEY,
            config=BotoConfig(signature_version="s3v4"),
        )

    def validate_file_content(self, file_content: bytes, declared_filename: str) -> tuple[bool, str]:
        """Validate file using magic bytes, not extension."""
        # Check size
        if len(file_content) > MAX_FILE_SIZE:
            return False, f"File too large. Maximum: {MAX_FILE_SIZE // (1024*1024)}MB"

        # Detect actual MIME type from content
        detected_mime = magic.from_buffer(file_content, mime=True)

        if detected_mime not in ALLOWED_MIME_TYPES:
            return False, f"Invalid file type detected: {detected_mime}. Allowed: PNG, JPG, PDF"

        # Verify extension matches detected type
        ext = declared_filename.lower()[declared_filename.rfind("."):]
        expected_ext = ALLOWED_MIME_TYPES[detected_mime]
        if ext != expected_ext:
            return False, f"File extension does not match content. Expected {expected_ext}, got {ext}"

        return True, ""

    async def upload_consent_proof(self, file_content: bytes, filename: str, account_id: int) -> tuple[str, str]:
        """Upload consent proof to S3 temp bucket for scanning."""
        is_valid, error = self.validate_file_content(file_content, filename)
        if not is_valid:
            raise ValueError(error)

        # Generate unique key
        file_id = str(uuid.uuid4())
        detected_mime = magic.from_buffer(file_content, mime=True)
        key = f"uploads/{account_id}/{file_id}{ALLOWED_MIME_TYPES[detected_mime]}"

        # Upload to temp bucket first
        self.s3_client.put_object(
            Bucket=self.settings.S3_BUCKET_TEMP,
            Key=key,
            Body=file_content,
            ContentType=detected_mime,
            ServerSideEncryption="AES256",
        )

        return key, file_id

    async def move_to_permanent(self, temp_key: str, account_id: int) -> str:
        """Move file from temp to permanent bucket after scan."""
        permanent_key = temp_key.replace("uploads/", f"consent-proofs/{account_id}/")

        # Copy to permanent bucket
        self.s3_client.copy_object(
            CopySource={"Bucket": self.settings.S3_BUCKET_TEMP, "Key": temp_key},
            Bucket=self.settings.S3_BUCKET_CONSENT_PROOFS,
            Key=permanent_key,
            ServerSideEncryption="AES256",
        )

        # Delete from temp
        self.s3_client.delete_object(
            Bucket=self.settings.S3_BUCKET_TEMP,
            Key=temp_key,
        )

        return permanent_key

    async def upload_file(self, file_content: bytes, key: str, content_type: str = "application/octet-stream") -> str:
        """Upload arbitrary generated file content (e.g. reports) to the permanent bucket."""
        self.s3_client.put_object(
            Bucket=self.settings.S3_BUCKET_CONSENT_PROOFS,
            Key=key,
            Body=file_content,
            ContentType=content_type,
            ServerSideEncryption="AES256",
        )
        return key

    def generate_presigned_url(self, key: str, expiration: int = 300) -> str:
        """Generate a presigned URL for temporary access."""
        return self.s3_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.settings.S3_BUCKET_CONSENT_PROOFS, "Key": key},
            ExpiresIn=expiration,
        )

    def delete_file(self, key: str) -> None:
        """Permanently delete a file from S3."""
        try:
            self.s3_client.delete_object(
                Bucket=self.settings.S3_BUCKET_CONSENT_PROOFS,
                Key=key,
            )
        except ClientError as e:
            logger.error(f"Failed to delete S3 object: {e}")
            raise
